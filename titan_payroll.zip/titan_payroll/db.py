import json
import os
import re
import psycopg2
import psycopg2.extras
from flask import g
import config


# ---------------------------------------------------------------------------
# Thin compatibility layer so the rest of the app (written against sqlite3's
# API) can talk to Postgres/Supabase with minimal changes:
#   - "?" positional and ":name" named placeholders both work (SQLite style)
#   - rows behave like dicts (row["col"]), same as sqlite3.Row
#   - cursor.lastrowid is emulated by auto-appending RETURNING id to bare
#     INSERTs (every table except `settings` has an `id` primary key)
# ---------------------------------------------------------------------------

_INSERT_RE = re.compile(r"^\s*INSERT\s+INTO\s+(\w+)", re.IGNORECASE)
_NAMED_PARAM_RE = re.compile(r":(\w+)")
_NO_ID_TABLES = {"settings"}


def _translate(sql, params):
    """Convert SQLite-style placeholders to psycopg2's, and figure out
    whether this needs an auto-appended RETURNING id for .lastrowid."""
    if isinstance(params, dict):
        sql = _NAMED_PARAM_RE.sub(r"%(\1)s", sql)
    else:
        sql = sql.replace("?", "%s")

    auto_returning = False
    m = _INSERT_RE.match(sql)
    if m and "returning" not in sql.lower() and m.group(1).lower() not in _NO_ID_TABLES:
        sql = sql.rstrip().rstrip(";") + " RETURNING id"
        auto_returning = True
    return sql, auto_returning


class Cursor:
    def __init__(self, pg_cursor):
        self._cur = pg_cursor
        self.lastrowid = None

    def execute(self, sql, params=()):
        pg_sql, auto_returning = _translate(sql, params)
        self._cur.execute(pg_sql, params)
        if auto_returning:
            row = self._cur.fetchone()
            self.lastrowid = row["id"] if row else None
        return self

    def executemany(self, sql, seq_of_params):
        pg_sql, _ = _translate(sql, seq_of_params[0] if seq_of_params else ())
        self._cur.executemany(pg_sql, seq_of_params)
        return self

    def executescript(self, script):
        self._cur.execute(script)
        return self

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()

    def close(self):
        self._cur.close()

    def __getattr__(self, name):
        return getattr(self._cur, name)


class Connection:
    def __init__(self, pg_conn):
        self._conn = pg_conn

    def cursor(self):
        return Cursor(self._conn.cursor())

    def execute(self, sql, params=()):
        cur = self.cursor()
        cur.execute(sql, params)
        return cur

    def executemany(self, sql, seq_of_params):
        cur = self.cursor()
        cur.executemany(sql, seq_of_params)
        return cur

    def executescript(self, script):
        cur = self.cursor()
        cur.executescript(script)
        self.commit()
        return cur

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()


def _connect():
    if not config.DATABASE_URL:
        raise RuntimeError(
            "DATABASE_URL is not set. This app now runs against Supabase/Postgres -- "
            "set the DATABASE_URL environment variable to your Supabase connection string."
        )
    pg_conn = psycopg2.connect(config.DATABASE_URL, cursor_factory=psycopg2.extras.RealDictCursor)
    pg_conn.autocommit = False
    return Connection(pg_conn)


def get_db():
    if "db" not in g:
        g.db = _connect()
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables/functions if they don't exist yet (idempotent -- schema.sql
    uses CREATE TABLE/INDEX IF NOT EXISTS and CREATE OR REPLACE FUNCTION), and
    seed default settings. Returns True if this looks like a brand-new database
    (no users yet)."""
    conn = _connect()
    with open(os.path.join(config.BASE_DIR, "schema.sql"), "r") as f:
        conn.executescript(f.read())

    first_time = conn.execute("SELECT 1 FROM users LIMIT 1").fetchone() is None

    for key, value in config.DEFAULT_SETTINGS.items():
        row = conn.execute("SELECT 1 FROM settings WHERE key = %s", (key,)).fetchone()
        if not row:
            conn.execute("INSERT INTO settings (key, value) VALUES (%s, %s)", (key, value))

    conn.commit()
    conn.close()
    return first_time


def get_setting(db, key, default=None):
    row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    if row is None:
        return default
    return row["value"]


def get_setting_json(db, key, default=None):
    val = get_setting(db, key, None)
    if val is None:
        return default
    return json.loads(val)


def get_setting_float(db, key, default=0.0):
    val = get_setting(db, key, None)
    if val is None:
        return default
    return float(val)


def set_setting(db, key, value):
    db.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value)),
    )
    db.commit()


def log_action(db, user_id, action, details=""):
    db.execute(
        "INSERT INTO audit_log (user_id, action, details) VALUES (?, ?, ?)",
        (user_id, action, details),
    )
    db.commit()
