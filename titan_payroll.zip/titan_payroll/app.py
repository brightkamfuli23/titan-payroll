import os
import datetime
from flask import Flask, g, render_template, redirect, url_for, request, flash, session
from werkzeug.security import generate_password_hash

import config
from db import get_db, close_db, init_db
from auth import load_logged_in_user, login_required

from routes.auth_routes import bp as auth_bp
from routes.dashboard import bp as dashboard_bp
from routes.drivers import bp as drivers_bp
from routes.payroll import bp as payroll_bp
from routes.charges import bp as charges_bp
from routes.settings_routes import bp as settings_bp
from routes.users_routes import bp as users_bp
from routes.roster import bp as roster_bp


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = config.SECRET_KEY
    # Now reachable over the open internet (not just an office LAN), so lock
    # the session cookie down: JS can't read it, it's only ever sent over
    # HTTPS, it isn't sent cross-site, and it expires after 8 hours idle.
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = bool(os.environ.get("DATABASE_URL"))
    app.config["PERMANENT_SESSION_LIFETIME"] = datetime.timedelta(hours=8)
    app.teardown_appcontext(close_db)

    @app.before_request
    def _make_session_permanent():
        session.permanent = True

    with app.app_context():
        init_db()

    @app.before_request
    def _before():
        load_logged_in_user()

    @app.route("/setup", methods=["GET", "POST"])
    def setup():
        db = get_db()
        has_user = db.execute("SELECT 1 FROM users LIMIT 1").fetchone()
        if has_user:
            return redirect(url_for("auth.login"))
        if request.method == "POST":
            username = request.form.get("username", "").strip().lower()
            full_name = request.form.get("full_name", "").strip()
            password = request.form.get("password", "")
            if not username or not full_name or len(password) < 8:
                flash("Please fill all fields; password must be at least 8 characters.", "danger")
                return render_template("setup.html")
            db.execute(
                "INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)",
                (username, generate_password_hash(password), full_name, "admin"),
            )
            db.commit()
            flash("Admin account created. Please log in.", "success")
            return redirect(url_for("auth.login"))
        return render_template("setup.html")

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(drivers_bp)
    app.register_blueprint(payroll_bp)
    app.register_blueprint(charges_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(roster_bp)

    # Require login for everything except auth/setup/static
    @app.before_request
    def _require_login():
        open_endpoints = {"auth.login", "setup", "static"}
        if request.endpoint in open_endpoints:
            return
        if g.get("user") is None:
            db = get_db()
            has_user = db.execute("SELECT 1 FROM users LIMIT 1").fetchone()
            if not has_user:
                return redirect(url_for("setup"))
            flash("Please log in to continue.", "warning")
            return redirect(url_for("auth.login", next=request.path))

    def _initials(name):
        if not name:
            return "?"
        parts = [p for p in name.strip().split() if p]
        if not parts:
            return "?"
        if len(parts) == 1:
            return parts[0][:2].upper()
        return (parts[0][0] + parts[-1][0]).upper()

    AVATAR_COLORS = ["#12b76a", "#f59e0b", "#6366f1", "#ec4899", "#0ea5e9", "#f97316", "#8b5cf6", "#14b8a6"]

    def _avatar_color(name):
        if not name:
            return AVATAR_COLORS[0]
        return AVATAR_COLORS[sum(ord(c) for c in name) % len(AVATAR_COLORS)]

    app.jinja_env.filters["initials"] = _initials
    app.jinja_env.filters["avatar_color"] = _avatar_color

    @app.context_processor
    def inject_globals():
        user = g.get("user")
        return {
            "product_name": config.PRODUCT_NAME,
            "company_name": config.COMPANY_NAME,
            "currency": config.CURRENCY,
            "current_user": user,
            "user_initials": _initials(user["full_name"]) if user else None,
            "now": datetime.datetime.now(),
        }

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("error.html", code=403, message="You don't have permission to view that page."), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="Page not found."), 404

    return app


app = create_app()

if __name__ == "__main__":
    import socket
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
    except Exception:
        local_ip = "127.0.0.1"
    print("=" * 70)
    print(f" {config.PRODUCT_NAME} — {config.COMPANY_NAME}")
    print("=" * 70)
    print(f" Running on this computer:   http://127.0.0.1:5000")
    print(f" On the office network from another PC/phone: http://{local_ip}:5000")
    print(" Press CTRL+C to stop the server.")
    print("=" * 70)
    app.run(host="0.0.0.0", port=5000, debug=False)
