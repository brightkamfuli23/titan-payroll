@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  BK HRM 300 - Payroll Backup
echo ============================================================

if not exist "venv\" (
    echo The app hasn't been run yet on this computer ^(no venv found^).
    echo Run run_windows.bat once first, then try this again.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat

REM Optional: drag a folder onto this file, or pass a path as an argument,
REM to also copy the backup there (e.g. a OneDrive folder or USB drive).
REM Example (edit and uncomment to always copy to the same place):
REM python utils\backup_cli.py "D:\TitanPayrollBackups"

python utils\backup_cli.py %*

echo.
echo Done. See the backups\ folder next to this app.
pause
