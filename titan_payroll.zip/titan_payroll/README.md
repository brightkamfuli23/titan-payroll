# BK HRM 300 — Zambia Driver Payroll System

A payroll web application, currently deployed for **Titan Gateway Logistics
Limited** (one client's data lives in this particular deployment — the app
itself is a generic product; every other client gets their own deployment
from the same codebase, with only `config.py`'s `COMPANY_NAME` changed).

This deployment replaces Titan's old manual
`TITAN PAYROLL ZAMBIA DRIVER JULY 2026.xlsx` workbook. It's cloud-hosted —
the database lives in **Supabase** (Postgres) and the app itself runs on
**Render** — so Admin/HR/Accountant staff can reach it from anywhere with a
browser, not just one office PC. Drivers do not log in — each gets a PDF
payslip you distribute by email/WhatsApp/print.

Your 295 existing driver records (263 active, 16 spare, 16 terminated) from
the original workbook are already loaded into the Supabase database — there's
nothing to import.

**Trucks and drivers are tracked separately.** A "Fleet Number" identifies a
truck, not a person — drivers rotate on and off trucks (leave, sickness,
desertion, resignation, termination), so the **Truck Roster** screen is
where you manage who's currently on which truck, move someone to the bench,
and put a bench driver onto a truck to replace them — by dragging cards, or
with the buttons on each driver's page. See section 5.

---

## 1. How this is hosted

Two pieces, both with free tiers:

- **Supabase** — the Postgres database. All data (drivers, payroll runs,
  charges, users, etc.) lives here. Manage it at https://supabase.com/dashboard.
- **Render** — runs the Flask application itself and gives it a public URL
  (`https://<your-app-name>.onrender.com`). Manage it at
  https://dashboard.render.com.

Because both are cloud services, there is no "start the app" step for daily
use the way a locally-hosted version would have — the app is simply always
online at its Render URL. Admin/HR/Accountant staff log in from that URL on
any device with a browser (phone, laptop, tablet) — no VPN or office network
needed.

### Configuration (environment variables on Render)

The app reads two environment variables, set once on the Render web service
(Render dashboard → your service → **Environment**):

- `DATABASE_URL` — the Supabase Postgres connection string (Supabase
  dashboard → your project → **Project Settings → Database → Connection
  string (URI)**).
- `PAYROLL_SECRET_KEY` — a random secret used to sign login sessions. Generate
  one with `python3 -c "import secrets; print(secrets.token_hex(32))"` and
  never reuse it elsewhere. The app refuses to start without this set once
  `DATABASE_URL` is present, so it can't accidentally run with the old
  hardcoded placeholder key on the open internet.

### Redeploying after a code change

Render redeploys automatically on every push to the connected Git branch. To
change something yourself: edit the code, commit, push — Render picks it up
within a minute or two. You can also trigger a manual redeploy from the
Render dashboard without a code change (e.g. after only changing an
environment variable).

## 2. First login

Open the app's Render URL. The first visit shows a **"Welcome to BK HRM
300"** screen — create your Admin account here (this is the only account
with full access; you can add HR/Accountant accounts afterwards from the
**Users** screen). From then on, everyone just goes to the same URL and logs
in with their own username/password.

## 3. User roles

| Role | Can do |
|---|---|
| **Admin** | Everything: run and finalize payroll, manage drivers, charges, users, statutory settings, the Truck Roster, and terminations/terminal dues. |
| **Accountant** | View payroll runs and download payslips, bank files, statutory reports and management summaries. Cannot edit driver records, the Truck Roster, or run/finalize payroll. |
| **HR** | Manage driver records and the Truck Roster (bench, assign, swap drivers between trucks). Cannot see salary figures, payroll runs, statutory reports, or finalize a termination (terminal dues involve pay figures, so that step needs Admin). |

Drivers are **not** system users — see "Payslip delivery" below.

## 4. Monthly payroll workflow

1. **Payroll → New Payroll Run**, pick the month/year. This pulls in every
   currently **Active** (on a truck) driver *and* every **Bench** (spare)
   driver, each with their own basic salary, default work days (26), and
   their own actual food/transport allowance. Bench drivers are included
   by default because being on the bench for a legitimate reason — sick
   leave, resting between trucks, etc. — doesn't stop someone being paid;
   they're marked with a <span class="badge spare">Bench</span> tag on the
   run screen so you can tell at a glance who's on a truck and who isn't.
   If someone on the bench shouldn't be paid this month (they've exceeded
   their leave with no communication, for example), remove them from this
   run with the ✕ button next to their line, then process them through
   **Termination** from their driver page or the Truck Roster (section 5)
   — removing them from payroll and terminating them are two separate,
   deliberate steps, so nothing happens automatically just because someone
   is on the bench.
2. On the run screen, fill in each driver's **Days Attended** for the month
   (and Leave Days / Backpay / Gratuity / Bonus / Advance if applicable —
   leave at 0 otherwise). Any driver with an open **Charge** (see below)
   already has a suggested installment amount pre-filled in the Charges
   column — adjust if needed. Salary, Housing, Gross Pay, NHIMA, NAPSA,
   PAYE and Net Pay update **live in the browser** as you type, so you can
   see the effect immediately — but nothing is saved until you click
   Save & Recalculate. Missed someone (e.g. a bench driver you removed and
   want to re-add), or need to add a driver mid-run? Use **Add a Driver to
   This Run** below the table — any driver ID works, whatever their status.
3. Click **Save & Recalculate** to persist the figures (this is what
   actually writes them to the database — the live numbers above are a
   preview). Do this as often as you like while checking figures.
4. Click **🔒 Finalize Payroll Run** once everything is correct. This locks
   the run from further editing and posts the charge deductions to the
   Charges ledger (reducing each driver's outstanding balance).
5. Use the **Outputs** buttons at the top of the run to download:
   - **Full Payroll Register (Excel, audit record)** — a three-sheet
     workbook that's the complete underlying record, not just the pay run:
     - *Payroll Register* — every pay element for every driver on this run
       (fleet no., bank/account, date employed, basic, days attended,
       salary, housing, food, transport, leave pay, backpay, gratuity,
       bonuses, advance, gross pay, NHIMA, NAPSA, PAYE, charge deductions,
       net pay), plus a header block showing the period, DRAFT/FINALIZED
       status, who prepared the run and when, and — once finalized — who
       finalized it and when. Ends with a Prepared By / Reviewed By /
       Approved By sign-off block for printed copies.
     - *Bench Drivers (Spare)* — the full current bench census: who they
       are, when they came off their truck, and why (sick leave, resting
       between trucks, desertion, suspension, etc.), plus an "On This
       Payroll Run?" column showing whether each one was actually paid
       this run (they are, by default, unless manually removed) — so the
       register accounts for the whole workforce, not just who got paid.
     - *Terminated Drivers* — everyone recorded as terminated, with their
       terminal dues settlement (gratuity, leave pay, other amounts,
       deductions, total payable) where one was processed through this
       system, or a clear "No settlement record in system" flag for anyone
       terminated before this system tracked that.
     Every sheet has a totals row (SUM formulas, not hard-coded numbers, so
     you can verify them in Excel). This is the file to keep for
     ZRA/NAPSA/NHIMA audits or internal record-keeping — download it again
     any time from a draft run to get current figures, or from a finalized
     run for the permanent record. Available to Admin and Accountant only.
   - **All Payslips (ZIP of PDFs)** — one PDF per driver, named by fleet
     number and surname, ready to email/WhatsApp/print to each driver.
   - **Bank Payment File (Excel)** — one sheet per bank (FNB, Stanbic,
     Access, ABSA, etc.) plus a combined sheet, with account details and
     amounts, ready to reformat for your bank's bulk-payment upload.
   - **NAPSA / NHIMA / PAYE Schedules** — contribution/tax schedules for
     each statutory body (see note under "Statutory rates" below).
   - **Management Summary** — headcount, payroll cost, and contract
     status/expiry alerts, similar to your old "Status Report" sheet.

## 5. Truck Roster — moving drivers between trucks, the bench, and termination

Open **Truck Roster** (Admin/HR). It's a three-column board:

- **On Truck — Active**: every driver currently assigned to a truck, plus any
  **vacant trucks** (a truck that exists but has no driver right now).
- **Bench — Spare**: drivers not currently on any truck (on leave, off sick,
  between trucks, etc.). Being on the bench doesn't stop someone being
  paid — they're included on new payroll runs by default (section 4); the
  bench is for tracking who isn't on a truck right now, not for cutting
  off pay.
- **Terminated**: recently separated drivers (read-only list).

**Moving someone to the bench** (sick leave, desertion, resignation pending,
suspension, truck breakdown, etc.): drag their card onto the Bench column
(or use the "Move to Bench" button on their driver page), pick a reason, and
confirm. Their truck immediately shows up as vacant.

**Replacing them with someone taking over**: drag a Bench driver's card onto
a vacant truck card (or onto the outgoing driver's card, to do both moves —
bench the outgoing driver *and* assign the incoming one to the same
truck — in one action) and confirm. You can also do this from the driver's
own page with the "Assign to Truck" button.

Every move is logged with a date, reason and note, so **Truck Assignment
History** on each driver's page shows their full record of which trucks they
drove and why they came off each one — useful for HR/disciplinary records
(e.g. repeated "desertion" entries) as well as day-to-day dispatch.

**New drivers** are added to the Bench by default; you can assign them a
truck immediately from the Add Driver form, or later from the Roster.

**A bench driver who exceeds their leave without communication** (the
classic "went on sick leave and never came back" case) isn't handled
automatically — you decide when that's happened. On the payroll run they'd
otherwise be paid on, remove their line with the ✕ button (section 4),
then terminate them below with reason **Desertion / Absconded** (or
whichever reason actually fits) so their terminal dues are calculated and
they're taken off future runs entirely.

### Termination & terminal dues

Drag a driver's card onto **Terminated** (or use the "Terminate / Process
Terminal Dues" button on their page — Admin only, since it involves salary
figures). You'll see a form with **suggested figures you review and adjust
before confirming**:

- **Gratuity or severance**, calculated per the Employment Code Act:
  - Contract expiry, resignation, desertion, dismissal, other → **25% of
    basic pay earned during the contract** (pro-rated if ended early).
  - Redundancy, medical discharge, death in service → **2 months' basic pay
    per completed year served**.
- **Leave pay** for any accrued (2 days/month) leave not yet taken or paid
  out, valued at current pay.
- **Other/bonus** — a free-text manual amount (e.g. notice pay in lieu) —
  nothing is auto-calculated here since notice-period rules depend on the
  specific contract.
- **Outstanding charges/loans** are automatically listed and deducted from
  the final settlement, and closed out once the termination is confirmed.

Confirming: settles all open charges for that driver, frees their truck if
they had one, marks them **Terminated**, and saves a permanent record you
can revisit from their driver page (**Termination / Terminal Dues**).

**Please have HR/your labour-law advisor sign off on the gratuity vs.
severance rule mapping** (which reasons trigger which formula) before
relying on it for real payouts — it's a judgement call built from the
Employment Code Act No. 3 of 2019, not a substitute for legal advice on any
specific case.

## 6. Driver Charges (loans, damages, etc.)

Go to **Charges → + Add Charge**, pick the driver, describe the charge
(e.g. "Windscreen damage"), and set the **total amount** and the **monthly
installment**. From then on, every payroll run automatically suggests that
installment as a deduction from the driver's **net pay** (after tax — this
is separate from the old "Advance/Credit" field, which still reduces gross
pay pre-tax as it did in the original sheet). The remaining balance is
tracked automatically and the charge closes itself once fully paid. You can
always adjust the suggested amount on the payroll run screen before saving.

## 7. Statutory rates (Settings screen, Admin only)

All tax/contribution rates are stored as **editable settings**, not
hard-coded — when ZRA/NAPSA/NHIMA change rates (e.g. at the next national
budget), an Admin updates them in **Settings** without needing a developer.

Verified as current for 2026 (checked against the KPMG/UNDP Zambia 2026
National Budget Highlights and NAPSA's public notice, August 2026):

- **PAYE** (monthly, unchanged from 2025): K0–5,100 = 0%; K5,101–7,100 =
  20%; K7,101–9,200 = 30%; above K9,200 = 37%.
- **NAPSA**: 5% employee contribution, capped at an insurable earnings
  ceiling of **K37,236/month** (i.e. never more than **K1,861.80/month**),
  effective 1 January 2026. *(The original spreadsheet applied 5% of Gross
  Pay with no ceiling at all — this system fixes that gap. It didn't affect
  July 2026 figures since no driver's pay was near the ceiling, but it will
  matter for any higher earner in future.)*
- **NHIMA**: 1% of Basic Salary, no ceiling. Matches the original sheet.

**Please have your accountant/tax advisor confirm one existing practice
carried over unchanged from the original workbook:** PAYE is calculated on
Gross Pay *minus* Bonus/Other, and Gratuity + Salary Backpay are added to
net pay without any PAYE applied to them at all. This may be intentional
(e.g. distinct tax treatment for terminal benefits), but it's worth a
one-time sign-off since it meaningfully reduces tax on those specific pay
elements. It's flagged again inside `utils/payroll_calc.py`.

The NAPSA/NHIMA/PAYE export workbook is a **best-effort** layout built from
public guidance on what each body typically requires (names, ID numbers,
contribution base, amounts) — it is *not* a confirmed copy of NAPSA's
e-Service, NHIMA's portal, or ZRA TaxOnline's exact upload template. Check
the real upload format before your first electronic submission; the sheet
can be adjusted to match if the columns need to move around.

## 8. Data notes from the migration

- **"Fleet Number"** (e.g. `N005`, `T001`, `EXN167`) identifies a **truck**,
  not an employee. Since the original workbook stored it directly on the
  driver row, this system now tracks it properly with its own Trucks/Truck
  Roster model (see section 5) — every **active** driver's fleet number from
  July 2026 was seeded as a live truck assignment automatically, *except
  one case*: `N038` was listed against two different active drivers
  (MAPILI GIVEUS and SIMATA MUKWAMATABA) in the original sheet, so it
  couldn't be auto-resolved. SIMATA MUKWAMATABA was imported as Active but
  with **no truck assigned** — the Dashboard and Truck Roster both flag
  this; assign him his real current truck from the Roster when convenient.
  Spare and terminated drivers' fleet numbers were kept as reference text
  only (no live assignment), since they weren't actively driving anything
  in July.
- The original workbook had some rows using a rounded daily-pay rate
  (e.g. exactly `154`) instead of the precise `Basic Salary ÷ Work Days`
  formula used on other rows — an inconsistency likely from manual editing
  over time. This system always uses the precise formula for every driver
  going forward, so a handful of July figures may differ by a few Kwacha
  from the original sheet for that reason (verified: all NHIMA/NAPSA/PAYE
  logic matches the original exactly wherever it used the formula-driven
  rows).
- Bank details, account numbers, NRC/TPIN/NAPSA/NHIMA numbers, and contract
  dates were carried over as entered in the original sheet. A few driver
  records have missing bank names (shown as "UNSPECIFIED" in the bank
  export) or missing ID numbers — worth a data-cleanup pass in **Drivers**
  when you have time.
- **Food and Transport allowances are captured per driver, not as one
  company-wide figure.** Food was uniform (K180) across every driver in the
  July sheet, but Transport was not — most drivers are on K156 (partial) or
  K200 (full attendance), but drivers on certain long-haul routes are on
  K1,620 or K3,420. Each driver's own July figures were imported onto their
  Driver record (see **Employment & Pay** on their Edit Driver page) and
  every new payroll run now seeds that driver's line from their own record,
  not a blanket default. If a driver's route or allowance changes, update it
  once on their Driver record and every future run picks it up automatically
  — you can still override it for a single month directly on that payroll
  run if needed.

## 9. Backups

The database lives in Supabase, not on anyone's laptop, so nothing is lost
if a computer is turned off, lost, or replaced. Two layers of protection:

1. **Supabase's own backups** — covered by whatever backup/PITR (point-in-
   time recovery) tier your Supabase project is on; check **Project
   Settings → Database → Backups** in the Supabase dashboard. The free tier
   has more limited backup retention than paid tiers — if this system
   becomes business-critical, it's worth reviewing that page and considering
   an upgrade.
2. **From the app** — Admin → **Settings** → **Download Database Backup
   Now**. Generates a plain-text `.sql` file (every driver, payroll run,
   charge, and termination, as ready-to-replay `INSERT` statements) and
   sends it straight to your browser's Downloads folder — a portable copy
   you control independently of Supabase. Save it to a OneDrive/Google Drive
   folder or email it to yourself. This also runs automatically every time a
   payroll run is finalized, saved into the app's `backups/` folder — but
   since Render's filesystem is not guaranteed to persist across deploys,
   treat the **Settings** download button as the reliable way to get a copy
   safely off-platform, not the `backups/` folder alone.

**To restore a `.sql` backup**: apply `schema.sql` to a fresh/empty Supabase
project first (so the tables exist), then run the backup file's SQL against
it — either via `psql "<connection-string>" -f your_backup.sql` from a
computer with the Postgres client tools installed, or by pasting its
contents into the Supabase dashboard's **SQL Editor** and running it.

`backup_now.sh` / `backup_now.bat` still work for an on-demand or scheduled
snapshot from any machine — they just need `DATABASE_URL` set in that
machine's environment first, since the database is no longer a local file.

## 10. Project structure (for reference)

```
titan_payroll/
  app.py                 Flask application
  config.py               Company/default settings
  db.py                    Database helper (includes safe in-place upgrades)
  schema.sql               Database schema
  auth.py                  Login/roles
  routes/                  Web routes (drivers, payroll, charges, settings, users, roster)
  utils/
    payroll_calc.py        Core payroll calculation engine
    contract.py             Contract span/status/leave helpers
    roster.py                Truck assignment logic (bench/assign/swap)
    terminal_dues.py         Gratuity/severance/leave-pay calculator
    payslip_pdf.py           PDF payslip generation
    bank_export.py           Bank payment file export
    statutory_reports.py     NAPSA/NHIMA/PAYE export
    summary_report.py        Management summary export
    payroll_register.py      Full payroll register export (audit record)
    backup.py                 Database snapshot helper (used by Settings and by backup_now)
    backup_cli.py              Command-line backup, for scripts/Task Scheduler
    import_excel.py          One-time legacy Excel import (already run for you)
  templates/               HTML pages
  static/                  CSS
  instance/payroll.db      Your data (drivers, trucks, payroll runs, users, charges, terminations)
  backups/                 Automatic/manual database snapshots (see section 9)
  requirements.txt         Python packages needed
  run_windows.bat / run_mac.sh       Start scripts
  backup_now.bat / backup_now.sh     On-demand/scheduled backup scripts
```
