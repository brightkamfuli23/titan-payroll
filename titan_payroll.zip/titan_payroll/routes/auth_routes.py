from flask import Blueprint, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import check_password_hash
from db import get_db, log_action

bp = Blueprint("auth", __name__, url_prefix="/auth")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user is not None:
        return redirect(url_for("dashboard.index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username = ? AND active = 1", (username,)
        ).fetchone()

        error = None
        if user is None or not check_password_hash(user["password_hash"], password):
            error = "Incorrect username or password."

        if error is None:
            session.clear()
            session["user_id"] = user["id"]
            log_action(db, user["id"], "login", "")
            nxt = request.args.get("next")
            return redirect(nxt or url_for("dashboard.index"))

        flash(error, "danger")

    return render_template("login.html")


@bp.route("/logout")
def logout():
    if g.user:
        db = get_db()
        log_action(db, g.user["id"], "logout", "")
    session.clear()
    return redirect(url_for("auth.login"))
