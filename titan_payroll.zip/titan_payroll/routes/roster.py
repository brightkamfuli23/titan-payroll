import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, jsonify
from db import get_db, log_action, get_setting_float
from utils import roster as roster_utils
from utils.terminal_dues import compute_terminal_dues, REASONS
from utils.contract import contract_info

bp = Blueprint("roster", __name__, url_prefix="/roster")


def _can_manage_roster():
    return g.user["role"] in ("admin", "hr")


@bp.before_request
def _guard():
    if g.user is None:
        abort(403)
    if not _can_manage_roster():
        flash("Only Admin and HR can manage the truck roster.", "danger")
        abort(403)


@bp.route("/")
def board():
    db = get_db()
    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))

    active_rows = db.execute(
        """SELECT d.*, ta.id as assignment_id, t.fleet_number as truck_fleet_number, ta.start_date as assignment_start
           FROM drivers d
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE d.status = 'active' ORDER BY t.fleet_number"""
    ).fetchall()

    spare_rows = db.execute("SELECT * FROM drivers WHERE status = 'spare' ORDER BY updated_at DESC").fetchall()
    terminated_rows = db.execute(
        "SELECT * FROM drivers WHERE status = 'terminated' ORDER BY date_terminated DESC LIMIT 30"
    ).fetchall()
    vacant_trucks = roster_utils.get_vacant_trucks(db)

    # flag active drivers without a current truck assignment (data conflicts, or newly hired)
    unassigned_active = [r for r in active_rows if r["assignment_id"] is None]

    enriched_active = []
    for r in active_rows:
        info = contract_info(r["date_employed"], r["contract_end_override"], contract_length, leave_per_month)
        enriched_active.append({"driver": r, "contract": info})

    return render_template(
        "roster.html", active_rows=enriched_active, spare_rows=spare_rows,
        terminated_rows=terminated_rows, vacant_trucks=vacant_trucks,
        unassigned_count=len(unassigned_active), bench_reasons=roster_utils.BENCH_REASONS,
        is_admin=(g.user["role"] == "admin"),
    )


@bp.route("/bench/<int:driver_id>", methods=["POST"])
def bench(driver_id):
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    reason = request.form.get("reason", "other")
    note = request.form.get("note", "")
    effective_date = request.form.get("effective_date") or datetime.date.today().isoformat()

    freed = roster_utils.move_to_bench(db, driver_id, reason, note, g.user["id"], effective_date)
    log_action(db, g.user["id"], "driver_to_bench", f"driver_id={driver_id} reason={reason} freed_truck={freed}")
    if freed:
        flash(f"{driver['first_name']} {driver['surname']} moved to the bench. Truck {freed} is now vacant.", "success")
    else:
        flash(f"{driver['first_name']} {driver['surname']} moved to the bench.", "success")

    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({"ok": True})
    return redirect(url_for("roster.board"))


@bp.route("/assign/<int:driver_id>", methods=["POST"])
def assign(driver_id):
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    fleet_number = request.form.get("fleet_number", "").strip()
    note = request.form.get("note", "")
    effective_date = request.form.get("effective_date") or datetime.date.today().isoformat()

    if not fleet_number:
        flash("Please choose or type a truck/fleet number to assign.", "danger")
        return redirect(url_for("roster.board"))

    try:
        truck = roster_utils.assign_to_truck(db, driver_id, fleet_number, g.user["id"], effective_date, note)
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("roster.board"))

    log_action(db, g.user["id"], "driver_to_truck", f"driver_id={driver_id} truck={truck['fleet_number']}")
    flash(f"{driver['first_name']} {driver['surname']} assigned to truck {truck['fleet_number']}.", "success")
    return redirect(url_for("roster.board"))


@bp.route("/swap", methods=["POST"])
def swap():
    """Drag-and-drop 'replace' shortcut: bench the outgoing driver and put
    the incoming (bench) driver straight onto the same truck."""
    db = get_db()
    outgoing_id = int(request.form["outgoing_driver_id"])
    incoming_id = int(request.form["incoming_driver_id"])
    reason = request.form.get("reason", "other")
    note = request.form.get("note", "")
    effective_date = request.form.get("effective_date") or datetime.date.today().isoformat()

    outgoing = db.execute("SELECT * FROM drivers WHERE id=?", (outgoing_id,)).fetchone()
    incoming = db.execute("SELECT * FROM drivers WHERE id=?", (incoming_id,)).fetchone()
    if outgoing is None or incoming is None:
        abort(404)

    try:
        truck = roster_utils.swap_driver(db, outgoing_id, incoming_id, reason, note, g.user["id"], effective_date)
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("roster.board"))

    log_action(db, g.user["id"], "driver_swap",
               f"out={outgoing_id} in={incoming_id} truck={truck['fleet_number']}")
    flash(f"{incoming['first_name']} {incoming['surname']} now on truck {truck['fleet_number']}, "
          f"replacing {outgoing['first_name']} {outgoing['surname']} (moved to bench).", "success")
    return redirect(url_for("roster.board"))


@bp.route("/terminate/<int:driver_id>", methods=["GET", "POST"])
def terminate(driver_id):
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    if driver["status"] == "terminated":
        flash("This driver is already terminated.", "warning")
        return redirect(url_for("drivers.driver_detail", driver_id=driver_id))

    # Terminal dues involve basic salary and payable amounts -- restrict to Admin,
    # consistent with HR not having salary visibility elsewhere in the system.
    if g.user["role"] != "admin":
        flash("Only Admin can process terminal dues and finalize a termination. "
              "HR can prepare the move to bench in the meantime.", "warning")
        return redirect(url_for("roster.board"))

    if request.method == "POST":
        termination_date = request.form.get("termination_date") or datetime.date.today().isoformat()
        reason = request.form.get("reason", "other")
        gratuity_amount = float(request.form.get("gratuity_amount") or 0)
        leave_days_owing = float(request.form.get("leave_days_owing") or 0)
        leave_pay_amount = float(request.form.get("leave_pay_amount") or 0)
        other_amount = float(request.form.get("other_amount") or 0)
        other_description = request.form.get("other_description", "")
        deductions_amount = float(request.form.get("deductions_amount") or 0)
        notes = request.form.get("notes", "")
        gratuity_method = request.form.get("gratuity_method", "contract_gratuity_25pct")
        basic_pay_basis = float(request.form.get("basic_pay_basis") or 0)

        total_payable = round(gratuity_amount + leave_pay_amount + other_amount - deductions_amount, 2)

        cur = db.execute(
            """INSERT INTO terminations
               (driver_id, termination_date, reason, gratuity_method, basic_pay_basis,
                gratuity_amount, leave_days_owing, leave_pay_amount, other_amount,
                other_description, deductions_amount, total_payable, status, notes, created_by)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (driver_id, termination_date, reason, gratuity_method, basic_pay_basis,
             gratuity_amount, leave_days_owing, leave_pay_amount, other_amount,
             other_description, deductions_amount, total_payable, "finalized", notes, g.user["id"]),
        )
        termination_id = cur.lastrowid

        # Settle outstanding charges against this termination
        open_charges = db.execute(
            "SELECT * FROM charges WHERE driver_id = ? AND status = 'open'", (driver_id,)
        ).fetchall()
        for c in open_charges:
            paid = db.execute(
                "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (c["id"],)
            ).fetchone()["s"]
            balance = round(c["total_amount"] - paid, 2)
            if balance > 0:
                db.execute(
                    "INSERT INTO charge_deductions (charge_id, termination_id, amount) VALUES (?,?,?)",
                    (c["id"], termination_id, balance),
                )
            db.execute("UPDATE charges SET status='paid' WHERE id=?", (c["id"],))

        # End any current truck assignment
        roster_utils.move_to_bench(db, driver_id, "termination", f"Terminated: {reason}", g.user["id"], termination_date)

        db.execute(
            "UPDATE drivers SET status='terminated', date_terminated=?, updated_at=now_text() WHERE id=?",
            (termination_date, driver_id),
        )
        db.commit()
        log_action(db, g.user["id"], "driver_terminate", f"driver_id={driver_id} termination_id={termination_id} total={total_payable}")
        flash(f"{driver['first_name']} {driver['surname']} terminated. Final settlement: "
              f"{'ZMW'} {total_payable:,.2f}.", "success")
        return redirect(url_for("roster.termination_detail", termination_id=termination_id))

    reason = request.args.get("reason", "contract_expiry")
    termination_date = request.args.get("termination_date") or datetime.date.today().isoformat()
    suggestion = compute_terminal_dues(db, driver, termination_date, reason)
    return render_template("terminate_form.html", driver=driver, suggestion=suggestion,
                            reasons=REASONS, reason=reason, termination_date=termination_date)


@bp.route("/terminate/<int:driver_id>/recalculate")
def terminate_recalculate(driver_id):
    """AJAX endpoint: recompute suggested figures when reason/date changes."""
    db = get_db()
    if g.user["role"] != "admin":
        abort(403)
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    reason = request.args.get("reason", "contract_expiry")
    termination_date = request.args.get("termination_date") or datetime.date.today().isoformat()
    suggestion = compute_terminal_dues(db, driver, termination_date, reason)
    return jsonify(suggestion)


@bp.route("/termination/<int:termination_id>")
def termination_detail(termination_id):
    db = get_db()
    if g.user["role"] != "admin":
        abort(403)
    t = db.execute(
        """SELECT term.*, d.first_name, d.surname, d.fleet_number FROM terminations term
           JOIN drivers d ON d.id = term.driver_id WHERE term.id = ?""",
        (termination_id,),
    ).fetchone()
    if t is None:
        abort(404)
    return render_template("termination_detail.html", t=t)
