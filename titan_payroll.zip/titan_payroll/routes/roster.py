import calendar
import datetime
from flask import (Blueprint, render_template, request, redirect, url_for, flash, g, abort,
                    jsonify, send_file)
from db import get_db, log_action, get_setting_float
from utils import roster as roster_utils
from utils.terminal_dues import compute_terminal_dues, REASONS
from utils.contract import contract_info
from utils.payroll_calc import PayrollInputs, compute_payroll_line
from utils.payroll_register import last_payroll_fields, build_gratuity_summary
from routes.drivers import _delete_blockers
from routes.payroll import _get_rates

bp = Blueprint("roster", __name__, url_prefix="/roster")

MONTH_NAMES = list(calendar.month_name)


def _can_manage_roster():
    return g.user["role"] in ("admin", "hr")


@bp.before_request
def _guard():
    if g.user is None:
        abort(403)
    if not _can_manage_roster():
        flash("Only Admin and HR can manage the truck roster.", "danger")
        abort(403)


@bp.route("/")
def board():
    db = get_db()
    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))

    active_rows = db.execute(
        """SELECT d.*, ta.id as assignment_id, t.fleet_number as truck_fleet_number, ta.start_date as assignment_start
           FROM drivers d
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE d.status = 'active' ORDER BY t.fleet_number"""
    ).fetchall()

    spare_rows = db.execute("SELECT * FROM drivers WHERE status = 'spare' ORDER BY updated_at DESC").fetchall()
    terminated_rows = db.execute(
        "SELECT * FROM drivers WHERE status = 'terminated' ORDER BY date_terminated DESC LIMIT 30"
    ).fetchall()
    vacant_trucks = roster_utils.get_vacant_trucks(db)

    # flag active drivers without a current truck assignment (data conflicts, or newly hired)
    unassigned_active = [r for r in active_rows if r["assignment_id"] is None]

    enriched_active = []
    for r in active_rows:
        info = contract_info(r["date_employed"], r["contract_end_override"], contract_length, leave_per_month,
                              contract_cycle_start=r["contract_cycle_start"])
        enriched_active.append({"driver": r, "contract": info})

    return render_template(
        "roster.html", active_rows=enriched_active, spare_rows=spare_rows,
        terminated_rows=terminated_rows, vacant_trucks=vacant_trucks,
        unassigned_count=len(unassigned_active), bench_reasons=roster_utils.BENCH_REASONS,
        is_admin=(g.user["role"] == "admin"),
    )


@bp.route("/bench/<int:driver_id>", methods=["POST"])
def bench(driver_id):
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    reason = request.form.get("reason", "other")
    note = request.form.get("note", "")
    effective_date = request.form.get("effective_date") or datetime.date.today().isoformat()

    freed = roster_utils.move_to_bench(db, driver_id, reason, note, g.user["id"], effective_date)
    log_action(db, g.user["id"], "driver_to_bench", f"driver_id={driver_id} reason={reason} freed_truck={freed}")
    if freed:
        flash(f"{driver['first_name']} {driver['surname']} moved to the bench. Truck {freed} is now vacant.", "success")
    else:
        flash(f"{driver['first_name']} {driver['surname']} moved to the bench.", "success")

    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({"ok": True})
    return redirect(url_for("roster.board"))


@bp.route("/assign/<int:driver_id>", methods=["POST"])
def assign(driver_id):
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    fleet_number = request.form.get("fleet_number", "").strip()
    note = request.form.get("note", "")
    effective_date = request.form.get("effective_date") or datetime.date.today().isoformat()

    if not fleet_number:
        flash("Please choose or type a truck/fleet number to assign.", "danger")
        return redirect(url_for("roster.board"))

    try:
        truck = roster_utils.assign_to_truck(db, driver_id, fleet_number, g.user["id"], effective_date, note)
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("roster.board"))

    log_action(db, g.user["id"], "driver_to_truck", f"driver_id={driver_id} truck={truck['fleet_number']}")
    flash(f"{driver['first_name']} {driver['surname']} assigned to truck {truck['fleet_number']}.", "success")
    return redirect(url_for("roster.board"))


@bp.route("/swap", methods=["POST"])
def swap():
    """Drag-and-drop 'replace' shortcut: bench the outgoing driver and put
    the incoming (bench) driver straight onto the same truck."""
    db = get_db()
    outgoing_id = int(request.form["outgoing_driver_id"])
    incoming_id = int(request.form["incoming_driver_id"])
    reason = request.form.get("reason", "other")
    note = request.form.get("note", "")
    effective_date = request.form.get("effective_date") or datetime.date.today().isoformat()

    outgoing = db.execute("SELECT * FROM drivers WHERE id=?", (outgoing_id,)).fetchone()
    incoming = db.execute("SELECT * FROM drivers WHERE id=?", (incoming_id,)).fetchone()
    if outgoing is None or incoming is None:
        abort(404)

    try:
        truck = roster_utils.swap_driver(db, outgoing_id, incoming_id, reason, note, g.user["id"], effective_date)
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("roster.board"))

    log_action(db, g.user["id"], "driver_swap",
               f"out={outgoing_id} in={incoming_id} truck={truck['fleet_number']}")
    flash(f"{incoming['first_name']} {incoming['surname']} now on truck {truck['fleet_number']}, "
          f"replacing {outgoing['first_name']} {outgoing['surname']} (moved to bench).", "success")
    return redirect(url_for("roster.board"))


@bp.route("/renew/<int:driver_id>", methods=["POST"])
def renew_contract(driver_id):
    """Renew an expired (or soon-to-expire) driver's contract for another
    standard term. Per the client's chosen policy, nothing is settled or
    paid out at renewal time -- this only resets contract_cycle_start
    (which drives expected_end/status) so the contract clock restarts.
    date_employed is left untouched, so tenure-based gratuity/leave accrual
    for an eventual future termination still reflects the driver's full
    history, continuous across renewals.

    This is the manual "renew with nothing paid out" path. There's a
    separate, automatic renewal path in routes/payroll.py's finalize_run():
    if a driver's gratuity was actually paid out on a finalized payroll run,
    that also resets contract_cycle_start (to the run's cycle end) since the
    whole point of paying it was to settle that contract term -- see the
    comment there. The two never conflict; a driver only goes through
    whichever path actually applies to them at a given time."""
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    if driver["status"] == "terminated":
        flash("This driver is already terminated.", "warning")
        return redirect(url_for("drivers.driver_detail", driver_id=driver_id))

    effective_date = request.form.get("effective_date") or datetime.date.today().isoformat()
    db.execute(
        "UPDATE drivers SET contract_cycle_start=?, updated_at=now_text() WHERE id=?",
        (effective_date, driver_id),
    )
    db.commit()

    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))
    info = contract_info(driver["date_employed"], driver["contract_end_override"], contract_length, leave_per_month,
                          contract_cycle_start=effective_date)

    log_action(db, g.user["id"], "driver_renew_contract",
               f"driver_id={driver_id} effective_date={effective_date} new_expected_end={info['expected_end']}")
    flash(f"{driver['first_name']} {driver['surname']}'s contract renewed for another standard term. "
          f"New expected end: {info['expected_end']}.", "success")

    next_url = request.form.get("next")
    if next_url:
        return redirect(next_url)
    return redirect(url_for("drivers.driver_detail", driver_id=driver_id))


@bp.route("/terminate/<int:driver_id>", methods=["GET", "POST"])
def terminate(driver_id):
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    if driver["status"] == "terminated":
        flash("This driver is already terminated.", "warning")
        return redirect(url_for("drivers.driver_detail", driver_id=driver_id))

    # Terminal dues involve basic salary and payable amounts -- restrict to Admin,
    # consistent with HR not having salary visibility elsewhere in the system.
    if g.user["role"] != "admin":
        flash("Only Admin can process terminal dues and finalize a termination. "
              "HR can prepare the move to bench in the meantime.", "warning")
        return redirect(url_for("roster.board"))

    if request.method == "POST":
        termination_date = request.form.get("termination_date") or datetime.date.today().isoformat()
        reason = request.form.get("reason", "other")
        gratuity_amount = float(request.form.get("gratuity_amount") or 0)
        leave_days_owing = float(request.form.get("leave_days_owing") or 0)
        leave_pay_amount = float(request.form.get("leave_pay_amount") or 0)
        other_amount = float(request.form.get("other_amount") or 0)
        other_description = request.form.get("other_description", "")
        deductions_amount = float(request.form.get("deductions_amount") or 0)
        notes = request.form.get("notes", "")
        gratuity_method = request.form.get("gratuity_method", "contract_gratuity_25pct")
        basic_pay_basis = float(request.form.get("basic_pay_basis") or 0)

        total_payable = round(gratuity_amount + leave_pay_amount + other_amount - deductions_amount, 2)

        cur = db.execute(
            """INSERT INTO terminations
               (driver_id, termination_date, reason, gratuity_method, basic_pay_basis,
                gratuity_amount, leave_days_owing, leave_pay_amount, other_amount,
                other_description, deductions_amount, total_payable, status, notes, created_by,
                finalized_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,now_text())""",
            (driver_id, termination_date, reason, gratuity_method, basic_pay_basis,
             gratuity_amount, leave_days_owing, leave_pay_amount, other_amount,
             other_description, deductions_amount, total_payable, "finalized", notes, g.user["id"]),
        )
        termination_id = cur.lastrowid

        # Settle outstanding charges against this termination
        open_charges = db.execute(
            "SELECT * FROM charges WHERE driver_id = ? AND status = 'open'", (driver_id,)
        ).fetchall()
        for c in open_charges:
            paid = db.execute(
                "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (c["id"],)
            ).fetchone()["s"]
            balance = round(c["total_amount"] - paid, 2)
            if balance > 0:
                db.execute(
                    "INSERT INTO charge_deductions (charge_id, termination_id, amount) VALUES (?,?,?)",
                    (c["id"], termination_id, balance),
                )
            db.execute("UPDATE charges SET status='paid' WHERE id=?", (c["id"],))

        # End any current truck assignment
        roster_utils.move_to_bench(db, driver_id, "termination", f"Terminated: {reason}", g.user["id"], termination_date)

        db.execute(
            "UPDATE drivers SET status='terminated', date_terminated=?, updated_at=now_text() WHERE id=?",
            (termination_date, driver_id),
        )
        db.commit()
        log_action(db, g.user["id"], "driver_terminate", f"driver_id={driver_id} termination_id={termination_id} total={total_payable}")
        flash(f"{driver['first_name']} {driver['surname']} terminated. Final settlement: "
              f"{'ZMW'} {total_payable:,.2f}.", "success")
        return redirect(url_for("roster.termination_detail", termination_id=termination_id))

    reason = request.args.get("reason", "contract_expiry")
    termination_date = request.args.get("termination_date") or datetime.date.today().isoformat()
    suggestion = compute_terminal_dues(db, driver, termination_date, reason)
    return render_template("terminate_form.html", driver=driver, suggestion=suggestion,
                            reasons=REASONS, reason=reason, termination_date=termination_date)


@bp.route("/terminate/<int:driver_id>/recalculate")
def terminate_recalculate(driver_id):
    """AJAX endpoint: recompute suggested figures when reason/date changes."""
    db = get_db()
    if g.user["role"] != "admin":
        abort(403)
    driver = db.execute("SELECT * FROM drivers WHERE id=?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    reason = request.args.get("reason", "contract_expiry")
    termination_date = request.args.get("termination_date") or datetime.date.today().isoformat()
    suggestion = compute_terminal_dues(db, driver, termination_date, reason)
    return jsonify(suggestion)


@bp.route("/termination/<int:termination_id>")
def termination_detail(termination_id):
    db = get_db()
    if g.user["role"] != "admin":
        abort(403)
    t = db.execute(
        """SELECT term.*, d.first_name, d.surname, d.fleet_number, d.basic_salary,
                  d.bank_name, d.account_no, d.date_employed
           FROM terminations term
           JOIN drivers d ON d.id = term.driver_id WHERE term.id = ?""",
        (termination_id,),
    ).fetchone()
    if t is None:
        abort(404)
    # TEMPORARY DIAGNOSTIC -- remove once the "Final Dues Paid" button
    # visibility report from 2026-08-21 is root-caused. Safe to leave
    # running meanwhile; just prints to the Render log stream.
    print(f"[DIAG roster] termination_id={termination_id} "
          f"has_dues_paid_at_key={'dues_paid_at' in t} dues_paid_at={t.get('dues_paid_at')!r} "
          f"row_keys={sorted(t.keys())}", flush=True)
    # Same fields, same source query as the "Last Paid Period" block on the
    # Terminated Drivers sheet in the Payroll Register export -- so what's
    # shown here always matches the Excel version for this driver.
    last_payroll = last_payroll_fields(db, t["driver_id"])
    # Whether this driver can be deleted entirely (not just the termination
    # reversed) -- e.g. a duplicate entry that was mistakenly terminated.
    # Their current status is 'terminated', so _delete_blockers() won't
    # block on this very termination record; it still blocks on finalized
    # payroll lines or any charge/loan history, same as everywhere else.
    delete_blockers = _delete_blockers(db, t["driver_id"], "terminated")
    return render_template("termination_detail.html", t=t, last_payroll=last_payroll,
                            delete_blockers=delete_blockers)


@bp.route("/termination/<int:termination_id>/reverse", methods=["POST"])
def reverse_termination(termination_id):
    """Undo a mistaken termination: reopens any charges it settled, restores
    the driver to active/spare (reopening their old truck assignment if it's
    still vacant), and removes the termination record. Mirrors the reopening
    logic in payroll.delete_run for charges affected by a deleted run."""
    db = get_db()
    if g.user["role"] != "admin":
        flash("Only Admin can reverse a termination.", "danger")
        return redirect(url_for("roster.termination_detail", termination_id=termination_id))

    t = db.execute("SELECT * FROM terminations WHERE id = ?", (termination_id,)).fetchone()
    if t is None:
        abort(404)
    driver = db.execute("SELECT * FROM drivers WHERE id = ?", (t["driver_id"],)).fetchone()
    if driver is None:
        abort(404)

    if driver["status"] != "terminated":
        flash(f"{driver['first_name']} {driver['surname']} isn't currently terminated "
              "(their status has already changed since this record was created) -- nothing to reverse.",
              "warning")
        return redirect(url_for("roster.termination_detail", termination_id=termination_id))

    # Charges that had an installment settled through this termination are
    # about to lose that charge_deductions row (it cascades away with the
    # termination). Note which are affected *before* deleting, so we can
    # reopen any left with an outstanding balance afterwards.
    affected_charge_ids = [
        r["charge_id"] for r in db.execute(
            "SELECT DISTINCT charge_id FROM charge_deductions WHERE termination_id = ?", (termination_id,)
        ).fetchall()
    ]

    # charge_deductions rows cascade-delete via their termination_id foreign key.
    db.execute("DELETE FROM terminations WHERE id = ?", (termination_id,))

    reopened = 0
    for charge_id in affected_charge_ids:
        charge = db.execute("SELECT * FROM charges WHERE id = ?", (charge_id,)).fetchone()
        if charge is None:
            continue
        paid = db.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (charge_id,)
        ).fetchone()["s"]
        balance = round(charge["total_amount"] - paid, 2)
        if balance > 0.01 and charge["status"] != "open":
            db.execute("UPDATE charges SET status='open' WHERE id=?", (charge_id,))
            reopened += 1

    # Try to restore the driver's old truck assignment, but only if it's
    # still vacant -- someone else may have been assigned to that truck
    # since the termination, and we must not silently bump them off it.
    last_assignment = db.execute(
        """SELECT * FROM truck_assignments WHERE driver_id = ? AND end_reason = 'termination'
           ORDER BY id DESC LIMIT 1""",
        (driver["id"],),
    ).fetchone()
    restored_truck = None
    if last_assignment is not None:
        occupant = roster_utils.get_current_driver_for_truck(db, last_assignment["truck_id"])
        if occupant is None:
            db.execute(
                "UPDATE truck_assignments SET end_date=NULL, end_reason=NULL, "
                "note=COALESCE(note,'') || ' (termination reversed -- reassignment restored)' WHERE id=?",
                (last_assignment["id"],),
            )
            restored_truck = last_assignment["fleet_number"]

    db.execute(
        "UPDATE drivers SET status=?, date_terminated=NULL, updated_at=now_text() WHERE id=?",
        ("active" if restored_truck else "spare", driver["id"]),
    )
    db.commit()

    log_action(
        db, g.user["id"], "driver_termination_reverse",
        f"driver_id={driver['id']} termination_id={termination_id} "
        f"termination_date={t['termination_date']} reason={t['reason']} total_payable={t['total_payable']} "
        f"reopened_charges={reopened} restored_truck={restored_truck or 'none'}",
    )
    flash(
        f"{driver['first_name']} {driver['surname']}'s termination has been reversed -- they're back on "
        + (f"truck {restored_truck}." if restored_truck else "the bench (spare); assign them to a truck from the Roster when ready.")
        + (f" {reopened} charge(s) reopened since their settlement from this termination was reversed." if reopened else ""),
        "success",
    )
    return redirect(url_for("drivers.driver_detail", driver_id=driver["id"]))


@bp.route("/termination/<int:termination_id>/mark_dues_paid", methods=["POST"])
def mark_dues_paid(termination_id):
    """Confirms this termination's final settlement was actually disbursed
    (bank transfer/cash) -- a payment-tracking flag, separate from the
    already-final total_payable figure itself.

    As a safety net, this also scrubs any leftover Gratuity/Leave Days this
    same driver might still be carrying on an open (draft) Payroll Run --
    e.g. if their contract had already gone "Expired" and gotten
    auto-suggested there (see utils.terminal_dues.contract_due_status)
    before this termination was processed, or if the run was created after
    the termination but the driver wasn't removed from it. Without this,
    they could get paid gratuity/leave twice: once here, once on that run.
    Only the gratuity/leave-days portion of an affected line is zeroed out
    -- days actually worked this cycle may still be legitimately owed, so
    the rest of the line (days attended, salary, etc.) is left alone.
    Finalized runs are locked and are never touched by this; if a driver
    was already paid gratuity on a finalized run before being terminated,
    Admin needs to review that manually."""
    db = get_db()
    if g.user["role"] != "admin":
        flash("Only Admin can confirm final dues paid.", "danger")
        return redirect(url_for("roster.termination_detail", termination_id=termination_id))

    t = db.execute("SELECT * FROM terminations WHERE id = ?", (termination_id,)).fetchone()
    if t is None:
        abort(404)
    if t["dues_paid_at"]:
        flash("Final dues were already marked as paid for this termination.", "warning")
        return redirect(url_for("roster.termination_detail", termination_id=termination_id))

    db.execute(
        "UPDATE terminations SET dues_paid_at=now_text(), dues_paid_by=? WHERE id=?",
        (g.user["id"], termination_id),
    )

    open_lines = db.execute(
        """SELECT pl.* FROM payroll_lines pl
           JOIN payroll_runs pr ON pr.id = pl.run_id
           WHERE pl.driver_id = ? AND pr.status = 'draft'
             AND (pl.gratuity > 0 OR pl.leave_days > 0)""",
        (t["driver_id"],),
    ).fetchall()

    scrubbed = 0
    if open_lines:
        rates = _get_rates(db)
        note = f"Gratuity/leave zeroed -- final dues already settled via Termination #{termination_id}."
        for line in open_lines:
            inp = PayrollInputs(
                basic_salary=line["basic_salary"],
                work_days=line["work_days"],
                days_attended=line["days_attended"],
                housing_pct=rates["housing_pct"],
                food=line["food"],
                transport=line["transport"],
                leave_days=0.0,
                salary_backpay=line["salary_backpay"],
                gratuity=0.0,
                bonus_other=line["bonus_other"],
                advance=line["advance"],
                charge_deduction=line["charge_deduction"],
            )
            res = compute_payroll_line(inp, rates["paye_bands"], rates["napsa_rate"],
                                        rates["napsa_ceiling"], rates["nhima_rate"])
            existing_comments = (line["comments"] or "").strip()
            new_comments = (existing_comments + " " + note).strip() if existing_comments else note
            db.execute(
                """UPDATE payroll_lines SET leave_days=0, leave_pay=?, leave_balance=0, gratuity=0,
                   gross_pay=?, nhima=?, napsa=?, paye=?, payable=?, comments=? WHERE id=?""",
                (res.leave_pay, res.gross_pay, res.nhima, res.napsa, res.paye, res.payable,
                 new_comments, line["id"]),
            )
            scrubbed += 1

    db.commit()
    log_action(db, g.user["id"], "termination_mark_dues_paid",
               f"termination_id={termination_id} driver_id={t['driver_id']} scrubbed_payroll_lines={scrubbed}")

    flash("Final dues marked as paid."
          + (f" Also cleared gratuity/leave from {scrubbed} open payroll run line(s) for this driver "
             "to prevent a double payment." if scrubbed else ""),
          "success")
    return redirect(url_for("roster.termination_detail", termination_id=termination_id))


def _gratuity_period(year_arg, month_arg):
    """Resolves the (year, month) for a Gratuity Summary request -- from
    query args if given and valid, otherwise the current calendar month --
    and returns the year, month, and the month's first/last calendar dates.
    Shared by the on-screen summary and its Excel export so both always
    agree on exactly which terminations a given period covers."""
    today = datetime.date.today()
    try:
        year = int(year_arg or today.year)
        month = int(month_arg or today.month)
        if not (1 <= month <= 12):
            raise ValueError
    except ValueError:
        year, month = today.year, today.month
    month_start = datetime.date(year, month, 1)
    days_in_month = calendar.monthrange(year, month)[1]
    month_end = datetime.date(year, month, days_in_month)
    return year, month, month_start, month_end


def _gratuity_rows(db, month_start, month_end):
    return db.execute(
        """SELECT term.*, d.first_name, d.surname, d.bank_name, d.account_no, d.date_employed,
                  COALESCE(t.fleet_number, d.fleet_number) as fleet_number
           FROM terminations term
           JOIN drivers d ON d.id = term.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE term.termination_date >= ? AND term.termination_date <= ?
           ORDER BY term.termination_date, d.surname, d.first_name""",
        (month_start.isoformat(), month_end.isoformat()),
    ).fetchall()


@bp.route("/gratuity-summary")
def gratuity_summary():
    """Read-only breakdown of every termination settlement (gratuity, leave
    pay, other amounts, deductions, total payable) whose termination date
    falls in a given calendar month -- defaults to the current month.
    Same idea as a payroll run's driver-by-driver breakdown table, but for
    terminal-dues settlements instead of regular pay."""
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()

    year, month, month_start, month_end = _gratuity_period(
        request.args.get("year"), request.args.get("month")
    )
    rows = _gratuity_rows(db, month_start, month_end)

    totals = {
        "cnt": len(rows),
        "gratuity": sum(r["gratuity_amount"] for r in rows),
        "leave_pay": sum(r["leave_pay_amount"] for r in rows),
        "other": sum(r["other_amount"] for r in rows),
        "deductions": sum(r["deductions_amount"] for r in rows),
        "total_payable": sum(r["total_payable"] for r in rows),
    }

    prev_month, prev_year = (12, year - 1) if month == 1 else (month - 1, year)
    next_month, next_year = (1, year + 1) if month == 12 else (month + 1, year)
    today = datetime.date.today()

    return render_template(
        "gratuity_summary.html", rows=rows, totals=totals, year=year, month=month,
        period_label=f"{MONTH_NAMES[month]} {year}",
        prev_year=prev_year, prev_month=prev_month, next_year=next_year, next_month=next_month,
        month_names=MONTH_NAMES, is_current_month=(year == today.year and month == today.month),
    )


@bp.route("/gratuity-summary/export")
def gratuity_summary_export():
    """Downloadable Excel copy of the Gratuity Summary for a given month --
    every pay element shown on the page, up through Total Payable. It's a
    plain .xlsx, so it's freely editable for your own working notes; that
    never writes back to the live system -- corrections belong on the
    termination's own page instead."""
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()

    year, month, month_start, month_end = _gratuity_period(
        request.args.get("year"), request.args.get("month")
    )
    rows = _gratuity_rows(db, month_start, month_end)
    period_label = f"{MONTH_NAMES[month]} {year}"

    buf = build_gratuity_summary(rows, period_label, month_start.isoformat(), month_end.isoformat())
    log_action(db, g.user["id"], "gratuity_summary_export", f"period={period_label} count={len(rows)}")
    filename = f"Gratuity_Summary_{period_label.replace(' ', '_')}.xlsx"
    return send_file(
        buf, as_attachment=True, download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
