"""News Center: labour-law changes, Statutory Instruments, statutory-rate
changes and system-update notes. Everyone logged in can read it; only Admins
add, edit or delete items. Opening the page marks the items shown as read
(drives the unread badge on the bell in the top bar)."""
import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort

from db import get_db, log_action

bp = Blueprint("news", __name__, url_prefix="/news")

CATEGORIES = [
    ("labour_law", "Labour law"),
    ("si", "Statutory Instrument"),
    ("tax", "Tax & statutory rates"),
    ("system", "System update"),
]
CATEGORY_LABELS = dict(CATEGORIES)
IMPORTANCE = [
    ("info", "For information"),
    ("important", "Important"),
    ("action", "Action recommended"),
]
IMPORTANCE_LABELS = dict(IMPORTANCE)


def unread_count(db, user_id):
    row = db.execute(
        """SELECT COUNT(*) AS c FROM news_items n
           WHERE NOT EXISTS (SELECT 1 FROM news_reads r WHERE r.news_id = n.id AND r.user_id = ?)""",
        (user_id,),
    ).fetchone()
    return row["c"] if row else 0


def _require_admin():
    if g.user["role"] != "admin":
        abort(403)


def _clean_url(url):
    url = (url or "").strip()
    if url and not url.lower().startswith(("http://", "https://")):
        return None
    return url


def _read_form():
    f = request.form
    data = {
        "category": f.get("category", "labour_law"),
        "importance": f.get("importance", "info"),
        "title": f.get("title", "").strip(),
        "summary": f.get("summary", "").strip(),
        "details": f.get("details", "").strip() or None,
        "recommended_action": f.get("recommended_action", "").strip() or None,
        "source_name": f.get("source_name", "").strip() or None,
        "source_url": _clean_url(f.get("source_url")),
        "effective_date": f.get("effective_date", "").strip() or None,
    }
    error = None
    if not data["title"] or not data["summary"]:
        error = "A title and a short summary are required."
    elif data["category"] not in CATEGORY_LABELS or data["importance"] not in IMPORTANCE_LABELS:
        error = "Invalid category or importance."
    elif data["source_url"] is None:
        error = "The source link must start with http:// or https://."
    else:
        data["source_url"] = data["source_url"] or None
    return data, error


@bp.route("/")
def list_news():
    db = get_db()
    category = request.args.get("category", "")
    sql = "SELECT * FROM news_items"
    params = ()
    if category in CATEGORY_LABELS:
        sql += " WHERE category = ?"
        params = (category,)
    sql += " ORDER BY published_date DESC, id ASC"
    items = db.execute(sql, params).fetchall()

    read_ids = {r["news_id"] for r in db.execute(
        "SELECT news_id FROM news_reads WHERE user_id = ?", (g.user["id"],)).fetchall()}
    new_ids = {i["id"] for i in items if i["id"] not in read_ids}

    # Viewing the page marks what was shown as read (the NEW tags still show
    # on this visit because new_ids was worked out first).
    for nid in new_ids:
        db.execute("INSERT INTO news_reads (user_id, news_id) VALUES (?, ?) ON CONFLICT DO NOTHING",
                   (g.user["id"], nid))
    if new_ids:
        db.commit()

    return render_template("news_list.html", items=items, new_ids=new_ids, category=category,
                           categories=CATEGORIES, category_labels=CATEGORY_LABELS,
                           importance_labels=IMPORTANCE_LABELS, new_total=len(new_ids))


@bp.route("/new", methods=["GET", "POST"])
def new_item():
    _require_admin()
    db = get_db()
    if request.method == "POST":
        data, error = _read_form()
        if error:
            flash(error, "danger")
            return render_template("news_form.html", item=data, categories=CATEGORIES,
                                   importance=IMPORTANCE, editing=False)
        cur = db.execute(
            """INSERT INTO news_items (category, importance, title, summary, details, recommended_action,
                                       source_name, source_url, effective_date, published_date, created_by)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (data["category"], data["importance"], data["title"], data["summary"], data["details"],
             data["recommended_action"], data["source_name"], data["source_url"], data["effective_date"],
             datetime.date.today().isoformat(), g.user["id"]),
        )
        db.commit()
        log_action(db, g.user["id"], "news_create", f"id={cur.lastrowid} title={data['title']}")
        flash("News item published.", "success")
        return redirect(url_for("news.list_news"))
    return render_template("news_form.html", item={"category": "labour_law", "importance": "info"},
                           categories=CATEGORIES, importance=IMPORTANCE, editing=False)


@bp.route("/<int:news_id>/edit", methods=["GET", "POST"])
def edit_item(news_id):
    _require_admin()
    db = get_db()
    item = db.execute("SELECT * FROM news_items WHERE id = ?", (news_id,)).fetchone()
    if item is None:
        abort(404)
    if request.method == "POST":
        data, error = _read_form()
        if error:
            flash(error, "danger")
            data["id"] = news_id
            return render_template("news_form.html", item=data, categories=CATEGORIES,
                                   importance=IMPORTANCE, editing=True)
        db.execute(
            """UPDATE news_items SET category=?, importance=?, title=?, summary=?, details=?,
                      recommended_action=?, source_name=?, source_url=?, effective_date=?
               WHERE id=?""",
            (data["category"], data["importance"], data["title"], data["summary"], data["details"],
             data["recommended_action"], data["source_name"], data["source_url"], data["effective_date"],
             news_id),
        )
        db.commit()
        log_action(db, g.user["id"], "news_edit", f"id={news_id} title={data['title']}")
        flash("News item updated.", "success")
        return redirect(url_for("news.list_news"))
    return render_template("news_form.html", item=item, categories=CATEGORIES, importance=IMPORTANCE,
                           editing=True)


@bp.route("/<int:news_id>/delete", methods=["POST"])
def delete_item(news_id):
    _require_admin()
    db = get_db()
    item = db.execute("SELECT title FROM news_items WHERE id = ?", (news_id,)).fetchone()
    if item is None:
        abort(404)
    db.execute("DELETE FROM news_items WHERE id = ?", (news_id,))
    db.commit()
    log_action(db, g.user["id"], "news_delete", f"id={news_id} title={item['title']}")
    flash("News item deleted.", "success")
    return redirect(url_for("news.list_news"))
