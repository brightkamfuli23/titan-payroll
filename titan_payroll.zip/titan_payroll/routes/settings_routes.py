import json
import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, send_file
import config
from db import get_db, get_setting, set_setting, log_action
from utils import backup as backup_utils

bp = Blueprint("settings", __name__, url_prefix="/settings")

EDITABLE_KEYS = [
    ("paye_bands", "PAYE monthly tax bands (JSON: [[lower, upper_or_null, rate], ...])"),
    ("napsa_rate", "NAPSA employee contribution rate (e.g. 0.05 = 5%)"),
    ("napsa_ceiling", "NAPSA insurable earnings ceiling per month (ZMW)"),
    ("nhima_rate", "NHIMA contribution rate (e.g. 0.01 = 1%)"),
    ("housing_pct", "Housing allowance as % of Salary (e.g. 0.30 = 30%)"),
    ("default_food_allowance", "Default food allowance (ZMW/month)"),
    ("default_transport_full", "Default transport allowance - full attendance (ZMW/month)"),
    ("default_transport_partial", "Default transport allowance - partial attendance (ZMW/month)"),
    ("default_work_days", "Default work days per month"),
    ("leave_days_per_month", "Leave days accrued per month worked"),
    ("contract_length_months", "Standard contract length (months)"),
    ("expiring_contract_alert_days", "Alert threshold for expiring contracts (days)"),
    ("gratuity_pct", "Fixed-term contract gratuity: % of basic pay earned (e.g. 0.25 = 25%)"),
    ("redundancy_months_per_year", "Redundancy/death-in-service severance: months' basic pay per completed year served"),
]


@bp.route("/", methods=["GET", "POST"])
def index():
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()
    if request.method == "POST":
        for key, _ in EDITABLE_KEYS:
            val = request.form.get(key, "").strip()
            if key == "paye_bands":
                try:
                    json.loads(val)
                except ValueError:
                    flash("PAYE bands must be valid JSON, e.g. [[0,5100,0.0],[5100,7100,0.2],[7100,9200,0.3],[9200,null,0.37]]", "danger")
                    return redirect(url_for("settings.index"))
            set_setting(db, key, val)
        log_action(db, g.user["id"], "settings_update", "")
        flash("Settings updated.", "success")
        return redirect(url_for("settings.index"))

    values = {key: get_setting(db, key, "") for key, _ in EDITABLE_KEYS}
    recent_backups = backup_utils.list_backups()[:10]
    return render_template("settings.html", keys=EDITABLE_KEYS, values=values, recent_backups=recent_backups)


@bp.route("/backup/download")
def download_backup():
    """Take a fresh, consistent snapshot right now and send it straight to
    the browser -- the safest way to grab an offline copy before shutting
    the computer down or handing it to someone else. Also leaves a copy in
    backups/ like every other snapshot."""
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()
    path = backup_utils.make_backup(tag="manual")
    log_action(db, g.user["id"], "backup_download", path)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    company_slug = "".join(c if c.isalnum() else "_" for c in config.COMPANY_NAME).strip("_")
    return send_file(path, as_attachment=True,
                      download_name=f"{company_slug}_Payroll_Backup_{ts}.sql", mimetype="text/plain")
