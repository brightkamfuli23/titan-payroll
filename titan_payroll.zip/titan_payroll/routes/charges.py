import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort
from db import get_db, log_action

bp = Blueprint("charges", __name__, url_prefix="/charges")


def _can_manage():
    return g.user["role"] == "admin"


@bp.route("/")
def list_charges():
    db = get_db()
    status = request.args.get("status", "open")
    sql = """SELECT c.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number, d.surname, d.first_name
              FROM charges c JOIN drivers d ON d.id = c.driver_id
              LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
              LEFT JOIN trucks t ON t.id = ta.truck_id
              WHERE 1=1"""
    params = []
    if status in ("open", "paid"):
        sql += " AND c.status = ?"
        params.append(status)
    sql += " ORDER BY c.date_charged DESC"
    rows = db.execute(sql, params).fetchall()

    enriched = []
    for c in rows:
        paid = db.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (c["id"],)
        ).fetchone()["s"]
        enriched.append({"charge": c, "paid": paid, "balance": round(c["total_amount"] - paid, 2)})

    return render_template("charges_list.html", rows=enriched, status=status, can_manage=_can_manage())


@bp.route("/new", methods=["GET", "POST"])
def new_charge():
    if not _can_manage():
        flash("Only Admin can add driver charges.", "danger")
        return redirect(url_for("charges.list_charges"))
    db = get_db()
    if request.method == "POST":
        driver_id = int(request.form["driver_id"])
        description = request.form.get("description", "").strip()
        date_charged = request.form.get("date_charged") or datetime.date.today().isoformat()
        total_amount = float(request.form.get("total_amount") or 0)
        installment_amount = float(request.form.get("installment_amount") or 0)

        if not description or total_amount <= 0 or installment_amount <= 0:
            flash("Please provide a description, total amount and installment amount.", "danger")
            drivers = db.execute("SELECT * FROM drivers WHERE status != 'terminated' ORDER BY surname").fetchall()
            return render_template("charge_form.html", drivers=drivers)

        db.execute(
            """INSERT INTO charges (driver_id, description, date_charged, total_amount,
               installment_amount, created_by) VALUES (?,?,?,?,?,?)""",
            (driver_id, description, date_charged, total_amount, installment_amount, g.user["id"]),
        )
        db.commit()
        log_action(db, g.user["id"], "charge_create", f"driver_id={driver_id} amount={total_amount}")
        flash("Charge added. It will be auto-deducted (as an installment) from this driver's next payroll runs until paid off.", "success")
        return redirect(url_for("charges.list_charges"))

    drivers = db.execute("SELECT * FROM drivers WHERE status != 'terminated' ORDER BY surname").fetchall()
    return render_template("charge_form.html", drivers=drivers)


@bp.route("/<int:charge_id>")
def charge_detail(charge_id):
    db = get_db()
    charge = db.execute(
        """SELECT c.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number, d.surname, d.first_name
           FROM charges c JOIN drivers d ON d.id = c.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE c.id = ?""",
        (charge_id,),
    ).fetchone()
    if charge is None:
        abort(404)
    # A deduction comes from either a payroll run OR a termination settlement
    # (never both) -- LEFT JOIN both and label accordingly so neither kind
    # of deduction silently disappears from the history or the paid total.
    deductions = db.execute(
        """SELECT cd.*, pr.period_label, term.termination_date,
                  COALESCE(pr.period_label, 'Termination Settlement (' || term.termination_date || ')') as source_label
           FROM charge_deductions cd
           LEFT JOIN payroll_runs pr ON pr.id = cd.run_id
           LEFT JOIN terminations term ON term.id = cd.termination_id
           WHERE cd.charge_id = ? ORDER BY cd.created_at""",
        (charge_id,),
    ).fetchall()
    paid = db.execute(
        "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (charge_id,)
    ).fetchone()["s"]
    balance = round(charge["total_amount"] - paid, 2)
    return render_template("charge_detail.html", charge=charge, deductions=deductions,
                            paid=paid, balance=balance, can_manage=_can_manage())


@bp.route("/<int:charge_id>/cancel", methods=["POST"])
def cancel_charge(charge_id):
    if not _can_manage():
        abort(403)
    db = get_db()
    db.execute("UPDATE charges SET status='paid' WHERE id=?", (charge_id,))
    db.commit()
    log_action(db, g.user["id"], "charge_cancel", f"charge_id={charge_id}")
    flash("Charge marked as closed/paid. It will no longer be auto-deducted.", "success")
    return redirect(url_for("charges.charge_detail", charge_id=charge_id))
