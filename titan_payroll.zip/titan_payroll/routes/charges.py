import datetime
import json
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, send_file
from db import get_db, log_action
from utils import charges_import

bp = Blueprint("charges", __name__, url_prefix="/charges")


def _can_manage():
    return g.user["role"] == "admin"


@bp.route("/")
def list_charges():
    db = get_db()
    status = request.args.get("status", "open")
    sql = """SELECT c.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number, d.surname, d.first_name
              FROM charges c JOIN drivers d ON d.id = c.driver_id
              LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
              LEFT JOIN trucks t ON t.id = ta.truck_id
              WHERE 1=1"""
    params = []
    if status in ("open", "paid"):
        sql += " AND c.status = ?"
        params.append(status)
    sql += " ORDER BY c.date_charged DESC"
    rows = db.execute(sql, params).fetchall()

    enriched = []
    for c in rows:
        paid = db.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (c["id"],)
        ).fetchone()["s"]
        enriched.append({"charge": c, "paid": paid, "balance": round(c["total_amount"] - paid, 2)})

    return render_template("charges_list.html", rows=enriched, status=status, can_manage=_can_manage())


@bp.route("/new", methods=["GET", "POST"])
def new_charge():
    if not _can_manage():
        flash("Only Admin can add driver charges.", "danger")
        return redirect(url_for("charges.list_charges"))
    db = get_db()
    if request.method == "POST":
        driver_id = int(request.form["driver_id"])
        description = request.form.get("description", "").strip()
        date_charged = request.form.get("date_charged") or datetime.date.today().isoformat()
        total_amount = float(request.form.get("total_amount") or 0)
        installment_amount = float(request.form.get("installment_amount") or 0)

        if not description or total_amount <= 0 or installment_amount <= 0:
            flash("Please provide a description, total amount and installment amount.", "danger")
            drivers = db.execute("SELECT * FROM drivers WHERE status != 'terminated' ORDER BY surname").fetchall()
            return render_template("charge_form.html", drivers=drivers)

        db.execute(
            """INSERT INTO charges (driver_id, description, date_charged, total_amount,
               installment_amount, created_by) VALUES (?,?,?,?,?,?)""",
            (driver_id, description, date_charged, total_amount, installment_amount, g.user["id"]),
        )
        db.commit()
        log_action(db, g.user["id"], "charge_create", f"driver_id={driver_id} amount={total_amount}")
        flash("Charge added. It will be auto-deducted (as an installment) from this driver's next payroll runs until paid off.", "success")
        return redirect(url_for("charges.list_charges"))

    drivers = db.execute("SELECT * FROM drivers WHERE status != 'terminated' ORDER BY surname").fetchall()
    return render_template("charge_form.html", drivers=drivers)


@bp.route("/<int:charge_id>")
def charge_detail(charge_id):
    db = get_db()
    charge = db.execute(
        """SELECT c.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number, d.surname, d.first_name
           FROM charges c JOIN drivers d ON d.id = c.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE c.id = ?""",
        (charge_id,),
    ).fetchone()
    if charge is None:
        abort(404)
    # A deduction comes from either a payroll run OR a termination settlement
    # (never both) -- LEFT JOIN both and label accordingly so neither kind
    # of deduction silently disappears from the history or the paid total.
    deductions = db.execute(
        """SELECT cd.*, pr.period_label, term.termination_date,
                  COALESCE(pr.period_label, 'Termination Settlement (' || term.termination_date || ')') as source_label
           FROM charge_deductions cd
           LEFT JOIN payroll_runs pr ON pr.id = cd.run_id
           LEFT JOIN terminations term ON term.id = cd.termination_id
           WHERE cd.charge_id = ? ORDER BY cd.created_at""",
        (charge_id,),
    ).fetchall()
    paid = db.execute(
        "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (charge_id,)
    ).fetchone()["s"]
    balance = round(charge["total_amount"] - paid, 2)
    return render_template("charge_detail.html", charge=charge, deductions=deductions,
                            paid=paid, balance=balance, can_manage=_can_manage())


@bp.route("/<int:charge_id>/cancel", methods=["POST"])
def cancel_charge(charge_id):
    if not _can_manage():
        abort(403)
    db = get_db()
    db.execute("UPDATE charges SET status='paid' WHERE id=?", (charge_id,))
    db.commit()
    log_action(db, g.user["id"], "charge_cancel", f"charge_id={charge_id}")
    flash("Charge marked as closed/paid. It will no longer be auto-deducted.", "success")
    return redirect(url_for("charges.charge_detail", charge_id=charge_id))


@bp.route("/<int:charge_id>/delete", methods=["POST"])
def delete_charge(charge_id):
    """Permanently remove a single charge, including its deduction history
    (charge_deductions cascade-deletes via the charge_id foreign key). Use
    Close/Write Off instead if you just want to stop future deductions
    while keeping the record -- this is for a genuine mistake (wrong driver,
    duplicate entry, data import error, etc.)."""
    if not _can_manage():
        abort(403)
    db = get_db()
    charge = db.execute(
        """SELECT c.*, d.first_name, d.surname FROM charges c
           JOIN drivers d ON d.id = c.driver_id WHERE c.id = ?""",
        (charge_id,),
    ).fetchone()
    if charge is None:
        abort(404)
    paid = db.execute(
        "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (charge_id,)
    ).fetchone()["s"]

    db.execute("DELETE FROM charges WHERE id = ?", (charge_id,))
    db.commit()
    log_action(
        db, g.user["id"], "charge_delete",
        f"charge_id={charge_id} driver={charge['first_name']} {charge['surname']} "
        f"description={charge['description']!r} total_amount={charge['total_amount']} "
        f"already_deducted={paid} status_was={charge['status']}",
    )
    flash(f"Charge deleted ({charge['first_name']} {charge['surname']} — {charge['description']}).", "success")
    return_status = request.form.get("return_status", "open")
    return redirect(url_for("charges.list_charges", status=return_status))


@bp.route("/clear", methods=["POST"])
def clear_charges():
    """Permanently delete every charge currently matching the list page's
    status filter (Open, Paid/Closed, or All if no filter). Deduction
    history for each cascades away with it."""
    if not _can_manage():
        abort(403)
    db = get_db()
    status = request.form.get("status", "open")

    sql = "SELECT * FROM charges WHERE 1=1"
    params = []
    if status in ("open", "paid"):
        sql += " AND status = ?"
        params.append(status)
    rows = db.execute(sql, params).fetchall()

    if not rows:
        flash("No charges to clear.", "warning")
        return redirect(url_for("charges.list_charges", status=status))

    ids = [r["id"] for r in rows]
    total = sum(r["total_amount"] for r in rows)
    placeholders = ",".join("?" * len(ids))
    db.execute(f"DELETE FROM charges WHERE id IN ({placeholders})", ids)
    db.commit()

    log_action(
        db, g.user["id"], "charges_clear_all",
        f"status_filter={status} count={len(ids)} total_amount={total} charge_ids={ids}",
    )
    scope = {"open": "open", "paid": "paid/closed"}.get(status, "all")
    flash(f"Cleared {len(ids)} {scope} charge(s), totaling {total:,.2f}.", "success")
    return redirect(url_for("charges.list_charges", status=status))


# ---------------------------------------------------------------------
# Bulk upload (Excel / CSV)
# ---------------------------------------------------------------------

def _latest_draft_run(db):
    """The draft payroll run new charges can be added to (same pick as the
    contract-renewal queueing: latest period, not archived, not finalized)."""
    return db.execute(
        """SELECT * FROM payroll_runs WHERE status = 'draft' AND deleted_at IS NULL
           ORDER BY period_year DESC, period_month DESC LIMIT 1"""
    ).fetchone()


@bp.route("/upload/template")
def upload_template():
    if not _can_manage():
        abort(403)
    return send_file(charges_import.build_template(),
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     as_attachment=True, download_name="Driver_Charges_Upload_Template.xlsx")


@bp.route("/upload", methods=["GET", "POST"])
def upload():
    if not _can_manage():
        flash("Only Admin can add driver charges.", "danger")
        return redirect(url_for("charges.list_charges"))
    db = get_db()
    draft = _latest_draft_run(db)
    if request.method == "GET":
        return render_template("charges_upload.html", draft=draft)

    f = request.files.get("file")
    if f is None or not f.filename:
        flash("Please choose an Excel or CSV file to upload.", "danger")
        return redirect(url_for("charges.upload"))
    data = f.read(charges_import.MAX_FILE_BYTES + 1)
    rows, error = charges_import.read_sheet(data, f.filename)
    if error:
        flash(error, "danger")
        return redirect(url_for("charges.upload"))

    results = charges_import.match_rows(db, rows)
    importable = [r for r in results if r["status"] in ("ok", "warn")]
    payload = json.dumps([
        {"d": r["driver_id"], "desc": r["description"], "date": r["date"],
         "total": r["total"], "inst": r["installment"]}
        for r in importable
    ])
    counts = {k: sum(1 for r in results if r["status"] == k) for k in ("ok", "warn", "skip", "error")}
    return render_template(
        "charges_preview.html", results=results, payload=payload, counts=counts, draft=draft,
        filename=f.filename, import_total=sum(r["total"] for r in importable),
    )


@bp.route("/upload/confirm", methods=["POST"])
def upload_confirm():
    if not _can_manage():
        abort(403)
    db = get_db()
    try:
        items = json.loads(request.form.get("payload", "[]"))
        assert isinstance(items, list) and len(items) <= charges_import.MAX_ROWS
    except Exception:
        flash("The upload preview expired or was invalid. Please upload the file again.", "danger")
        return redirect(url_for("charges.upload"))

    existing = {(r["driver_id"], str(r["description"]).strip().lower(),
                 round(float(r["total_amount"]), 2), r["date_charged"])
                for r in db.execute("SELECT driver_id, description, total_amount, date_charged FROM charges").fetchall()}
    drivers = {r["id"]: r["status"] for r in db.execute("SELECT id, status FROM drivers").fetchall()}

    added, skipped = [], 0
    for it in items:
        try:
            driver_id = int(it["d"])
            desc = str(it["desc"]).strip()[:200]
            date = str(it["date"])[:10]
            datetime.date.fromisoformat(date)
            total = round(float(it["total"]), 2)
            inst = round(float(it["inst"]), 2)
        except (KeyError, ValueError, TypeError):
            skipped += 1
            continue
        if (not desc or total <= 0 or inst <= 0 or drivers.get(driver_id) in (None, "terminated")):
            skipped += 1
            continue
        inst = min(inst, total)
        key = (driver_id, desc.lower(), total, date)
        if key in existing:          # e.g. the confirm button was pressed twice
            skipped += 1
            continue
        existing.add(key)
        db.execute(
            """INSERT INTO charges (driver_id, description, date_charged, total_amount,
               installment_amount, created_by) VALUES (?,?,?,?,?,?)""",
            (driver_id, desc, date, total, inst, g.user["id"]),
        )
        added.append((driver_id, inst))
    db.commit()

    # Reflect on the current draft payroll run (and so on its payslips): add each
    # new charge's first installment to that driver's line, keeping any manual
    # edits already made on the line. Finalized runs are never touched.
    on_run = off_run = 0
    run_label = None
    if added and request.form.get("apply_to_draft"):
        run = _latest_draft_run(db)
        if run is not None:
            run_label = run["period_label"]
            per_driver = {}
            for driver_id, inst in added:
                per_driver[driver_id] = round(per_driver.get(driver_id, 0) + inst, 2)
            for driver_id, amt in per_driver.items():
                cur = db.execute(
                    """UPDATE payroll_lines SET charge_deduction = charge_deduction + ?,
                              payable = ROUND((payable - ?)::numeric, 2)
                       WHERE run_id = ? AND driver_id = ?""",
                    (amt, amt, run["id"], driver_id),
                )
                if cur.rowcount:
                    on_run += 1
                else:
                    off_run += 1
            db.commit()
            log_action(db, g.user["id"], "charges_bulk_apply_to_run",
                       f"run_id={run['id']} drivers_updated={on_run} drivers_not_on_run={off_run}")

    total_added = sum(i for _, i in added)
    log_action(db, g.user["id"], "charges_bulk_upload",
               f"added={len(added)} skipped={skipped} first_installments_total={total_added:.2f}")
    msg = f"{len(added)} charge(s) added from the upload."
    if skipped:
        msg += f" {skipped} skipped (duplicates or invalid)."
    if run_label:
        msg += f" Added to the {run_label} draft payroll run for {on_run} driver(s)."
        if off_run:
            msg += f" {off_run} driver(s) aren't on that run, so their deduction starts on the next run they are on."
    elif added:
        msg += " They will be deducted automatically on the next payroll run you create."
    flash(msg, "success")
    return redirect(url_for("charges.list_charges"))
