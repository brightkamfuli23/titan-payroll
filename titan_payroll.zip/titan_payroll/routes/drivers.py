from flask import Blueprint, render_template, request, redirect, url_for, flash, g
from db import get_db, log_action, get_setting_float
from utils.contract import contract_info
from utils import roster as roster_utils

bp = Blueprint("drivers", __name__, url_prefix="/drivers")


def _can_edit():
    return g.user["role"] in ("admin", "hr")


def _delete_blockers(db, driver_id):
    """Reasons a driver can't be deleted -- real history that must be
    preserved. Empty list means it's safe to delete (only draft-run payroll
    lines and truck-assignment records exist, if anything, and those get
    cascaded away automatically)."""
    finalized_lines = db.execute(
        "SELECT COUNT(*) c FROM payroll_lines pl JOIN payroll_runs pr ON pr.id = pl.run_id "
        "WHERE pl.driver_id = ? AND pr.status = 'finalized'", (driver_id,)
    ).fetchone()["c"]
    termination_count = db.execute(
        "SELECT COUNT(*) c FROM terminations WHERE driver_id = ?", (driver_id,)
    ).fetchone()["c"]
    charge_count = db.execute(
        "SELECT COUNT(*) c FROM charges WHERE driver_id = ?", (driver_id,)
    ).fetchone()["c"]
    reasons = []
    if finalized_lines:
        reasons.append(f"{finalized_lines} finalized payroll line(s)")
    if termination_count:
        reasons.append(f"{termination_count} termination record(s)")
    if charge_count:
        reasons.append(f"{charge_count} charge/loan record(s)")
    return reasons


@bp.route("/")
def list_drivers():
    db = get_db()
    status = request.args.get("status", "active")
    q = request.args.get("q", "").strip()

    sql = "SELECT * FROM drivers WHERE 1=1"
    params = []
    if status in ("active", "spare", "terminated"):
        sql += " AND status = ?"
        params.append(status)
    if q:
        sql += " AND (surname LIKE ? OR first_name LIKE ? OR fleet_number LIKE ?)"
        like = f"%{q}%"
        params += [like, like, like]
    sql += " ORDER BY surname, first_name"
    drivers = db.execute(sql, params).fetchall()

    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))
    alert_days = int(float(get_setting_float(db, "expiring_contract_alert_days", 30)))

    enriched = []
    for d in drivers:
        info = contract_info(d["date_employed"], d["contract_end_override"],
                              contract_length, leave_per_month,
                              contract_cycle_start=d["contract_cycle_start"])
        current_truck = roster_utils.get_current_assignment_for_driver(db, d["id"])
        enriched.append({"driver": d, "contract": info,
                          "truck": current_truck["fleet_number"] if current_truck else None})

    counts = {
        "active": db.execute("SELECT COUNT(*) c FROM drivers WHERE status='active'").fetchone()["c"],
        "spare": db.execute("SELECT COUNT(*) c FROM drivers WHERE status='spare'").fetchone()["c"],
        "terminated": db.execute("SELECT COUNT(*) c FROM drivers WHERE status='terminated'").fetchone()["c"],
    }

    return render_template("drivers_list.html", rows=enriched, status=status, q=q,
                            counts=counts, can_edit=_can_edit())


@bp.route("/new", methods=["GET", "POST"])
def new_driver():
    if not _can_edit():
        flash("You don't have permission to add drivers.", "danger")
        return redirect(url_for("drivers.list_drivers"))
    if request.method == "POST":
        return _save_driver(None)
    return render_template("driver_form.html", driver=None)


@bp.route("/<int:driver_id>/edit", methods=["GET", "POST"])
def edit_driver(driver_id):
    if not _can_edit():
        flash("You don't have permission to edit drivers.", "danger")
        return redirect(url_for("drivers.list_drivers"))
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id = ?", (driver_id,)).fetchone()
    if driver is None:
        flash("Driver not found.", "danger")
        return redirect(url_for("drivers.list_drivers"))
    if request.method == "POST":
        return _save_driver(driver_id)
    return render_template("driver_form.html", driver=driver)


def _save_driver(driver_id):
    db = get_db()
    f = request.form
    data = {
        "fleet_number": f.get("fleet_number", "").strip(),
        "surname": f.get("surname", "").strip().upper(),
        "first_name": f.get("first_name", "").strip(),
        "bank_name": f.get("bank_name", "").strip(),
        "account_no": f.get("account_no", "").strip(),
        "branch": f.get("branch", "").strip(),
        "nrc_no": f.get("nrc_no", "").strip(),
        "tpin_no": f.get("tpin_no", "").strip(),
        "napsa_no": f.get("napsa_no", "").strip(),
        "nhima_no": f.get("nhima_no", "").strip(),
        "phone": f.get("phone", "").strip(),
        "email": f.get("email", "").strip(),
        "date_employed": f.get("date_employed") or None,
        "basic_salary": float(f.get("basic_salary") or 0),
        "work_days": int(f.get("work_days") or 26),
        "food_allowance": float(f.get("food_allowance") or 180),
        "transport_full": float(f.get("transport_full") or 200),
        "contract_end_override": f.get("contract_end_override") or None,
        "comments": f.get("comments", "").strip(),
    }

    if not data["surname"] or not data["first_name"]:
        flash("Surname and first name are required.", "danger")
        return render_template("driver_form.html", driver=data if driver_id is None else data)

    if driver_id is None:
        # New drivers always start on the bench (spare) -- use "Assign to a
        # truck now" below, or assign them later from the Truck Roster.
        data["status"] = "spare"
        assign_fleet_number = f.get("assign_fleet_number", "").strip()
        if not data["fleet_number"]:
            data["fleet_number"] = assign_fleet_number  # keep as reference even before/without live assignment

        cols = ", ".join(data.keys())
        placeholders = ", ".join(f":{k}" for k in data.keys())
        cur = db.execute(f"INSERT INTO drivers ({cols}) VALUES ({placeholders})", data)
        db.commit()
        new_id = cur.lastrowid
        log_action(db, g.user["id"], "driver_create", f"driver_id={new_id} fleet={data['fleet_number']}")

        if assign_fleet_number:
            try:
                truck = roster_utils.assign_to_truck(db, new_id, assign_fleet_number, g.user["id"])
                flash(f"Driver {data['first_name']} {data['surname']} added and assigned to truck {truck['fleet_number']}.", "success")
            except ValueError as e:
                flash(f"Driver {data['first_name']} {data['surname']} added, but could not be assigned to a truck: {e}", "warning")
        else:
            flash(f"Driver {data['first_name']} {data['surname']} added to the bench (spare). "
                  f"Assign them to a truck from the Truck Roster when ready.", "success")
        return redirect(url_for("drivers.list_drivers"))
    else:
        # Employment status (active/spare/terminated) is managed from the
        # Truck Roster, not this form, so it isn't touched here.
        data["id"] = driver_id
        set_clause = ", ".join(f"{k} = :{k}" for k in data.keys() if k != "id")
        db.execute(f"UPDATE drivers SET {set_clause}, updated_at = now_text() WHERE id = :id", data)
        db.commit()
        log_action(db, g.user["id"], "driver_update", f"driver_id={driver_id}")
        flash(f"Driver {data['first_name']} {data['surname']} updated.", "success")
        return redirect(url_for("drivers.driver_detail", driver_id=driver_id))


@bp.route("/<int:driver_id>")
def driver_detail(driver_id):
    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id = ?", (driver_id,)).fetchone()
    if driver is None:
        flash("Driver not found.", "danger")
        return redirect(url_for("drivers.list_drivers"))

    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))
    info = contract_info(driver["date_employed"], driver["contract_end_override"],
                          contract_length, leave_per_month,
                          contract_cycle_start=driver["contract_cycle_start"])

    charges = db.execute(
        "SELECT * FROM charges WHERE driver_id = ? ORDER BY date_charged DESC", (driver_id,)
    ).fetchall()

    charges_enriched = []
    for c in charges:
        paid = db.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (c["id"],)
        ).fetchone()["s"]
        charges_enriched.append({"charge": c, "paid": paid, "balance": round(c["total_amount"] - paid, 2)})

    show_salary = g.user["role"] in ("admin", "accountant")
    can_manage_roster = g.user["role"] in ("admin", "hr")
    current_assignment = roster_utils.get_current_assignment_for_driver(db, driver_id)
    truck_history = roster_utils.assignment_history(db, driver_id)
    terminations = db.execute(
        "SELECT * FROM terminations WHERE driver_id = ? ORDER BY termination_date DESC", (driver_id,)
    ).fetchall()

    delete_blockers = _delete_blockers(db, driver_id)

    return render_template("driver_detail.html", driver=driver, contract=info,
                            charges=charges_enriched, can_edit=_can_edit(), show_salary=show_salary,
                            can_manage_roster=can_manage_roster, current_assignment=current_assignment,
                            truck_history=truck_history, terminations=terminations,
                            bench_reasons=roster_utils.BENCH_REASONS, is_admin=(g.user["role"] == "admin"),
                            delete_blockers=delete_blockers)


@bp.route("/<int:driver_id>/delete", methods=["POST"])
def delete_driver(driver_id):
    if g.user["role"] != "admin":
        flash("Only Admin can delete a driver.", "danger")
        return redirect(url_for("drivers.driver_detail", driver_id=driver_id))

    db = get_db()
    driver = db.execute("SELECT * FROM drivers WHERE id = ?", (driver_id,)).fetchone()
    if driver is None:
        flash("Driver not found.", "danger")
        return redirect(url_for("drivers.list_drivers"))

    blockers = _delete_blockers(db, driver_id)
    if blockers:
        flash(
            f"Can't delete {driver['first_name']} {driver['surname']}: they have "
            + ", ".join(blockers) + ". This driver has real history and shouldn't be removed -- "
            "if they've left the company, use Terminate instead. If this is genuinely a duplicate "
            "entry, you'll need to resolve/cancel the charge(s) and remove the finalized payroll "
            "line(s) first.",
            "danger",
        )
        return redirect(url_for("drivers.driver_detail", driver_id=driver_id))

    # Safe to delete: only draft-run payroll lines and/or truck-assignment
    # history exist (if anything) -- neither is "final" yet, so cascade them
    # away along with the driver record itself.
    draft_lines = db.execute(
        "SELECT COUNT(*) c FROM payroll_lines pl JOIN payroll_runs pr ON pr.id = pl.run_id "
        "WHERE pl.driver_id = ? AND pr.status = 'draft'", (driver_id,)
    ).fetchone()["c"]
    assignment_count = db.execute(
        "SELECT COUNT(*) c FROM truck_assignments WHERE driver_id = ?", (driver_id,)
    ).fetchone()["c"]

    db.execute(
        "DELETE FROM payroll_lines WHERE driver_id = ? AND run_id IN "
        "(SELECT id FROM payroll_runs WHERE status = 'draft')", (driver_id,)
    )
    db.execute("DELETE FROM truck_assignments WHERE driver_id = ?", (driver_id,))
    db.execute("DELETE FROM drivers WHERE id = ?", (driver_id,))
    db.commit()

    log_action(
        db, g.user["id"], "driver_delete",
        f"driver_id={driver_id} name={driver['first_name']} {driver['surname']} "
        f"fleet={driver['fleet_number']} draft_payroll_lines_removed={draft_lines} "
        f"truck_assignments_removed={assignment_count}",
    )
    flash(
        f"{driver['first_name']} {driver['surname']} permanently deleted."
        + (f" Also removed {draft_lines} draft payroll line(s) and {assignment_count} "
           f"truck assignment record(s) that referenced them." if (draft_lines or assignment_count) else ""),
        "success",
    )
    return redirect(url_for("drivers.list_drivers"))
