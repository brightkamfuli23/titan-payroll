import datetime
from flask import Blueprint, render_template, g
from db import get_db, get_setting_float
from utils.contract import contract_info

bp = Blueprint("dashboard", __name__, url_prefix="/")


@bp.route("/")
def index():
    db = get_db()
    counts = {}
    for status in ("active", "spare", "terminated"):
        counts[status] = db.execute(
            "SELECT COUNT(*) c FROM drivers WHERE status=?", (status,)
        ).fetchone()["c"]

    latest_run = db.execute(
        "SELECT * FROM payroll_runs ORDER BY period_year DESC, period_month DESC LIMIT 1"
    ).fetchone()
    latest_totals = None
    if latest_run:
        latest_totals = db.execute(
            "SELECT COALESCE(SUM(gross_pay),0) gross, COALESCE(SUM(payable),0) net, COUNT(*) cnt "
            "FROM payroll_lines WHERE run_id = ?",
            (latest_run["id"],),
        ).fetchone()

    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))
    alert_days = int(float(get_setting_float(db, "expiring_contract_alert_days", 30)))

    active_drivers = db.execute("SELECT * FROM drivers WHERE status='active'").fetchall()
    expired_count = 0
    expiring_soon = []
    today = datetime.date.today()
    for d in active_drivers:
        info = contract_info(d["date_employed"], d["contract_end_override"], contract_length, leave_per_month)
        if info["status"] == "Expired":
            expired_count += 1
        if info["expected_end"]:
            end_date = datetime.date.fromisoformat(info["expected_end"])
            days_left = (end_date - today).days
            if 0 <= days_left <= alert_days:
                expiring_soon.append((d, end_date, days_left))
    expiring_soon.sort(key=lambda x: x[2])

    open_charges = db.execute(
        "SELECT COUNT(*) c, COALESCE(SUM(total_amount - COALESCE((SELECT SUM(amount) FROM charge_deductions WHERE charge_id=charges.id),0)),0) bal "
        "FROM charges WHERE status='open'"
    ).fetchone()

    unassigned_active = db.execute(
        """SELECT COUNT(*) c FROM drivers d
           WHERE d.status='active' AND d.id NOT IN
             (SELECT driver_id FROM truck_assignments WHERE end_date IS NULL)"""
    ).fetchone()["c"]
    vacant_trucks = db.execute(
        """SELECT COUNT(*) c FROM trucks t
           WHERE t.id NOT IN (SELECT truck_id FROM truck_assignments WHERE end_date IS NULL)"""
    ).fetchone()["c"]

    return render_template(
        "dashboard.html", counts=counts, latest_run=latest_run, latest_totals=latest_totals,
        expired_count=expired_count, expiring_soon=expiring_soon, open_charges=open_charges,
        role=g.user["role"], unassigned_active=unassigned_active, vacant_trucks=vacant_trucks,
    )
