import calendar
from flask import (Blueprint, render_template, request, redirect, url_for, flash, g,
                    send_file, abort)
from db import get_db, log_action, get_setting_json, get_setting_float
from utils.payroll_calc import PayrollInputs, compute_payroll_line, default_days_attended, pay_cycle_bounds
from utils.terminal_dues import contract_due_status, contract_settings as _fetch_contract_settings
from utils.contract import contract_info
from utils import payslip_pdf, bank_export, statutory_reports, summary_report, payroll_register, backup

bp = Blueprint("payroll", __name__, url_prefix="/payroll")

MONTH_NAMES = list(calendar.month_name)


def _admin_only():
    return g.user["role"] == "admin"


def _get_rates(db):
    return {
        "paye_bands": get_setting_json(db, "paye_bands"),
        "napsa_rate": get_setting_float(db, "napsa_rate"),
        "napsa_ceiling": get_setting_float(db, "napsa_ceiling"),
        "nhima_rate": get_setting_float(db, "nhima_rate"),
        "housing_pct": get_setting_float(db, "housing_pct"),
    }


@bp.route("/")
def list_runs():
    if g.user["role"] not in ("admin", "accountant"):
        abort(403)
    db = get_db()
    runs = db.execute(
        "SELECT * FROM payroll_runs WHERE deleted_at IS NULL ORDER BY period_year DESC, period_month DESC"
    ).fetchall()
    totals = {}
    for r in runs:
        t = db.execute(
            "SELECT COALESCE(SUM(payable),0) s, COUNT(*) c FROM payroll_lines WHERE run_id = ?",
            (r["id"],),
        ).fetchone()
        totals[r["id"]] = {"total": t["s"], "count": t["c"]}
    archived_count = db.execute(
        "SELECT COUNT(*) c FROM payroll_runs WHERE deleted_at IS NOT NULL"
    ).fetchone()["c"]
    return render_template("payroll_list.html", runs=runs, totals=totals, is_admin=_admin_only(),
                            archived_count=archived_count)


@bp.route("/archived")
def archived_runs():
    if not _admin_only():
        abort(403)
    db = get_db()
    runs = db.execute(
        """SELECT pr.*, u.full_name as deleted_by_name
           FROM payroll_runs pr LEFT JOIN users u ON u.id = pr.deleted_by
           WHERE pr.deleted_at IS NOT NULL ORDER BY pr.deleted_at DESC"""
    ).fetchall()
    totals = {}
    for r in runs:
        t = db.execute(
            "SELECT COALESCE(SUM(payable),0) s, COUNT(*) c FROM payroll_lines WHERE run_id = ?",
            (r["id"],),
        ).fetchone()
        totals[r["id"]] = {"total": t["s"], "count": t["c"]}
    return render_template("payroll_archived.html", runs=runs, totals=totals)


@bp.route("/new", methods=["GET", "POST"])
def new_run():
    if not _admin_only():
        flash("Only Admin can start a new payroll run.", "danger")
        return redirect(url_for("payroll.list_runs"))
    db = get_db()
    if request.method == "POST":
        year = int(request.form["year"])
        month = int(request.form["month"])
        label = f"{MONTH_NAMES[month]} {year}"

        existing = db.execute(
            "SELECT id FROM payroll_runs WHERE period_year=? AND period_month=? AND deleted_at IS NULL",
            (year, month),
        ).fetchone()
        if existing:
            flash(f"A payroll run for {label} already exists.", "warning")
            return redirect(url_for("payroll.run_detail", run_id=existing["id"]))

        cur = db.execute(
            "INSERT INTO payroll_runs (period_year, period_month, period_label, created_by) "
            "VALUES (?, ?, ?, ?)",
            (year, month, label, g.user["id"]),
        )
        db.commit()
        run_id = cur.lastrowid

        # Bench (spare) drivers are included by default -- someone on the
        # bench for a legitimate reason (sick leave, resting between
        # trucks, etc.) is still an employee and still gets paid. If
        # someone on the bench shouldn't be paid this month (e.g. they've
        # exceeded their leave without communication), remove them from
        # this run manually below and process them through Termination on
        # the Truck Roster instead.
        drivers = db.execute(
            "SELECT * FROM drivers WHERE status IN ('active', 'spare') ORDER BY surname"
        ).fetchall()
        active_count = sum(1 for d in drivers if d["status"] == "active")
        bench_count = sum(1 for d in drivers if d["status"] == "spare")
        rates = _get_rates(db)

        # Leave/gratuity pre-fill (contract_due_status, per driver) used to
        # issue 3 settings queries + a leave-taken query + (for anyone whose
        # contract has expired) a basic-pay JOIN query -- EVERY time it was
        # called. That's fine for a one-off Termination lookup, but across
        # this roster's 264 active + 13 spare = 277 drivers it meant 1,000+
        # extra sequential DB round-trips per run, enough to blow past
        # gunicorn's 30s worker timeout ("Internal server error"). Fetch all
        # of that once here instead, and pass it down to every driver. Both
        # the gratuity basic-pay window and the leave window need the same
        # per-driver payroll history (period + basic_salary + leave_days),
        # so one batched query now covers both.
        settings = _fetch_contract_settings(db)
        payroll_rows_by_driver = {}
        for row in db.execute(
            """SELECT pl.driver_id, pr.period_year, pr.period_month, pl.basic_salary, pl.leave_days
               FROM payroll_lines pl JOIN payroll_runs pr ON pr.id = pl.run_id"""
        ).fetchall():
            payroll_rows_by_driver.setdefault(row["driver_id"], []).append(row)

        for d in drivers:
            _create_line_for_driver(db, run_id, d, rates, year, month, settings=settings,
                                     payroll_rows_by_driver=payroll_rows_by_driver)
        db.commit()
        log_action(db, g.user["id"], "payroll_run_create",
                   f"run_id={run_id} label={label} drivers={len(drivers)} "
                   f"(active={active_count} bench={bench_count})")
        flash(f"Payroll run for {label} created with {len(drivers)} drivers "
              f"({active_count} on truck, {bench_count} on bench). Remove anyone "
              f"who shouldn't be paid this run individually below.", "success")
        return redirect(url_for("payroll.run_detail", run_id=run_id))

    return render_template("payroll_new.html", month_names=MONTH_NAMES)


def _create_line_for_driver(db, run_id, driver, rates, period_year, period_month,
                             settings=None, payroll_rows_by_driver=None):
    # Food/transport allowances are NOT uniform across drivers (transport in
    # particular varies a lot by route -- long-haul drivers get materially
    # more than local-route drivers). Use this driver's own standing
    # allowance (set on their Driver record, editable from the Edit Driver
    # page), falling back to the company-wide default only if it's missing.
    food = driver["food_allowance"] if driver["food_allowance"] is not None else get_setting_float(db, "default_food_allowance", 180)
    transport_full = driver["transport_full"] if driver["transport_full"] is not None else get_setting_float(db, "default_transport_full", 200)

    # suggested charge deduction from any open charges ledger balance
    charge_amt, _charge_rows = _suggested_charge_deduction(db, driver["id"])

    work_days = driver["work_days"] or 26
    # Full month by default; a driver who started *during* this run's
    # calendar month gets counted from their actual start date instead,
    # excluding Sundays -- same as everything else here, still editable
    # afterwards if it needs adjusting.
    suggested_days_attended = default_days_attended(driver["date_employed"], period_year, period_month, work_days)

    # Leave Balance is always computed and stored (read-only display of the
    # driver's total accrued-but-untaken leave days as of this run's pay
    # cycle end). Leave Days (the amount actually being paid out this run)
    # and Gratuity are only pre-filled when the driver's contract has
    # expired as of this run -- see utils.terminal_dues.contract_due_status.
    # Both remain ordinary editable fields on the run either way.
    _cycle_start, cycle_end = pay_cycle_bounds(period_year, period_month)
    payroll_rows = None if payroll_rows_by_driver is None else payroll_rows_by_driver.get(driver["id"], [])
    due = contract_due_status(db, driver, cycle_end, settings=settings, payroll_rows=payroll_rows)
    leave_balance = due["leave_days_owing"]
    suggested_leave_days = leave_balance if due["is_due"] else 0.0
    suggested_gratuity = due["gratuity_amount"] if due["is_due"] else 0.0

    inp = PayrollInputs(
        basic_salary=driver["basic_salary"],
        work_days=work_days,
        days_attended=suggested_days_attended,
        housing_pct=rates["housing_pct"],
        food=food,
        transport=transport_full,
        leave_days=suggested_leave_days,
        gratuity=suggested_gratuity,
        charge_deduction=charge_amt,
        zambian_statutory=driver["zambian_statutory"] if driver["zambian_statutory"] is not None else True,
    )
    res = compute_payroll_line(inp, rates["paye_bands"], rates["napsa_rate"],
                                rates["napsa_ceiling"], rates["nhima_rate"])

    db.execute(
        """INSERT INTO payroll_lines
           (run_id, driver_id, basic_salary, work_days, days_attended, daily_pay, salary,
            housing, food, transport, leave_days, leave_pay, leave_balance, salary_backpay, gratuity,
            bonus_other, advance, gross_pay, nhima, napsa, paye, charge_deduction, payable)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (run_id, driver["id"], inp.basic_salary, inp.work_days, inp.days_attended, res.daily_pay,
         res.salary, res.housing, inp.food, inp.transport, inp.leave_days, res.leave_pay, leave_balance,
         0, inp.gratuity, 0, 0, res.gross_pay, res.nhima, res.napsa, res.paye, charge_amt, res.payable),
    )


def _suggested_charge_deduction(db, driver_id):
    """Sum the installment amounts of a driver's open charges, capped at
    the remaining balance of each charge."""
    open_charges = db.execute(
        "SELECT * FROM charges WHERE driver_id = ? AND status = 'open'", (driver_id,)
    ).fetchall()
    total = 0.0
    rows = []
    for c in open_charges:
        paid = db.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (c["id"],)
        ).fetchone()["s"]
        balance = round(c["total_amount"] - paid, 2)
        if balance <= 0:
            continue
        installment = min(c["installment_amount"], balance)
        total += installment
        rows.append((c["id"], installment))
    return round(total, 2), rows


@bp.route("/<int:run_id>")
def run_detail(run_id):
    if g.user["role"] not in ("admin", "accountant"):
        abort(403)
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    lines = db.execute(
        """SELECT pl.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number,
                  d.surname, d.first_name, d.bank_name, d.account_no, d.status as driver_status
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE pl.run_id = ? ORDER BY d.surname, d.first_name""",
        (run_id,),
    ).fetchall()

    totals = db.execute(
        """SELECT COALESCE(SUM(gross_pay),0) gross, COALESCE(SUM(payable),0) net,
                  COALESCE(SUM(nhima),0) nhima, COALESCE(SUM(napsa),0) napsa,
                  COALESCE(SUM(paye),0) paye, COALESCE(SUM(charge_deduction),0) charges,
                  COUNT(*) cnt
           FROM payroll_lines WHERE run_id = ?""",
        (run_id,),
    ).fetchone()

    show_salary = g.user["role"] in ("admin", "accountant")
    can_edit = _admin_only() and run["status"] == "draft" and not run["deleted_at"]
    rates = _get_rates(db)
    cycle_start, cycle_end = pay_cycle_bounds(run["period_year"], run["period_month"])

    deleted_by_name = None
    if run["deleted_at"] and run["deleted_by"]:
        u = db.execute("SELECT full_name FROM users WHERE id = ?", (run["deleted_by"],)).fetchone()
        deleted_by_name = u["full_name"] if u else None

    return render_template("payroll_run.html", run=run, lines=lines, totals=totals,
                            can_edit=can_edit, show_salary=show_salary, is_admin=_admin_only(),
                            rates=rates, cycle_start=cycle_start, cycle_end=cycle_end,
                            deleted_by_name=deleted_by_name)


@bp.route("/<int:run_id>/save", methods=["POST"])
def save_run(run_id):
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    if not _admin_only() or run["status"] != "draft" or run["deleted_at"]:
        flash("This payroll run can no longer be edited.", "danger")
        return redirect(url_for("payroll.run_detail", run_id=run_id))

    rates = _get_rates(db)
    lines = db.execute(
        """SELECT pl.*, d.zambian_statutory AS driver_zambian_statutory
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           WHERE pl.run_id = ?""",
        (run_id,),
    ).fetchall()

    for line in lines:
        prefix = f"line_{line['id']}_"
        try:
            days_attended = float(request.form.get(prefix + "days_attended", line["days_attended"]))
            leave_days = float(request.form.get(prefix + "leave_days", 0) or 0)
            salary_backpay = float(request.form.get(prefix + "salary_backpay", 0) or 0)
            gratuity = float(request.form.get(prefix + "gratuity", 0) or 0)
            bonus_other = float(request.form.get(prefix + "bonus_other", 0) or 0)
            advance = float(request.form.get(prefix + "advance", 0) or 0)
            food = float(request.form.get(prefix + "food", line["food"]) or 0)
            transport = float(request.form.get(prefix + "transport", line["transport"]) or 0)
            charge_deduction = float(request.form.get(prefix + "charge_deduction", line["charge_deduction"]) or 0)
        except ValueError:
            flash("Please enter valid numbers for all fields.", "danger")
            return redirect(url_for("payroll.run_detail", run_id=run_id))
        comments = request.form.get(prefix + "comments", "")

        inp = PayrollInputs(
            basic_salary=line["basic_salary"],
            work_days=line["work_days"],
            days_attended=days_attended,
            housing_pct=rates["housing_pct"],
            food=food,
            transport=transport,
            leave_days=leave_days,
            salary_backpay=salary_backpay,
            gratuity=gratuity,
            bonus_other=bonus_other,
            advance=advance,
            charge_deduction=charge_deduction,
            zambian_statutory=line["driver_zambian_statutory"] if line["driver_zambian_statutory"] is not None else True,
        )
        res = compute_payroll_line(inp, rates["paye_bands"], rates["napsa_rate"],
                                    rates["napsa_ceiling"], rates["nhima_rate"])

        db.execute(
            """UPDATE payroll_lines SET days_attended=?, daily_pay=?, salary=?, housing=?,
               food=?, transport=?, leave_days=?, leave_pay=?, salary_backpay=?, gratuity=?,
               bonus_other=?, advance=?, gross_pay=?, nhima=?, napsa=?, paye=?,
               charge_deduction=?, payable=?, comments=? WHERE id=?""",
            (days_attended, res.daily_pay, res.salary, res.housing, food, transport,
             leave_days, res.leave_pay, salary_backpay, gratuity, bonus_other, advance,
             res.gross_pay, res.nhima, res.napsa, res.paye, charge_deduction, res.payable,
             comments, line["id"]),
        )

    db.commit()
    log_action(db, g.user["id"], "payroll_run_save", f"run_id={run_id}")
    flash("Payroll run recalculated and saved.", "success")
    return redirect(url_for("payroll.run_detail", run_id=run_id))


@bp.route("/<int:run_id>/add_driver", methods=["POST"])
def add_driver(run_id):
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None or not _admin_only() or run["status"] != "draft" or run["deleted_at"]:
        abort(403)
    driver_id = int(request.form["driver_id"])
    exists = db.execute(
        "SELECT id FROM payroll_lines WHERE run_id=? AND driver_id=?", (run_id, driver_id)
    ).fetchone()
    if exists:
        flash("That driver is already on this payroll run.", "warning")
        return redirect(url_for("payroll.run_detail", run_id=run_id))
    driver = db.execute("SELECT * FROM drivers WHERE id = ?", (driver_id,)).fetchone()
    if driver is None:
        abort(404)
    rates = _get_rates(db)
    _create_line_for_driver(db, run_id, driver, rates, run["period_year"], run["period_month"])
    db.commit()
    flash(f"{driver['first_name']} {driver['surname']} added to this payroll run.", "success")
    return redirect(url_for("payroll.run_detail", run_id=run_id))


@bp.route("/<int:run_id>/remove_line/<int:line_id>", methods=["POST"])
def remove_line(run_id, line_id):
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None or not _admin_only() or run["status"] != "draft" or run["deleted_at"]:
        abort(403)
    db.execute("DELETE FROM payroll_lines WHERE id=? AND run_id=?", (line_id, run_id))
    db.commit()
    flash("Driver removed from this payroll run.", "success")
    return redirect(url_for("payroll.run_detail", run_id=run_id))


@bp.route("/<int:run_id>/delete", methods=["POST"])
def delete_run(run_id):
    if not _admin_only():
        flash("Only Admin can delete a payroll run.", "danger")
        return redirect(url_for("payroll.run_detail", run_id=run_id))
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    if run["deleted_at"]:
        flash(f"The {run['period_label']} payroll run is already archived.", "warning")
        return redirect(url_for("payroll.archived_runs"))

    totals = db.execute(
        "SELECT COUNT(*) c, COALESCE(SUM(payable),0) s FROM payroll_lines WHERE run_id = ?",
        (run_id,),
    ).fetchone()

    # "Delete" archives the run rather than erasing it -- nothing here is
    # removed, only hidden. deleted_at/deleted_by mark it archived, and the
    # partial unique index on (period_year, period_month) means this
    # immediately frees up the period for a fresh run, exactly like a real
    # delete used to. Because payroll_lines and charge_deductions are left
    # completely untouched, no charges need reopening the way the old
    # cascade-delete required -- restoring this run later would put
    # everything back exactly as it was.
    db.execute(
        "UPDATE payroll_runs SET deleted_at=now_text(), deleted_by=? WHERE id=?",
        (g.user["id"], run_id),
    )
    db.commit()
    log_action(
        db, g.user["id"], "payroll_run_archive",
        f"run_id={run_id} label={run['period_label']} status={run['status']} "
        f"drivers={totals['c']} total_payable={totals['s']}",
    )
    flash(f"Payroll run for {run['period_label']} archived — its figures are safely kept and can be "
          f"restored any time from Archived Runs.", "success")
    return redirect(url_for("payroll.list_runs"))


@bp.route("/<int:run_id>/restore", methods=["POST"])
def restore_run(run_id):
    if not _admin_only():
        flash("Only Admin can restore an archived payroll run.", "danger")
        return redirect(url_for("payroll.archived_runs"))
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    if not run["deleted_at"]:
        flash(f"The {run['period_label']} payroll run isn't archived.", "warning")
        return redirect(url_for("payroll.run_detail", run_id=run_id))

    conflict = db.execute(
        "SELECT id FROM payroll_runs WHERE period_year=? AND period_month=? AND deleted_at IS NULL AND id != ?",
        (run["period_year"], run["period_month"], run_id),
    ).fetchone()
    if conflict:
        flash(f"Can't restore {run['period_label']} — there's already an active payroll run for that "
              f"period. Archive or delete that one first, then restore this one.", "danger")
        return redirect(url_for("payroll.archived_runs"))

    db.execute("UPDATE payroll_runs SET deleted_at=NULL, deleted_by=NULL WHERE id=?", (run_id,))
    db.commit()
    log_action(db, g.user["id"], "payroll_run_restore", f"run_id={run_id} label={run['period_label']}")
    flash(f"Payroll run for {run['period_label']} restored, with all its figures exactly as they were.",
          "success")
    return redirect(url_for("payroll.run_detail", run_id=run_id))


@bp.route("/<int:run_id>/purge", methods=["POST"])
def purge_run(run_id):
    """Permanently delete an ARCHIVED, still-DRAFT payroll run and all its lines.

    Unlike Archive (which only hides a run and keeps every figure), this really
    erases it -- so it is deliberately hard to do by accident:
      * Admin only.
      * The run must already be archived (archive first, purge second).
      * Finalized runs can never be purged -- they are the permanent pay record,
        and finalizing already paid charges / reset contract cycles that a delete
        could not undo. Only drafts (nothing posted yet) can be erased.
      * The admin must type the run's period label to confirm.
    """
    if not _admin_only():
        flash("Only Admin can permanently delete a payroll run.", "danger")
        return redirect(url_for("payroll.archived_runs"))
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    if not run["deleted_at"]:
        flash(f"The {run['period_label']} payroll run isn't archived. Archive it first, then delete it "
              f"permanently from Archived Runs.", "warning")
        return redirect(url_for("payroll.run_detail", run_id=run_id))
    if run["status"] == "finalized":
        flash(f"The {run['period_label']} payroll run is finalized and can't be permanently deleted -- "
              f"finalized runs are the permanent pay record. It stays safely archived.", "danger")
        return redirect(url_for("payroll.archived_runs"))

    typed = (request.form.get("confirm_label") or "").strip().lower()
    if typed != (run["period_label"] or "").strip().lower():
        flash(f"Not deleted -- the period name you typed didn't match \"{run['period_label']}\".", "danger")
        return redirect(url_for("payroll.archived_runs"))

    totals = db.execute(
        "SELECT COUNT(*) c, COALESCE(SUM(payable),0) s, COALESCE(SUM(gross_pay),0) g "
        "FROM payroll_lines WHERE run_id = ?", (run_id,),
    ).fetchone()
    # Explicit deletes (the FKs also cascade) so it is clear exactly what goes.
    db.execute("DELETE FROM charge_deductions WHERE run_id = ?", (run_id,))
    db.execute("DELETE FROM payroll_lines WHERE run_id = ?", (run_id,))
    db.execute("DELETE FROM payroll_runs WHERE id = ?", (run_id,))
    db.commit()
    log_action(
        db, g.user["id"], "payroll_run_purge",
        f"run_id={run_id} label={run['period_label']} status={run['status']} "
        f"drivers={totals['c']} total_gross={totals['g']} total_payable={totals['s']} (permanently deleted)",
    )
    flash(f"Payroll run for {run['period_label']} permanently deleted ({totals['c']} driver lines removed).",
          "success")
    return redirect(url_for("payroll.archived_runs"))


@bp.route("/<int:run_id>/finalize", methods=["POST"])
def finalize_run(run_id):
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    if not _admin_only():
        flash("Only Admin can finalize a payroll run.", "danger")
        return redirect(url_for("payroll.run_detail", run_id=run_id))
    if run["status"] == "finalized":
        flash("This payroll run is already finalized.", "warning")
        return redirect(url_for("payroll.run_detail", run_id=run_id))
    if run["deleted_at"]:
        flash("This payroll run is archived and can't be finalized. Restore it first.", "danger")
        return redirect(url_for("payroll.run_detail", run_id=run_id))

    lines = db.execute("SELECT * FROM payroll_lines WHERE run_id = ?", (run_id,)).fetchall()
    for line in lines:
        if line["charge_deduction"] <= 0:
            continue
        _, charge_rows = _suggested_charge_deduction(db, line["driver_id"])
        remaining = line["charge_deduction"]
        for charge_id, installment in charge_rows:
            if remaining <= 0:
                break
            amt = min(installment, remaining)
            db.execute(
                "INSERT INTO charge_deductions (charge_id, run_id, amount) VALUES (?,?,?) "
                "ON CONFLICT (charge_id, run_id) DO UPDATE SET amount = excluded.amount",
                (charge_id, run_id, amt),
            )
            remaining -= amt
            paid = db.execute(
                "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (charge_id,)
            ).fetchone()["s"]
            charge = db.execute("SELECT * FROM charges WHERE id = ?", (charge_id,)).fetchone()
            if paid >= charge["total_amount"] - 0.01:
                db.execute("UPDATE charges SET status='paid' WHERE id=?", (charge_id,))

    # A paid gratuity line settles that driver's contract term -- per the
    # client's direction, finalizing a run with a paid gratuity auto-renews
    # that driver (resets contract_cycle_start to this run's cycle end) so
    # next month's run doesn't suggest the same gratuity again. This
    # supersedes the old "nothing paid out at renewal" policy specifically
    # for drivers settled this way; a manual gratuity entered for a driver
    # whose contract isn't actually due (e.g. a bonus) is left alone.
    _cycle_start, cycle_end = pay_cycle_bounds(run["period_year"], run["period_month"])
    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))
    renewed_count = 0
    for line in lines:
        if line["gratuity"] <= 0:
            continue
        driver = db.execute("SELECT * FROM drivers WHERE id = ?", (line["driver_id"],)).fetchone()
        if driver is None:
            continue
        info = contract_info(driver["date_employed"], driver["contract_end_override"],
                              contract_length, leave_per_month, today=cycle_end,
                              contract_cycle_start=driver["contract_cycle_start"])
        if info["status"] != "Expired":
            continue
        # The new cycle starts on the driver's own actual contract-cycle
        # boundary (info["expected_end"] -- exactly contract_length months
        # after their last cycle_start), NOT on cycle_end (this payroll
        # run's period-end date). Per the client's confirmed policy
        # (2026-08-21), a renewal always anchors to the driver's real start
        # date, not to whenever payroll happened to be run -- otherwise a
        # driver whose contract actually completed on, say, June 1st would
        # get their new term dated to August 31st just because that's when
        # this run was processed.
        db.execute(
            "UPDATE drivers SET contract_cycle_start=?, updated_at=now_text() WHERE id=?",
            (info["expected_end"], driver["id"]),
        )
        renewed_count += 1

    if renewed_count:
        log_action(db, g.user["id"], "payroll_auto_renew",
                   f"run_id={run_id} renewed={renewed_count} (contract cycle reset after paid gratuity)")

    db.execute(
        "UPDATE payroll_runs SET status='finalized', finalized_at=now_text(), finalized_by=? WHERE id=?",
        (g.user["id"], run_id),
    )
    db.commit()
    log_action(db, g.user["id"], "payroll_run_finalize", f"run_id={run_id}")

    # A finalized payroll run is the most important checkpoint to never
    # lose -- snapshot the whole database automatically right after.
    try:
        backup.make_backup(tag=f"finalized_{run['period_label'].replace(' ', '_')}")
    except Exception as e:
        # Never block finalization on a backup failure -- manual backup is
        # still available from Settings -- but record it so Admin notices.
        log_action(db, g.user["id"], "backup_failed", f"run_id={run_id} error={e}")

    flash(f"Payroll run for {run['period_label']} finalized. Charge deductions posted to the ledger."
          + (f" {renewed_count} driver contract(s) auto-renewed after paid gratuity." if renewed_count else ""),
          "success")
    return redirect(url_for("payroll.run_detail", run_id=run_id))


# ---------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------

@bp.route("/<int:run_id>/payslips.zip")
def payslips_zip(run_id):
    if g.user["role"] not in ("admin", "accountant"):
        abort(403)
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    buf = payslip_pdf.build_all_payslips_zip(db, run)
    log_action(db, g.user["id"], "payslips_download", f"run_id={run_id}")
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                      download_name=f"Payslips_{run['period_label'].replace(' ', '_')}.zip")


@bp.route("/<int:run_id>/payslip/<int:driver_id>.pdf")
def single_payslip(run_id, driver_id):
    if g.user["role"] not in ("admin", "accountant"):
        abort(403)
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    buf, filename = payslip_pdf.build_single_payslip(db, run, driver_id)
    if buf is None:
        abort(404)
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name=filename)


@bp.route("/<int:run_id>/bank_file.xlsx")
def bank_file(run_id):
    db = get_db()
    if g.user["role"] not in ("admin", "accountant"):
        abort(403)
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    buf = bank_export.build_bank_file(db, run)
    log_action(db, g.user["id"], "bank_file_download", f"run_id={run_id}")
    return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                      as_attachment=True,
                      download_name=f"Bank_Payment_File_{run['period_label'].replace(' ', '_')}.xlsx")


@bp.route("/<int:run_id>/statutory.xlsx")
def statutory(run_id):
    db = get_db()
    if g.user["role"] not in ("admin", "accountant"):
        abort(403)
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    buf = statutory_reports.build_statutory_workbook(db, run)
    log_action(db, g.user["id"], "statutory_report_download", f"run_id={run_id}")
    return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                      as_attachment=True,
                      download_name=f"Statutory_Reports_{run['period_label'].replace(' ', '_')}.xlsx")


@bp.route("/<int:run_id>/summary.xlsx")
def summary(run_id):
    db = get_db()
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    buf = summary_report.build_summary_workbook(db, run)
    log_action(db, g.user["id"], "summary_report_download", f"run_id={run_id}")
    return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                      as_attachment=True,
                      download_name=f"Management_Summary_{run['period_label'].replace(' ', '_')}.xlsx")


@bp.route("/<int:run_id>/register.xlsx")
def register(run_id):
    db = get_db()
    if g.user["role"] not in ("admin", "accountant"):
        abort(403)
    run = db.execute("SELECT * FROM payroll_runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        abort(404)
    buf = payroll_register.build_payroll_register(db, run)
    log_action(db, g.user["id"], "payroll_register_download", f"run_id={run_id}")
    status_tag = "FINAL" if run["status"] == "finalized" else "DRAFT"
    return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                      as_attachment=True,
                      download_name=f"Payroll_Register_{status_tag}_{run['period_label'].replace(' ', '_')}.xlsx")
