from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort
from werkzeug.security import generate_password_hash
from db import get_db, log_action

bp = Blueprint("users", __name__, url_prefix="/users")


@bp.route("/")
def list_users():
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()
    users = db.execute("SELECT * FROM users ORDER BY role, username").fetchall()
    return render_template("users_list.html", users=users)


@bp.route("/new", methods=["GET", "POST"])
def new_user():
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        full_name = request.form.get("full_name", "").strip()
        role = request.form.get("role", "accountant")
        password = request.form.get("password", "")

        error = None
        if not username or not full_name or not password:
            error = "Username, full name and password are required."
        elif role not in ("admin", "hr", "accountant"):
            error = "Invalid role."
        elif db.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
            error = "That username is already taken."
        elif len(password) < 8:
            error = "Password must be at least 8 characters."

        if error:
            flash(error, "danger")
            return render_template("user_form.html")

        db.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)",
            (username, generate_password_hash(password), full_name, role),
        )
        db.commit()
        log_action(db, g.user["id"], "user_create", f"username={username} role={role}")
        flash(f"User {username} created.", "success")
        return redirect(url_for("users.list_users"))

    return render_template("user_form.html")


@bp.route("/<int:user_id>/toggle", methods=["POST"])
def toggle_user(user_id):
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()
    if user_id == g.user["id"]:
        flash("You can't deactivate your own account.", "warning")
        return redirect(url_for("users.list_users"))
    user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if user is None:
        abort(404)
    new_state = 0 if user["active"] else 1
    db.execute("UPDATE users SET active=? WHERE id=?", (new_state, user_id))
    db.commit()
    log_action(db, g.user["id"], "user_toggle", f"user_id={user_id} active={new_state}")
    flash(f"User {user['username']} {'activated' if new_state else 'deactivated'}.", "success")
    return redirect(url_for("users.list_users"))


@bp.route("/<int:user_id>/reset_password", methods=["GET", "POST"])
def reset_password(user_id):
    if g.user["role"] != "admin":
        abort(403)
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if user is None:
        abort(404)
    if request.method == "POST":
        password = request.form.get("password", "")
        if len(password) < 8:
            flash("Password must be at least 8 characters.", "danger")
            return render_template("reset_password.html", user=user)
        db.execute("UPDATE users SET password_hash=? WHERE id=?",
                   (generate_password_hash(password), user_id))
        db.commit()
        log_action(db, g.user["id"], "user_reset_password", f"user_id={user_id}")
        flash(f"Password reset for {user['username']}.", "success")
        return redirect(url_for("users.list_users"))
    return render_template("reset_password.html", user=user)
