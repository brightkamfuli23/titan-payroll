import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
EXPORTS_DIR = os.path.join(BASE_DIR, "exports")
BACKUPS_DIR = os.path.join(BASE_DIR, "backups")

os.makedirs(EXPORTS_DIR, exist_ok=True)
os.makedirs(BACKUPS_DIR, exist_ok=True)

# The database now lives in Supabase (Postgres), not a local SQLite file --
# set this to your Supabase project's connection string. In local dev you can
# put it in a .env file / export it in your shell; on Render it's set as an
# environment variable on the web service.
DATABASE_URL = os.environ.get("DATABASE_URL", "")

SECRET_KEY = os.environ.get("PAYROLL_SECRET_KEY")
if not SECRET_KEY:
    if os.environ.get("RENDER") or os.environ.get("DATABASE_URL"):
        # Running somewhere internet-facing (Render, or any environment with
        # DATABASE_URL set) -- never fall back to a guessable default here.
        raise RuntimeError(
            "PAYROLL_SECRET_KEY environment variable is not set. Generate one "
            "(e.g. `python3 -c \"import secrets; print(secrets.token_hex(32))\"`) "
            "and set it before starting the app."
        )
    # Plain local/offline run with no DATABASE_URL configured yet (e.g. first
    # time following the README) -- fine to use a placeholder so the app still
    # boots for local exploration.
    SECRET_KEY = "titan-gateway-logistics-change-this-secret-key"

COMPANY_NAME = "TITAN GATEWAY LOGISTICS LIMITED"
CURRENCY = "ZMW"

# ---------------------------------------------------------------------------
# Default statutory rates for Zambia, verified against the 2026 national
# budget (unchanged from 2025) and current NAPSA/NHIMA regulations as of
# August 2026. These are seeded into the `settings` table on first run and
# can be edited from the Settings screen in the app WITHOUT touching code,
# so next year's budget changes don't require a developer.
#
# Sources checked during setup (see README "Statutory rates" section):
#  - PAYE bands: KPMG/UNDP Zambia 2026 National Budget Highlights
#  - NAPSA ceiling: NAPSA public notice effective 1 Jan 2026 (K37,236/month,
#    5% each side, capped at K1,861.80 each)
#  - NHIMA: 1% of basic pay, employee and employer each, no ceiling
# ---------------------------------------------------------------------------
DEFAULT_SETTINGS = {
    # PAYE monthly bands: list of [lower_bound, upper_bound_or_None, rate]
    "paye_bands": "[[0,5100,0.0],[5100,7100,0.20],[7100,9200,0.30],[9200,null,0.37]]",
    "napsa_rate": "0.05",
    "napsa_ceiling": "37236",           # insurable earnings ceiling per month
    "nhima_rate": "0.01",
    "housing_pct": "0.30",              # housing allowance = 30% of salary
    "default_food_allowance": "180",
    "default_transport_full": "200",
    "default_transport_partial": "156",
    "default_work_days": "26",
    "leave_days_per_month": "2",
    "contract_length_months": "12",
    "expiring_contract_alert_days": "30",

    # Terminal dues (Zambia Employment Code Act No. 3 of 2019, verified Aug 2026)
    "gratuity_pct": "0.25",                 # fixed-term contract gratuity: 25% of basic pay earned during the contract
    "redundancy_months_per_year": "2",      # redundancy / death-in-service severance: 2 months' basic pay per completed year served
}
