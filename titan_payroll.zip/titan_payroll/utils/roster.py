"""
Truck roster management: which driver is currently on which truck, moving a
driver to the bench (spare pool) when they come off a truck, and assigning
a bench driver onto a truck (taking over from whoever just came off it).
"""
import datetime

BENCH_REASONS = [
    ("sick_leave", "Sick Leave"),
    ("annual_leave", "Annual Leave"),
    ("desertion", "Desertion / Absconded"),
    ("resignation_pending", "Resignation (pending)"),
    ("suspension", "Suspension"),
    ("truck_breakdown", "Truck Breakdown / Off the Road"),
    ("other", "Other"),
]


def get_truck_by_fleet_number(db, fleet_number, create_if_missing=True, user_id=None):
    fleet_number = (fleet_number or "").strip()
    if not fleet_number:
        return None
    row = db.execute("SELECT * FROM trucks WHERE fleet_number = ?", (fleet_number,)).fetchone()
    if row:
        return row
    if not create_if_missing:
        return None
    db.execute("INSERT INTO trucks (fleet_number) VALUES (?)", (fleet_number,))
    db.commit()
    return db.execute("SELECT * FROM trucks WHERE fleet_number = ?", (fleet_number,)).fetchone()


def get_current_assignment_for_driver(db, driver_id):
    return db.execute(
        """SELECT ta.*, t.fleet_number FROM truck_assignments ta
           JOIN trucks t ON t.id = ta.truck_id
           WHERE ta.driver_id = ? AND ta.end_date IS NULL""",
        (driver_id,),
    ).fetchone()


def get_current_driver_for_truck(db, truck_id):
    return db.execute(
        """SELECT ta.*, d.first_name, d.surname, d.fleet_number as driver_fleet_ref
           FROM truck_assignments ta JOIN drivers d ON d.id = ta.driver_id
           WHERE ta.truck_id = ? AND ta.end_date IS NULL""",
        (truck_id,),
    ).fetchone()


def get_vacant_trucks(db):
    """Trucks that exist but currently have no driver assigned."""
    return db.execute(
        """SELECT t.* FROM trucks t
           WHERE t.id NOT IN (SELECT truck_id FROM truck_assignments WHERE end_date IS NULL)
           ORDER BY t.fleet_number"""
    ).fetchall()


def move_to_bench(db, driver_id, reason, note, user_id, effective_date=None):
    """End the driver's current truck assignment (if any) and put them on
    the bench (status='spare'). Returns the freed truck's fleet_number, or
    None if the driver wasn't on a truck."""
    effective_date = effective_date or datetime.date.today().isoformat()
    current = get_current_assignment_for_driver(db, driver_id)
    freed_fleet_number = None
    if current:
        db.execute(
            "UPDATE truck_assignments SET end_date=?, end_reason=?, note=? WHERE id=?",
            (effective_date, reason, note, current["id"]),
        )
        freed_fleet_number = current["fleet_number"]
    db.execute("UPDATE drivers SET status='spare', updated_at=now_text() WHERE id=?", (driver_id,))
    db.commit()
    return freed_fleet_number


def assign_to_truck(db, driver_id, fleet_number, user_id, effective_date=None, note=None):
    """Assign a driver (must not already be on a truck) onto a truck
    (creating the truck record if it doesn't exist yet, and ending any
    stale assignment on that truck defensively). Sets driver status to
    'active'."""
    effective_date = effective_date or datetime.date.today().isoformat()

    existing = get_current_assignment_for_driver(db, driver_id)
    if existing:
        raise ValueError("This driver is already assigned to a truck. Move them to the bench first.")

    truck = get_truck_by_fleet_number(db, fleet_number, create_if_missing=True, user_id=user_id)

    occupant = get_current_driver_for_truck(db, truck["id"])
    if occupant:
        raise ValueError(
            f"Truck {truck['fleet_number']} is currently occupied by "
            f"{occupant['first_name']} {occupant['surname']}. Move them to the bench first."
        )

    db.execute(
        """INSERT INTO truck_assignments (truck_id, driver_id, start_date, note, created_by)
           VALUES (?, ?, ?, ?, ?)""",
        (truck["id"], driver_id, effective_date, note, user_id),
    )
    db.execute("UPDATE drivers SET status='active', updated_at=now_text() WHERE id=?", (driver_id,))
    db.commit()
    return truck


def swap_driver(db, outgoing_driver_id, incoming_driver_id, reason, note, user_id, effective_date=None):
    """Take the outgoing driver off their truck (-> bench) and immediately
    put the incoming (bench) driver onto that same truck. Convenience
    wrapper used by the roster board's drag-and-drop 'replace' action."""
    fleet_number = move_to_bench(db, outgoing_driver_id, reason, note, user_id, effective_date)
    if not fleet_number:
        raise ValueError("The outgoing driver wasn't currently assigned to a truck.")
    return assign_to_truck(db, incoming_driver_id, fleet_number, user_id, effective_date, note)


def assignment_history(db, driver_id):
    return db.execute(
        """SELECT ta.*, t.fleet_number FROM truck_assignments ta
           JOIN trucks t ON t.id = ta.truck_id
           WHERE ta.driver_id = ? ORDER BY ta.start_date DESC""",
        (driver_id,),
    ).fetchall()
