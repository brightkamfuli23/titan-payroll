"""
Full payroll register export -- every pay element for every driver on a
payroll run, in one Excel file, for audit / record-keeping purposes.

Unlike the other exports (payslips, bank file, statutory schedules,
management summary), this is the complete underlying record. The workbook
has three sheets so the full driver-workforce picture is in one file:

  1. Payroll Register -- every pay element for every driver actually paid
     on this run (mirrors payroll_lines), with a header block identifying
     the period, status, who created/finalized the run and when, and a
     totals row.
  2. Bench Drivers (Spare) -- drivers not currently on a truck (sick leave,
     desertion, between trucks, etc.) as of the time of export. Bench
     drivers on legitimate leave ARE normally included and paid on the
     Payroll Register sheet above by default; this sheet is the full bench
     census with an "On This Payroll Run?" flag, so it's clear who was
     paid and who wasn't (e.g. removed for exceeding leave).
  3. Terminated Drivers -- separated drivers, with their terminal dues
     settlement (gratuity, leave pay, other amounts, deductions, total
     payable) where a termination record exists in the system.

This is the kind of single source-of-truth document an auditor or
ZRA/NAPSA/NHIMA inspector would expect to see for a given pay period.
"""
import io
import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import config
from db import get_setting_json, get_setting_float
from utils.roster import BENCH_REASONS
from utils.terminal_dues import REASONS as TERMINATION_REASONS

HEADER_FILL = PatternFill(start_color="1F3B57", end_color="1F3B57", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=10)
TITLE_FONT = Font(bold=True, size=14)
SUBTITLE_FONT = Font(bold=True, size=11)
LABEL_FONT = Font(bold=True, size=9, color="44515C")
TOTAL_FONT = Font(bold=True)
TOTAL_FILL = PatternFill(start_color="E6ECF3", end_color="E6ECF3", fill_type="solid")
THIN_BORDER = Border(bottom=Side(style="thin", color="D5DBE0"))
NOTE_FONT = Font(bold=True, italic=True, color="8A6100")

BENCH_REASON_LABELS = dict(BENCH_REASONS)
TERMINATION_REASON_LABELS = dict(TERMINATION_REASONS)
GRATUITY_METHOD_LABELS = {
    "contract_gratuity_25pct": "Contract Gratuity (25% of basic pay earned)",
    "severance_2mo_per_year": "Severance (2 months' basic pay/completed year)",
    "none": "None",
}

# --- Sheet 1: Payroll Register (this run's pay elements) -------------------
REGISTER_COLUMNS = [
    ("S/N", "sn", 6),
    ("Fleet No.", "fleet_number", 11),
    ("Surname", "surname", 15),
    ("First Name", "first_name", 15),
    ("Bank", "bank_name", 12),
    ("Account No.", "account_no", 16),
    ("Date Employed", "date_employed", 13),
    ("Basic Salary", "basic_salary", 12),
    ("Work Days", "work_days", 10),
    ("Days Attended", "days_attended", 12),
    ("Daily Pay", "daily_pay", 10),
    ("Salary", "salary", 12),
    ("Housing", "housing", 12),
    ("Food", "food", 10),
    ("Transport", "transport", 10),
    ("Leave Days", "leave_days", 10),
    ("Leave Pay", "leave_pay", 11),
    ("Salary Backpay", "salary_backpay", 13),
    ("Gratuity", "gratuity", 11),
    ("Bonus/Other", "bonus_other", 12),
    ("Advance", "advance", 11),
    ("Gross Pay", "gross_pay", 13),
    ("NHIMA", "nhima", 10),
    ("NAPSA", "napsa", 10),
    ("PAYE", "paye", 10),
    ("Charges Deduction", "charge_deduction", 15),
    ("Net Pay (Payable)", "payable", 15),
    ("Comments", "comments", 24),
]
REGISTER_MONEY_COLS = {"basic_salary", "daily_pay", "salary", "housing", "food", "transport", "leave_pay",
                        "salary_backpay", "gratuity", "bonus_other", "advance", "gross_pay", "nhima",
                        "napsa", "paye", "charge_deduction", "payable"}
REGISTER_TOTAL_COLS = {"basic_salary", "salary", "housing", "food", "transport", "leave_pay",
                        "salary_backpay", "gratuity", "bonus_other", "advance", "gross_pay", "nhima",
                        "napsa", "paye", "charge_deduction", "payable"}


def _register_rates(db):
    """Same rate lookup as routes.payroll._get_rates -- duplicated here
    (rather than imported) to avoid a routes->utils circular import."""
    return {
        "paye_bands": get_setting_json(db, "paye_bands"),
        "napsa_rate": get_setting_float(db, "napsa_rate"),
        "napsa_ceiling": get_setting_float(db, "napsa_ceiling"),
        "nhima_rate": get_setting_float(db, "nhima_rate"),
        "housing_pct": get_setting_float(db, "housing_pct"),
    }


def _paye_formula_expr(taxable_expr, bands):
    """Build an Excel expression (no leading '=') that reproduces
    utils.payroll_calc.compute_paye()'s progressive-band math exactly:
    each band contributes MAX(0, min(taxable, upper) - lower) * rate, which
    is zero for every band the taxable amount hasn't reached -- the same
    result the Python version gets via its early-break loop."""
    terms = []
    for lower, upper, rate in bands:
        if not rate:
            continue
        if upper is None:
            terms.append(f"MAX(0,{taxable_expr}-{lower})*{rate}")
        else:
            terms.append(f"MAX(0,MIN({taxable_expr},{upper})-{lower})*{rate}")
    return "+".join(terms) if terms else "0"


def _register_formulas(rates):
    """Formula-cell builders for the Payroll Register sheet's computed
    columns, keyed the same as REGISTER_COLUMNS -- each is called as
    fn(excel_row, col_letters, data_row) and returns either a formula
    string (leading '=') or a plain literal (used for the statutory
    deductions on a foreign-national driver, which are always 0 rather
    than rate-derived). Every formula reads only cells in the SAME row,
    reproducing utils.payroll_calc.compute_payroll_line()'s math so the
    workbook recalculates live in Excel exactly like the app would."""
    housing_pct = rates["housing_pct"]
    nhima_rate = rates["nhima_rate"]
    napsa_rate = rates["napsa_rate"]
    napsa_ceiling = rates["napsa_ceiling"]
    paye_bands = rates["paye_bands"]

    def daily_pay(r, L, row):
        return f"=IFERROR(ROUND({L['basic_salary']}{r}/{L['work_days']}{r},4),0)"

    def salary(r, L, row):
        return f"=ROUND({L['daily_pay']}{r}*{L['days_attended']}{r},2)"

    def housing(r, L, row):
        return f"=ROUND({L['salary']}{r}*{housing_pct},2)"

    def leave_pay(r, L, row):
        return (f"=ROUND(({L['salary']}{r}+{L['housing']}{r}+{L['food']}{r}+{L['transport']}{r})"
                f"/26*{L['leave_days']}{r},2)")

    def gross_pay(r, L, row):
        return (f"=ROUND({L['salary']}{r}+{L['housing']}{r}+{L['food']}{r}+{L['transport']}{r}"
                f"+{L['leave_pay']}{r}-{L['advance']}{r},2)")

    def nhima(r, L, row):
        if not row.get("zambian_statutory", True):
            return 0
        return f"=ROUND({L['basic_salary']}{r}*{nhima_rate},2)"

    def napsa(r, L, row):
        if not row.get("zambian_statutory", True):
            return 0
        return f"=ROUND(MIN({L['gross_pay']}{r},{napsa_ceiling})*{napsa_rate},2)"

    def paye(r, L, row):
        if not row.get("zambian_statutory", True):
            return 0
        taxable_expr = f"({L['gross_pay']}{r}-{L['bonus_other']}{r})"
        return f"=ROUND({_paye_formula_expr(taxable_expr, paye_bands)},2)"

    def payable(r, L, row):
        return (f"=ROUND({L['gross_pay']}{r}-{L['nhima']}{r}-{L['napsa']}{r}-{L['paye']}{r}"
                f"+{L['gratuity']}{r}+{L['salary_backpay']}{r}+{L['bonus_other']}{r}"
                f"-{L['charge_deduction']}{r},2)")

    return {
        "daily_pay": daily_pay, "salary": salary, "housing": housing, "leave_pay": leave_pay,
        "gross_pay": gross_pay, "nhima": nhima, "napsa": napsa, "paye": paye, "payable": payable,
    }


# --- Shared block: each driver's most recent ACTUAL payroll run, appended to
# both the Bench and Terminated sheets below so those sheets carry the same
# full set of pay elements as the Payroll Register sheet. These are real
# historical figures from the last payroll_lines row the driver was actually
# paid on (whichever run that was) -- not a recalculated estimate of what
# they'd earn today -- so "Last Paid Period" makes clear which run they're
# from.
LAST_PAYROLL_KEYS = ["work_days", "days_attended", "daily_pay", "salary", "housing", "food", "transport",
                      "leave_days", "leave_pay", "salary_backpay", "gratuity", "bonus_other", "advance",
                      "gross_pay", "nhima", "napsa", "paye", "charge_deduction", "payable", "comments"]
LAST_PAYROLL_COLUMNS = [
    ("Last Paid Period", "lp_period_label", 22),
    ("Work Days", "lp_work_days", 10),
    ("Days Attended", "lp_days_attended", 12),
    ("Daily Pay", "lp_daily_pay", 10),
    ("Salary", "lp_salary", 12),
    ("Housing", "lp_housing", 12),
    ("Food", "lp_food", 10),
    ("Transport", "lp_transport", 10),
    ("Leave Days", "lp_leave_days", 10),
    ("Leave Pay", "lp_leave_pay", 11),
    ("Salary Backpay", "lp_salary_backpay", 13),
    ("Gratuity", "lp_gratuity", 11),
    ("Bonus/Other", "lp_bonus_other", 12),
    ("Advance", "lp_advance", 11),
    ("Gross Pay", "lp_gross_pay", 13),
    ("NHIMA", "lp_nhima", 10),
    ("NAPSA", "lp_napsa", 10),
    ("PAYE", "lp_paye", 10),
    ("Charges Deduction", "lp_charge_deduction", 15),
    ("Net Pay (Payable)", "lp_payable", 15),
    ("Comments", "lp_comments", 24),
]
LAST_PAYROLL_MONEY_COLS = {"lp_daily_pay", "lp_salary", "lp_housing", "lp_food", "lp_transport", "lp_leave_pay",
                            "lp_salary_backpay", "lp_gratuity", "lp_bonus_other", "lp_advance", "lp_gross_pay",
                            "lp_nhima", "lp_napsa", "lp_paye", "lp_charge_deduction", "lp_payable"}
# Deliberately NOT summed in a totals row -- unlike the Payroll Register
# sheet (where every row is the same pay period), these figures come from
# whatever run each driver was last actually paid on, which differs driver
# to driver, so a SUM across them wouldn't represent any real payroll total.

# --- Sheet 2: Bench Drivers (Spare) -----------------------------------------
BENCH_COLUMNS = [
    ("S/N", "sn", 6),
    ("Fleet No. (Last Driven)", "fleet_number", 15),
    ("Surname", "surname", 15),
    ("First Name", "first_name", 15),
    ("Bank", "bank_name", 12),
    ("Account No.", "account_no", 16),
    ("Date Employed", "date_employed", 13),
    ("Basic Salary", "basic_salary", 12),
    ("On This Payroll Run?", "on_this_run", 16),
    ("On Bench Since", "bench_since", 14),
    ("Reason", "reason_label", 20),
    ("Note", "note", 24),
] + LAST_PAYROLL_COLUMNS
BENCH_MONEY_COLS = {"basic_salary"} | LAST_PAYROLL_MONEY_COLS
BENCH_TOTAL_COLS = {"basic_salary"}

# --- Sheet 3: Terminated Drivers ---------------------------------------------
TERMINATION_COLUMNS = [
    ("S/N", "sn", 6),
    ("Fleet No. (Last Driven)", "fleet_number", 15),
    ("Surname", "surname", 15),
    ("First Name", "first_name", 15),
    ("Bank", "bank_name", 12),
    ("Account No.", "account_no", 16),
    ("Date Employed", "date_employed", 13),
    ("Basic Salary", "basic_salary", 12),
    ("Termination Date", "termination_date", 14),
    ("Last Day Worked", "last_day_worked", 14),
    ("Reason", "reason_label", 22),
    ("Final Pay (Pro-rated)", "final_pay_amount", 16),
    ("Gratuity Method", "gratuity_method_label", 30),
    ("Gratuity Amount", "gratuity_amount", 14),
    ("Leave Days Owing", "leave_days_owing", 14),
    ("Leave Pay Amount", "leave_pay_amount", 14),
    ("Other Amount", "other_amount", 12),
    ("Other Description", "other_description", 22),
    ("Deductions (Charges)", "deductions_amount", 16),
    ("Total Payable (Settlement)", "total_payable", 18),
    ("Settlement Status", "settlement_status", 16),
    ("Notes", "notes", 24),
] + LAST_PAYROLL_COLUMNS
TERMINATION_MONEY_COLS = {"basic_salary", "final_pay_amount", "gratuity_amount", "leave_pay_amount",
                           "other_amount", "deductions_amount", "total_payable"} | LAST_PAYROLL_MONEY_COLS
TERMINATION_TOTAL_COLS = {"final_pay_amount", "gratuity_amount", "leave_pay_amount", "other_amount",
                           "deductions_amount", "total_payable"}


# --- Gratuity Summary (a calendar month's terminations, standalone) -------
GRATUITY_SUMMARY_COLUMNS = [
    ("S/N", "sn", 6),
    ("Fleet No.", "fleet_number", 11),
    ("Surname", "surname", 15),
    ("First Name", "first_name", 15),
    ("Bank", "bank_name", 12),
    ("Account No.", "account_no", 16),
    ("Termination Date", "termination_date", 14),
    ("Last Day Worked", "last_day_worked", 14),
    ("Reason", "reason_label", 22),
    ("Final Pay (Pro-rated)", "final_pay_amount", 16),
    ("Gratuity Method", "gratuity_method_label", 30),
    ("Basis", "basic_pay_basis", 14),
    ("Gratuity", "gratuity_amount", 12),
    ("Leave Days Owing", "leave_days_owing", 14),
    ("Leave Pay", "leave_pay_amount", 12),
    ("Other / Recovery", "other_amount", 15),
    ("Other / Recovery Description", "other_description", 30),
    ("Deductions (Charges)", "deductions_amount", 16),
    ("Total Payable", "total_payable", 15),
    ("Status", "settlement_status", 12),
    ("Notes", "notes", 24),
]
GRATUITY_SUMMARY_MONEY_COLS = {"basic_pay_basis", "final_pay_amount", "gratuity_amount", "leave_pay_amount",
                                "other_amount", "deductions_amount", "total_payable"}
GRATUITY_SUMMARY_TOTAL_COLS = {"final_pay_amount", "gratuity_amount", "leave_pay_amount", "other_amount",
                                "deductions_amount", "total_payable"}


def build_gratuity_summary(rows, period_label, month_start, month_end):
    """Standalone workbook of every termination settlement in a calendar
    month -- same pay elements as the Terminated Drivers sheet in the full
    Payroll Register, but scoped to one month and downloadable on its own
    from the Gratuity Summary page. This is a working copy: editing it does
    NOT change the live system -- corrections belong on the termination's
    own page so the on-file record stays the source of truth."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Gratuity Summary"

    data_rows = []
    for r in rows:
        row = dict(r)
        row["reason_label"] = TERMINATION_REASON_LABELS.get(r["reason"], r["reason"] or "—")
        row["gratuity_method_label"] = GRATUITY_METHOD_LABELS.get(r["gratuity_method"], r["gratuity_method"] or "—")
        row["settlement_status"] = "FINALIZED" if r["status"] == "finalized" else "DRAFT"
        data_rows.append(row)

    meta = [
        ("Currency", config.CURRENCY),
        ("Period", period_label),
        ("Date range", f"{month_start} to {month_end}"),
        ("Generated", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")),
        ("Terminations this period", len(data_rows)),
    ]
    _write_sheet(ws, [config.COMPANY_NAME, f"Gratuity Summary — {period_label}"], meta,
                 GRATUITY_SUMMARY_COLUMNS, GRATUITY_SUMMARY_MONEY_COLS, GRATUITY_SUMMARY_TOTAL_COLS,
                 data_rows, sign_off=True,
                 note="Editable working copy -- adjust any figure here for your own reference; it will NOT "
                      "change the live system. To correct a termination's actual on-file figures, edit it "
                      "from that termination's own page instead.")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def _get_username(db, user_id):
    if not user_id:
        return None
    row = db.execute("SELECT full_name, username FROM users WHERE id = ?", (user_id,)).fetchone()
    if not row:
        return None
    return f"{row['full_name']} ({row['username']})"


def _write_sheet(ws, title_lines, meta, columns, money_cols, total_cols, rows, sign_off=False, note=None,
                  formulas=None):
    """Shared layout: title block, meta key/value block, optional note,
    a styled data table with S/N-numbered rows, and an optional totals row
    (SUM formulas). Returns the row number the table's totals row landed on
    (or the last data row if there are no total_cols), for callers that
    want to add more content below.

    `formulas`, if given, is {column_key: fn(excel_row, col_letters, data_row)}
    -- for those columns, the cell gets the fn's return value (a formula
    string or a literal) instead of data_row[key], so the workbook itself
    carries the calculation rather than just its result. col_letters is a
    {column_key: "A"/"B"/...} map built from `columns`, handed to every fn
    so its formulas can reference this row's other cells."""
    ws["A1"] = title_lines[0]
    ws["A1"].font = TITLE_FONT
    if len(title_lines) > 1:
        ws["A2"] = title_lines[1]
        ws["A2"].font = SUBTITLE_FONT

    row = 4
    for label, value in meta:
        ws.cell(row=row, column=1, value=label).font = LABEL_FONT
        ws.cell(row=row, column=2, value=value)
        row += 1

    if note:
        ws.cell(row=row, column=1, value=note).font = NOTE_FONT
        row += 1

    row += 1  # blank spacer row
    table_start_row = row

    for i, (label, key, width) in enumerate(columns, start=1):
        cell = ws.cell(row=table_start_row, column=i, value=label)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[table_start_row].height = 26

    col_letters = {key: get_column_letter(i) for i, (label, key, width) in enumerate(columns, start=1)}

    r = table_start_row + 1
    for sn, data_row in enumerate(rows, start=1):
        for i, (label, key, width) in enumerate(columns, start=1):
            if formulas and key in formulas:
                val = formulas[key](r, col_letters, data_row)
            else:
                val = sn if key == "sn" else data_row.get(key)
            cell = ws.cell(row=r, column=i, value=val)
            if key in money_cols and val is not None:
                cell.number_format = "#,##0.00"
            cell.border = THIN_BORDER
        r += 1

    data_end_row = r - 1

    if not rows:
        ws.cell(row=r, column=1, value="(none)").font = Font(italic=True, color="8A939C")
        last_row = r
    elif total_cols:
        ws.cell(row=r, column=3, value="TOTAL").font = TOTAL_FONT
        for i, (label, key, width) in enumerate(columns, start=1):
            cell = ws.cell(row=r, column=i)
            cell.fill = TOTAL_FILL
            cell.font = TOTAL_FONT
            if key in total_cols:
                col_letter = get_column_letter(i)
                cell.value = f"=SUM({col_letter}{table_start_row + 1}:{col_letter}{data_end_row})"
                cell.number_format = "#,##0.00"
        last_row = r
    else:
        last_row = data_end_row

    if rows:
        ws.freeze_panes = f"A{table_start_row + 1}"
        ws.auto_filter.ref = f"A{table_start_row}:{get_column_letter(len(columns))}{data_end_row}"

    if sign_off:
        r = last_row + 3
        ws.cell(row=r, column=1, value="Prepared By:").font = LABEL_FONT
        ws.cell(row=r, column=4, value="Reviewed By:").font = LABEL_FONT
        ws.cell(row=r, column=7, value="Approved By:").font = LABEL_FONT
        r += 2
        ws.cell(row=r, column=1, value="Signature: _______________________")
        ws.cell(row=r, column=4, value="Signature: _______________________")
        ws.cell(row=r, column=7, value="Signature: _______________________")
        r += 1
        ws.cell(row=r, column=1, value="Date: ___________________________")
        ws.cell(row=r, column=4, value="Date: ___________________________")
        ws.cell(row=r, column=7, value="Date: ___________________________")
        last_row = r

    return last_row


def _register_rows(db, run):
    lines = db.execute(
        """SELECT pl.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number,
                  d.surname, d.first_name, d.bank_name, d.account_no, d.date_employed,
                  d.zambian_statutory
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE pl.run_id = ? ORDER BY d.surname, d.first_name""",
        (run["id"],),
    ).fetchall()
    return [dict(l) for l in lines]


def last_payroll_fields(db, driver_id):
    """The driver's most recent ACTUAL payroll_lines row across all runs
    (any status), so Bench/Terminated sheets can show real historical pay
    figures rather than leaving those columns blank. Returns all-None
    lp_* fields if the driver has never been on a payroll run."""
    line = db.execute(
        """SELECT pl.*, pr.period_label, pr.status as run_status
           FROM payroll_lines pl JOIN payroll_runs pr ON pr.id = pl.run_id
           WHERE pl.driver_id = ?
           ORDER BY pr.period_year DESC, pr.period_month DESC, pl.id DESC
           LIMIT 1""",
        (driver_id,),
    ).fetchone()
    fields = {"lp_period_label": None}
    for k in LAST_PAYROLL_KEYS:
        fields[f"lp_{k}"] = None
    if line:
        run_status_label = "Finalized" if line["run_status"] == "finalized" else "Draft"
        fields["lp_period_label"] = f"{line['period_label']} ({run_status_label})"
        for k in LAST_PAYROLL_KEYS:
            fields[f"lp_{k}"] = line[k]
    return fields


def _bench_rows(db, run):
    drivers = db.execute(
        """SELECT d.*,
             (SELECT t.fleet_number FROM truck_assignments ta JOIN trucks t ON t.id = ta.truck_id
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as last_fleet_number,
             (SELECT ta.end_date FROM truck_assignments ta
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as bench_since,
             (SELECT ta.end_reason FROM truck_assignments ta
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as end_reason,
             (SELECT ta.note FROM truck_assignments ta
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as note,
             (SELECT 1 FROM payroll_lines pl WHERE pl.driver_id = d.id AND pl.run_id = ?) as on_run
           FROM drivers d WHERE d.status = 'spare' ORDER BY d.surname, d.first_name""",
        (run["id"],),
    ).fetchall()

    rows = []
    for d in drivers:
        row = dict(d)
        row["fleet_number"] = d["last_fleet_number"] or d["fleet_number"]
        row["reason_label"] = BENCH_REASON_LABELS.get(d["end_reason"], d["end_reason"] or "—")
        row["on_this_run"] = "Yes — being paid" if d["on_run"] else "No — removed/not on this run"
        row.update(last_payroll_fields(db, d["id"]))
        rows.append(row)
    return rows


def _termination_rows(db):
    drivers = db.execute(
        """SELECT d.*,
             (SELECT t.fleet_number FROM truck_assignments ta JOIN trucks t ON t.id = ta.truck_id
              WHERE ta.driver_id = d.id ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as last_fleet_number,
             tm.termination_date, tm.last_day_worked, tm.reason as term_reason, tm.gratuity_method,
             tm.final_pay_amount, tm.gratuity_amount, tm.leave_days_owing, tm.leave_pay_amount, tm.other_amount,
             tm.other_description, tm.deductions_amount, tm.total_payable,
             tm.status as term_status, tm.notes as term_notes
           FROM drivers d
           LEFT JOIN terminations tm ON tm.id = (
             SELECT id FROM terminations WHERE driver_id = d.id
             ORDER BY termination_date DESC, id DESC LIMIT 1
           )
           WHERE d.status = 'terminated' ORDER BY d.surname, d.first_name"""
    ).fetchall()

    rows = []
    for d in drivers:
        row = dict(d)
        row["fleet_number"] = d["last_fleet_number"] or d["fleet_number"]
        if d["termination_date"] is not None:
            row["termination_date"] = d["termination_date"]
            row["reason_label"] = TERMINATION_REASON_LABELS.get(d["term_reason"], d["term_reason"] or "—")
            row["gratuity_method_label"] = GRATUITY_METHOD_LABELS.get(d["gratuity_method"], d["gratuity_method"] or "—")
            row["settlement_status"] = "FINALIZED" if d["term_status"] == "finalized" else "DRAFT"
            row["notes"] = d["term_notes"]
        else:
            # Driver marked terminated but no termination record was ever
            # created in this system (e.g. imported directly as terminated
            # from the legacy sheet) -- show what we know and flag the rest.
            row["termination_date"] = d["date_terminated"] or "—"
            row["reason_label"] = "—"
            row["gratuity_method_label"] = "—"
            row["settlement_status"] = "No settlement record in system"
            row["notes"] = d["comments"]
        row.update(last_payroll_fields(db, d["id"]))
        rows.append(row)
    return rows


def build_payroll_register(db, run):
    wb = Workbook()

    # --- Sheet 1: Payroll Register ---
    ws1 = wb.active
    ws1.title = "Payroll Register"
    status_label = "FINALIZED" if run["status"] == "finalized" else "DRAFT — subject to change"
    meta = [
        ("Currency", config.CURRENCY),
        ("Status", status_label),
        ("Prepared by", _get_username(db, run["created_by"]) or "—"),
        ("Created", run["created_at"]),
    ]
    if run["status"] == "finalized":
        meta.append(("Finalized by", _get_username(db, run["finalized_by"]) or "—"))
        meta.append(("Finalized at", run["finalized_at"] or "—"))
    meta.append(("Register generated", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
    note = None
    if run["status"] != "finalized":
        note = "NOTE: this run is still a DRAFT. Figures may still change before finalization."
    formula_note = ("Daily Pay, Salary, Housing, Leave Pay, Gross Pay, NHIMA, NAPSA, PAYE and Net Pay "
                     "(Payable) are live Excel formulas, not fixed numbers -- edit Basic Salary, Days "
                     "Attended, Leave Days, or any other input cell and they recalculate automatically, "
                     "the same way BHRM 300 itself would.")
    note = f"{note}  {formula_note}" if note else formula_note

    _write_sheet(ws1, [config.COMPANY_NAME, f"Payroll Register — {run['period_label']}"], meta,
                 REGISTER_COLUMNS, REGISTER_MONEY_COLS, REGISTER_TOTAL_COLS,
                 _register_rows(db, run), sign_off=True, note=note,
                 formulas=_register_formulas(_register_rates(db)))

    # --- Sheet 2: Bench Drivers (Spare) ---
    ws2 = wb.create_sheet("Bench Drivers (Spare)")
    bench_rows = _bench_rows(db, run)
    paid_count = sum(1 for r in bench_rows if r["on_run"])
    meta2 = [
        ("Currency", config.CURRENCY),
        ("Snapshot as of", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")),
        ("Drivers on bench", len(bench_rows)),
        ("...of which paid on this run", paid_count),
    ]
    _write_sheet(ws2, [config.COMPANY_NAME, "Bench Drivers (Spare) — current roster"], meta2,
                 BENCH_COLUMNS, BENCH_MONEY_COLS, BENCH_TOTAL_COLS, bench_rows,
                 note="Drivers not currently assigned to a truck (sick leave, resting between "
                      "trucks, desertion, etc.) as of the time this register was generated. "
                      "Bench drivers on legitimate leave are included and paid on the Payroll "
                      "Register above by default -- the 'On This Payroll Run?' column here shows "
                      "which ones were, in case any were manually removed for this period. The "
                      "'Last Paid Period' block on the right shows each driver's actual pay "
                      "elements from the most recent run they were really paid on (not "
                      "necessarily this one) -- blank if they've never been paid through this system.")

    # --- Sheet 3: Terminated Drivers ---
    ws3 = wb.create_sheet("Terminated Drivers")
    term_rows = _termination_rows(db)
    meta3 = [
        ("Currency", config.CURRENCY),
        ("Snapshot as of", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")),
        ("Terminated drivers on record", len(term_rows)),
    ]
    _write_sheet(ws3, [config.COMPANY_NAME, "Terminated Drivers — separation & terminal dues"], meta3,
                 TERMINATION_COLUMNS, TERMINATION_MONEY_COLS, TERMINATION_TOTAL_COLS, term_rows,
                 note="All drivers currently recorded as terminated, with their terminal dues "
                      "settlement where one was processed through this system. The 'Last Paid "
                      "Period' block on the right shows each driver's actual pay elements from "
                      "the last regular payroll run they were paid on before separation -- "
                      "separate from the terminal dues settlement figures to its left.")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
