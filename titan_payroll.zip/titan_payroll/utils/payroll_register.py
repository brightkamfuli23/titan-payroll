"""
Full payroll register export -- every pay element for every driver on a
payroll run, in one Excel file, for audit / record-keeping purposes.

Unlike the other exports (payslips, bank file, statutory schedules,
management summary), this is the complete underlying record. The workbook
has three sheets so the full driver-workforce picture is in one file:

  1. Payroll Register -- every pay element for every driver actually paid
     on this run (mirrors payroll_lines), with a header block identifying
     the period, status, who created/finalized the run and when, and a
     totals row.
  2. Bench Drivers (Spare) -- drivers not currently on a truck (sick leave,
     desertion, between trucks, etc.) as of the time of export. Bench
     drivers on legitimate leave ARE normally included and paid on the
     Payroll Register sheet above by default; this sheet is the full bench
     census with an "On This Payroll Run?" flag, so it's clear who was
     paid and who wasn't (e.g. removed for exceeding leave).
  3. Terminated Drivers -- separated drivers, with their terminal dues
     settlement (gratuity, leave pay, other amounts, deductions, total
     payable) where a termination record exists in the system.

This is the kind of single source-of-truth document an auditor or
ZRA/NAPSA/NHIMA inspector would expect to see for a given pay period.
"""
import io
import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

import config
from utils.roster import BENCH_REASONS
from utils.terminal_dues import REASONS as TERMINATION_REASONS

HEADER_FILL = PatternFill(start_color="1F3B57", end_color="1F3B57", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=10)
TITLE_FONT = Font(bold=True, size=14)
SUBTITLE_FONT = Font(bold=True, size=11)
LABEL_FONT = Font(bold=True, size=9, color="44515C")
TOTAL_FONT = Font(bold=True)
TOTAL_FILL = PatternFill(start_color="E6ECF3", end_color="E6ECF3", fill_type="solid")
THIN_BORDER = Border(bottom=Side(style="thin", color="D5DBE0"))
NOTE_FONT = Font(bold=True, italic=True, color="8A6100")

BENCH_REASON_LABELS = dict(BENCH_REASONS)
TERMINATION_REASON_LABELS = dict(TERMINATION_REASONS)
GRATUITY_METHOD_LABELS = {
    "contract_gratuity_25pct": "Contract Gratuity (25% of basic pay earned)",
    "severance_2mo_per_year": "Severance (2 months' basic pay/completed year)",
    "none": "None",
}

# --- Sheet 1: Payroll Register (this run's pay elements) -------------------
REGISTER_COLUMNS = [
    ("S/N", "sn", 6),
    ("Fleet No.", "fleet_number", 11),
    ("Surname", "surname", 15),
    ("First Name", "first_name", 15),
    ("Bank", "bank_name", 12),
    ("Account No.", "account_no", 16),
    ("Date Employed", "date_employed", 13),
    ("Basic Salary", "basic_salary", 12),
    ("Work Days", "work_days", 10),
    ("Days Attended", "days_attended", 12),
    ("Daily Pay", "daily_pay", 10),
    ("Salary", "salary", 12),
    ("Housing", "housing", 12),
    ("Food", "food", 10),
    ("Transport", "transport", 10),
    ("Leave Days", "leave_days", 10),
    ("Leave Pay", "leave_pay", 11),
    ("Salary Backpay", "salary_backpay", 13),
    ("Gratuity", "gratuity", 11),
    ("Bonus/Other", "bonus_other", 12),
    ("Advance", "advance", 11),
    ("Gross Pay", "gross_pay", 13),
    ("NHIMA", "nhima", 10),
    ("NAPSA", "napsa", 10),
    ("PAYE", "paye", 10),
    ("Charges Deduction", "charge_deduction", 15),
    ("Net Pay (Payable)", "payable", 15),
    ("Comments", "comments", 24),
]
REGISTER_MONEY_COLS = {"basic_salary", "daily_pay", "salary", "housing", "food", "transport", "leave_pay",
                        "salary_backpay", "gratuity", "bonus_other", "advance", "gross_pay", "nhima",
                        "napsa", "paye", "charge_deduction", "payable"}
REGISTER_TOTAL_COLS = {"basic_salary", "salary", "housing", "food", "transport", "leave_pay",
                        "salary_backpay", "gratuity", "bonus_other", "advance", "gross_pay", "nhima",
                        "napsa", "paye", "charge_deduction", "payable"}

# --- Sheet 2: Bench Drivers (Spare) -----------------------------------------
BENCH_COLUMNS = [
    ("S/N", "sn", 6),
    ("Fleet No. (Last Driven)", "fleet_number", 15),
    ("Surname", "surname", 15),
    ("First Name", "first_name", 15),
    ("Bank", "bank_name", 12),
    ("Account No.", "account_no", 16),
    ("Date Employed", "date_employed", 13),
    ("Basic Salary", "basic_salary", 12),
    ("On This Payroll Run?", "on_this_run", 16),
    ("On Bench Since", "bench_since", 14),
    ("Reason", "reason_label", 20),
    ("Note", "note", 24),
]
BENCH_MONEY_COLS = {"basic_salary"}
BENCH_TOTAL_COLS = {"basic_salary"}

# --- Sheet 3: Terminated Drivers ---------------------------------------------
TERMINATION_COLUMNS = [
    ("S/N", "sn", 6),
    ("Fleet No. (Last Driven)", "fleet_number", 15),
    ("Surname", "surname", 15),
    ("First Name", "first_name", 15),
    ("Bank", "bank_name", 12),
    ("Account No.", "account_no", 16),
    ("Date Employed", "date_employed", 13),
    ("Basic Salary", "basic_salary", 12),
    ("Termination Date", "termination_date", 14),
    ("Reason", "reason_label", 22),
    ("Gratuity Method", "gratuity_method_label", 30),
    ("Gratuity Amount", "gratuity_amount", 14),
    ("Leave Days Owing", "leave_days_owing", 14),
    ("Leave Pay Amount", "leave_pay_amount", 14),
    ("Other Amount", "other_amount", 12),
    ("Other Description", "other_description", 22),
    ("Deductions (Charges)", "deductions_amount", 16),
    ("Total Payable (Settlement)", "total_payable", 18),
    ("Settlement Status", "settlement_status", 16),
    ("Notes", "notes", 24),
]
TERMINATION_MONEY_COLS = {"basic_salary", "gratuity_amount", "leave_pay_amount", "other_amount",
                           "deductions_amount", "total_payable"}
TERMINATION_TOTAL_COLS = {"gratuity_amount", "leave_pay_amount", "other_amount",
                           "deductions_amount", "total_payable"}


def _get_username(db, user_id):
    if not user_id:
        return None
    row = db.execute("SELECT full_name, username FROM users WHERE id = ?", (user_id,)).fetchone()
    if not row:
        return None
    return f"{row['full_name']} ({row['username']})"


def _write_sheet(ws, title_lines, meta, columns, money_cols, total_cols, rows, sign_off=False, note=None):
    """Shared layout: title block, meta key/value block, optional note,
    a styled data table with S/N-numbered rows, and an optional totals row
    (SUM formulas). Returns the row number the table's totals row landed on
    (or the last data row if there are no total_cols), for callers that
    want to add more content below."""
    ws["A1"] = title_lines[0]
    ws["A1"].font = TITLE_FONT
    if len(title_lines) > 1:
        ws["A2"] = title_lines[1]
        ws["A2"].font = SUBTITLE_FONT

    row = 4
    for label, value in meta:
        ws.cell(row=row, column=1, value=label).font = LABEL_FONT
        ws.cell(row=row, column=2, value=value)
        row += 1

    if note:
        ws.cell(row=row, column=1, value=note).font = NOTE_FONT
        row += 1

    row += 1  # blank spacer row
    table_start_row = row

    for i, (label, key, width) in enumerate(columns, start=1):
        cell = ws.cell(row=table_start_row, column=i, value=label)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[table_start_row].height = 26

    r = table_start_row + 1
    for sn, data_row in enumerate(rows, start=1):
        for i, (label, key, width) in enumerate(columns, start=1):
            val = sn if key == "sn" else data_row.get(key)
            cell = ws.cell(row=r, column=i, value=val)
            if key in money_cols and val is not None:
                cell.number_format = "#,##0.00"
            cell.border = THIN_BORDER
        r += 1

    data_end_row = r - 1

    if not rows:
        ws.cell(row=r, column=1, value="(none)").font = Font(italic=True, color="8A939C")
        last_row = r
    elif total_cols:
        ws.cell(row=r, column=3, value="TOTAL").font = TOTAL_FONT
        for i, (label, key, width) in enumerate(columns, start=1):
            cell = ws.cell(row=r, column=i)
            cell.fill = TOTAL_FILL
            cell.font = TOTAL_FONT
            if key in total_cols:
                col_letter = get_column_letter(i)
                cell.value = f"=SUM({col_letter}{table_start_row + 1}:{col_letter}{data_end_row})"
                cell.number_format = "#,##0.00"
        last_row = r
    else:
        last_row = data_end_row

    if rows:
        ws.freeze_panes = f"A{table_start_row + 1}"
        ws.auto_filter.ref = f"A{table_start_row}:{get_column_letter(len(columns))}{data_end_row}"

    if sign_off:
        r = last_row + 3
        ws.cell(row=r, column=1, value="Prepared By:").font = LABEL_FONT
        ws.cell(row=r, column=4, value="Reviewed By:").font = LABEL_FONT
        ws.cell(row=r, column=7, value="Approved By:").font = LABEL_FONT
        r += 2
        ws.cell(row=r, column=1, value="Signature: _______________________")
        ws.cell(row=r, column=4, value="Signature: _______________________")
        ws.cell(row=r, column=7, value="Signature: _______________________")
        r += 1
        ws.cell(row=r, column=1, value="Date: ___________________________")
        ws.cell(row=r, column=4, value="Date: ___________________________")
        ws.cell(row=r, column=7, value="Date: ___________________________")
        last_row = r

    return last_row


def _register_rows(db, run):
    lines = db.execute(
        """SELECT pl.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number,
                  d.surname, d.first_name, d.bank_name, d.account_no, d.date_employed
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE pl.run_id = ? ORDER BY d.surname, d.first_name""",
        (run["id"],),
    ).fetchall()
    return [dict(l) for l in lines]


def _bench_rows(db, run):
    drivers = db.execute(
        """SELECT d.*,
             (SELECT t.fleet_number FROM truck_assignments ta JOIN trucks t ON t.id = ta.truck_id
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as last_fleet_number,
             (SELECT ta.end_date FROM truck_assignments ta
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as bench_since,
             (SELECT ta.end_reason FROM truck_assignments ta
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as end_reason,
             (SELECT ta.note FROM truck_assignments ta
              WHERE ta.driver_id = d.id AND ta.end_date IS NOT NULL
              ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as note,
             (SELECT 1 FROM payroll_lines pl WHERE pl.driver_id = d.id AND pl.run_id = ?) as on_run
           FROM drivers d WHERE d.status = 'spare' ORDER BY d.surname, d.first_name""",
        (run["id"],),
    ).fetchall()

    rows = []
    for d in drivers:
        row = dict(d)
        row["fleet_number"] = d["last_fleet_number"] or d["fleet_number"]
        row["reason_label"] = BENCH_REASON_LABELS.get(d["end_reason"], d["end_reason"] or "—")
        row["on_this_run"] = "Yes — being paid" if d["on_run"] else "No — removed/not on this run"
        rows.append(row)
    return rows


def _termination_rows(db):
    drivers = db.execute(
        """SELECT d.*,
             (SELECT t.fleet_number FROM truck_assignments ta JOIN trucks t ON t.id = ta.truck_id
              WHERE ta.driver_id = d.id ORDER BY ta.end_date DESC, ta.id DESC LIMIT 1) as last_fleet_number,
             tm.termination_date, tm.reason as term_reason, tm.gratuity_method,
             tm.gratuity_amount, tm.leave_days_owing, tm.leave_pay_amount, tm.other_amount,
             tm.other_description, tm.deductions_amount, tm.total_payable,
             tm.status as term_status, tm.notes as term_notes
           FROM drivers d
           LEFT JOIN terminations tm ON tm.id = (
             SELECT id FROM terminations WHERE driver_id = d.id
             ORDER BY termination_date DESC, id DESC LIMIT 1
           )
           WHERE d.status = 'terminated' ORDER BY d.surname, d.first_name"""
    ).fetchall()

    rows = []
    for d in drivers:
        row = dict(d)
        row["fleet_number"] = d["last_fleet_number"] or d["fleet_number"]
        if d["termination_date"] is not None:
            row["termination_date"] = d["termination_date"]
            row["reason_label"] = TERMINATION_REASON_LABELS.get(d["term_reason"], d["term_reason"] or "—")
            row["gratuity_method_label"] = GRATUITY_METHOD_LABELS.get(d["gratuity_method"], d["gratuity_method"] or "—")
            row["settlement_status"] = "FINALIZED" if d["term_status"] == "finalized" else "DRAFT"
            row["notes"] = d["term_notes"]
        else:
            # Driver marked terminated but no termination record was ever
            # created in this system (e.g. imported directly as terminated
            # from the legacy sheet) -- show what we know and flag the rest.
            row["termination_date"] = d["date_terminated"] or "—"
            row["reason_label"] = "—"
            row["gratuity_method_label"] = "—"
            row["settlement_status"] = "No settlement record in system"
            row["notes"] = d["comments"]
        rows.append(row)
    return rows


def build_payroll_register(db, run):
    wb = Workbook()

    # --- Sheet 1: Payroll Register ---
    ws1 = wb.active
    ws1.title = "Payroll Register"
    status_label = "FINALIZED" if run["status"] == "finalized" else "DRAFT — subject to change"
    meta = [
        ("Currency", config.CURRENCY),
        ("Status", status_label),
        ("Prepared by", _get_username(db, run["created_by"]) or "—"),
        ("Created", run["created_at"]),
    ]
    if run["status"] == "finalized":
        meta.append(("Finalized by", _get_username(db, run["finalized_by"]) or "—"))
        meta.append(("Finalized at", run["finalized_at"] or "—"))
    meta.append(("Register generated", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
    note = None
    if run["status"] != "finalized":
        note = "NOTE: this run is still a DRAFT. Figures may still change before finalization."

    _write_sheet(ws1, [config.COMPANY_NAME, f"Payroll Register — {run['period_label']}"], meta,
                 REGISTER_COLUMNS, REGISTER_MONEY_COLS, REGISTER_TOTAL_COLS,
                 _register_rows(db, run), sign_off=True, note=note)

    # --- Sheet 2: Bench Drivers (Spare) ---
    ws2 = wb.create_sheet("Bench Drivers (Spare)")
    bench_rows = _bench_rows(db, run)
    paid_count = sum(1 for r in bench_rows if r["on_run"])
    meta2 = [
        ("Currency", config.CURRENCY),
        ("Snapshot as of", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")),
        ("Drivers on bench", len(bench_rows)),
        ("...of which paid on this run", paid_count),
    ]
    _write_sheet(ws2, [config.COMPANY_NAME, "Bench Drivers (Spare) — current roster"], meta2,
                 BENCH_COLUMNS, BENCH_MONEY_COLS, BENCH_TOTAL_COLS, bench_rows,
                 note="Drivers not currently assigned to a truck (sick leave, resting between "
                      "trucks, desertion, etc.) as of the time this register was generated. "
                      "Bench drivers on legitimate leave are included and paid on the Payroll "
                      "Register above by default -- the 'On This Payroll Run?' column here shows "
                      "which ones were, in case any were manually removed for this period.")

    # --- Sheet 3: Terminated Drivers ---
    ws3 = wb.create_sheet("Terminated Drivers")
    term_rows = _termination_rows(db)
    meta3 = [
        ("Currency", config.CURRENCY),
        ("Snapshot as of", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")),
        ("Terminated drivers on record", len(term_rows)),
    ]
    _write_sheet(ws3, [config.COMPANY_NAME, "Terminated Drivers — separation & terminal dues"], meta3,
                 TERMINATION_COLUMNS, TERMINATION_MONEY_COLS, TERMINATION_TOTAL_COLS, term_rows,
                 note="All drivers currently recorded as terminated, with their terminal dues "
                      "settlement where one was processed through this system.")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
