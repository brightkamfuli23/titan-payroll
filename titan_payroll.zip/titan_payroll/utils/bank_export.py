import io
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

import config

HEADER_FILL = PatternFill(start_color="1F3B57", end_color="1F3B57", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)


def _style_header(ws, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    for c in range(1, ncols + 1):
        ws.column_dimensions[get_column_letter(c)].width = 20


def build_bank_file(db, run):
    lines = db.execute(
        """SELECT pl.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number,
                  d.surname, d.first_name, d.bank_name, d.account_no, d.branch, d.nrc_no
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE pl.run_id = ? ORDER BY d.bank_name, d.surname, d.first_name""",
        (run["id"],),
    ).fetchall()

    wb = Workbook()
    ws_all = wb.active
    ws_all.title = "All Banks"
    headers = ["Fleet No.", "Surname", "First Name", "NRC No.", "Bank", "Branch",
               "Account No.", "Amount (ZMW)", "Reference"]
    ws_all.append(headers)
    _style_header(ws_all, len(headers))

    by_bank = {}
    for l in lines:
        bank = l["bank_name"] or "UNSPECIFIED"
        by_bank.setdefault(bank, []).append(l)
        ref = f"{run['period_label']} Salary - {l['fleet_number']}"
        ws_all.append([l["fleet_number"], l["surname"], l["first_name"], l["nrc_no"],
                        bank, l["branch"], l["account_no"], round(l["payable"], 2), ref])

    total_row = len(lines) + 2
    ws_all.cell(row=total_row, column=7, value="TOTAL").font = Font(bold=True)
    ws_all.cell(row=total_row, column=8,
                value=f"=SUM(H2:H{len(lines) + 1})").font = Font(bold=True)

    for bank, rows in by_bank.items():
        safe_name = bank[:28] if bank else "UNSPECIFIED"
        ws = wb.create_sheet(title=safe_name)
        ws.append(headers)
        _style_header(ws, len(headers))
        for l in rows:
            ref = f"{run['period_label']} Salary - {l['fleet_number']}"
            ws.append([l["fleet_number"], l["surname"], l["first_name"], l["nrc_no"],
                       bank, l["branch"], l["account_no"], round(l["payable"], 2), ref])
        trow = len(rows) + 2
        ws.cell(row=trow, column=7, value="TOTAL").font = Font(bold=True)
        ws.cell(row=trow, column=8, value=f"=SUM(H2:H{len(rows) + 1})").font = Font(bold=True)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
