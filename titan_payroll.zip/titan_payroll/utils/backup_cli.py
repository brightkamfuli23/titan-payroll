"""
Command-line backup tool -- takes a safe database snapshot without needing
the app running or a browser open. Useful for:
  - A quick manual backup before shutting down / handing off the computer
    (double-click backup_now.bat on Windows, or run backup_now.sh on Mac).
  - An unattended scheduled backup (Windows Task Scheduler / cron) that
    also copies the snapshot to a second location, e.g. a OneDrive/Google
    Drive folder or a USB drive, for off-machine redundancy.

Usage:
    python utils/backup_cli.py
    python utils/backup_cli.py "D:\\TitanPayrollBackups"
    python utils/backup_cli.py "/Users/you/OneDrive/Titan Payroll Backups"
"""
import sys
import os
import shutil

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from utils import backup as backup_utils  # noqa: E402


def main():
    path = backup_utils.make_backup(tag="scheduled")
    print(f"Backup created: {path}")

    if len(sys.argv) > 1:
        dest_dir = sys.argv[1]
        try:
            os.makedirs(dest_dir, exist_ok=True)
            dest_path = os.path.join(dest_dir, os.path.basename(path))
            shutil.copy2(path, dest_path)
            print(f"Copied to: {dest_path}")
        except OSError as e:
            print(f"WARNING: could not copy backup to '{dest_dir}': {e}")
            print("The snapshot in the backups/ folder is still safe.")
            sys.exit(1)


if __name__ == "__main__":
    main()
