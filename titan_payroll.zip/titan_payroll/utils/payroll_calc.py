"""
Core payroll calculation engine.

This replicates (and fixes one gap in) the calculation logic found in the
original manual spreadsheet "TITAN PAYROLL ZAMBIA DRIVER JULY 2026.xlsx",
verified against Zambia's official 2026 statutory rates:

  PAYE (monthly, unchanged 2025->2026):
      K0        - K5,100 : 0%
      K5,101    - K7,100 : 20%
      K7,101    - K9,200 : 30%
      Above     K9,200   : 37%

  NAPSA: 5% employee (matched 5% employer, not deducted from driver),
      capped at an insurable earnings ceiling of K37,236/month, i.e. the
      employee contribution can never exceed K1,861.80/month. The original
      sheet computed NAPSA as 5% of Gross Pay with NO ceiling applied --
      that's the one correctness gap this engine fixes.

  NHIMA: 1% of Basic Salary, employee side, no ceiling. Matches original.

  Everything else (housing = 30% of salary, food/transport allowances,
  gratuity/backpay/bonus added back after tax, PAYE computed on
  Gross Pay minus Bonus/Other) mirrors the original workbook's formulas
  exactly, since that reflects this client's existing payroll practice
  (review these choices with each new client onboarded onto this product --
  they may not all treat these components the same way). The one
  new addition is the driver "Charges" ledger (loans/damages), which is
  deducted from NET pay (post-tax) and is separate from the pre-existing
  "Advance" (Credit) field, which continues to reduce Gross Pay pre-tax as
  it did in the original sheet.

NOTE for this client's accountant/tax advisor: the original sheet excludes
Bonus/Other (and entirely excludes Gratuity and Salary Backpay) from the
PAYE taxable base. This engine preserves that existing treatment rather
than silently changing it, since it may reflect a deliberate decision
(e.g. gratuity/severance often has different tax treatment in Zambia).
Please have this confirmed with your tax advisor -- it's flagged again in
the README.
"""

from dataclasses import dataclass, field


@dataclass
class PayrollInputs:
    basic_salary: float
    work_days: int
    days_attended: float
    housing_pct: float
    food: float
    transport: float
    leave_days: float = 0.0
    salary_backpay: float = 0.0
    gratuity: float = 0.0
    bonus_other: float = 0.0
    advance: float = 0.0          # pre-tax "Credit" deduction (legacy)
    charge_deduction: float = 0.0  # post-tax charges-ledger deduction (new)


@dataclass
class PayrollResult:
    daily_pay: float = 0.0
    salary: float = 0.0
    housing: float = 0.0
    leave_pay: float = 0.0
    gross_pay: float = 0.0
    nhima: float = 0.0
    napsa: float = 0.0
    paye: float = 0.0
    payable: float = 0.0


def compute_paye(taxable_income: float, bands) -> float:
    """
    Progressive PAYE calculation across monthly bands.
    bands: list of [lower, upper_or_None, rate]
    """
    if taxable_income <= 0:
        return 0.0
    tax = 0.0
    for lower, upper, rate in bands:
        if taxable_income <= lower:
            break
        top = taxable_income if upper is None else min(taxable_income, upper)
        if top > lower:
            tax += (top - lower) * rate
    return round(tax, 2)


def compute_payroll_line(inp: PayrollInputs, paye_bands, napsa_rate, napsa_ceiling, nhima_rate) -> PayrollResult:
    res = PayrollResult()

    res.daily_pay = round(inp.basic_salary / inp.work_days, 4) if inp.work_days else 0.0
    res.salary = round(res.daily_pay * inp.days_attended, 2)
    res.housing = round(inp.housing_pct * res.salary, 2)

    # Leave pay: average daily total pay (salary+housing+food+transport)/26 * leave days taken
    daily_total = (res.salary + res.housing + inp.food + inp.transport) / 26 if inp.days_attended or True else 0
    res.leave_pay = round(daily_total * inp.leave_days, 2) if inp.leave_days else 0.0

    # Gross Pay = Salary + Housing + Food + Transport + Leave Pay - Advance(Credit)
    res.gross_pay = round(
        res.salary + res.housing + inp.food + inp.transport + res.leave_pay - inp.advance, 2
    )

    # NHIMA = 1% of Basic Salary (no ceiling)
    res.nhima = round(inp.basic_salary * nhima_rate, 2)

    # NAPSA = 5% of Gross Pay, capped at ceiling * rate
    napsa_base = min(res.gross_pay, napsa_ceiling)
    res.napsa = round(max(napsa_base, 0) * napsa_rate, 2)

    # PAYE: taxable base = Gross Pay - Bonus/Other (matches legacy sheet convention)
    taxable = res.gross_pay - inp.bonus_other
    res.paye = compute_paye(taxable, paye_bands)

    # Payable (net) = Gross - NHIMA - NAPSA - PAYE + Gratuity + Backpay + Bonus - Charges deduction
    res.payable = round(
        res.gross_pay
        - res.nhima
        - res.napsa
        - res.paye
        + inp.gratuity
        + inp.salary_backpay
        + inp.bonus_other
        - inp.charge_deduction,
        2,
    )

    return res
