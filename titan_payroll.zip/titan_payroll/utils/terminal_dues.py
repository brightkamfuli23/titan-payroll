"""
Terminal dues calculator -- suggests gratuity, leave pay, and outstanding
charge deductions when a driver is separated/terminated. Every figure is
editable by the Admin before the termination is finalized; nothing here is
final until submitted on the termination form.

Legal basis (Zambia Employment Code Act No. 3 of 2019, verified Aug 2026 --
see README "Statutory rates" section for sources):
  - Fixed-term contract gratuity: not less than 25% of the employee's basic
    pay earned during the contract period (pro-rated if ended early).
  - Redundancy / death-in-service severance: 2 months' basic pay per
    completed year of service.
  - Pay in lieu of leave days accrued but not taken (2 days/month accrual,
    i.e. 24 days/year -- same rate already used for monthly leave pay).

Reasons that map to gratuity vs. severance are a judgement call this
client's HR/legal advisor should confirm -- see the note surfaced on the
termination form itself.

Desertion recovery: a driver terminated for Desertion / Absconded still has
their gratuity and leave pay calculated normally (same as everyone else),
but the company recovers one month's worth of pay (Basic Salary + Housing +
Food + Transport, at current rates) from that settlement, in addition to
any outstanding charges/loans -- this can leave the driver owing the
company money overall if the recovery + deductions exceed what they were
owed. It's expressed as a negative "Other" amount so it's just another
editable line on the termination form, same as everything else here.
"""
import datetime
from db import get_setting_float
from utils.contract import contract_info, parse_date

SEVERANCE_REASONS = {"redundancy", "medical_discharge", "death_in_service"}

REASONS = [
    ("contract_expiry", "Contract Expiry (natural end of term)"),
    ("resignation", "Resignation"),
    ("desertion", "Desertion / Absconded"),
    ("dismissal", "Dismissal (misconduct/disciplinary)"),
    ("medical_discharge", "Medical Discharge"),
    ("redundancy", "Redundancy"),
    ("death_in_service", "Death in Service"),
    ("other", "Other"),
]


def _basic_pay_earned_during_contract(db, driver, contract_start, as_of_date):
    """Sum recorded basic pay (from payroll_lines) for this driver within
    the current contract period, plus an estimate at the current basic
    salary rate for any months of the contract not yet recorded in this
    system (e.g. months paid via the old manual spreadsheet before this
    system went live)."""
    rows = db.execute(
        """SELECT pr.period_year, pr.period_month, pl.basic_salary
           FROM payroll_lines pl JOIN payroll_runs pr ON pr.id = pl.run_id
           WHERE pl.driver_id = ?""",
        (driver["id"],),
    ).fetchall()

    recorded_months = set()
    recorded_total = 0.0
    for r in rows:
        period_date = datetime.date(r["period_year"], r["period_month"], 1)
        if contract_start and period_date < datetime.date(contract_start.year, contract_start.month, 1):
            continue
        if period_date > datetime.date(as_of_date.year, as_of_date.month, 1):
            continue
        recorded_months.add((r["period_year"], r["period_month"]))
        recorded_total += r["basic_salary"]

    # Total months elapsed in the contract up to the termination date
    total_months = 0
    if contract_start:
        total_months = (as_of_date.year - contract_start.year) * 12 + (as_of_date.month - contract_start.month) + 1
        total_months = max(total_months, 0)

    missing_months = max(total_months - len(recorded_months), 0)
    estimated_total = recorded_total + missing_months * driver["basic_salary"]

    return {
        "recorded_months": len(recorded_months),
        "recorded_total": round(recorded_total, 2),
        "missing_months": missing_months,
        "estimated_missing_total": round(missing_months * driver["basic_salary"], 2),
        "total_basic_pay_earned": round(estimated_total, 2),
        "total_months": total_months,
    }


def compute_terminal_dues(db, driver, termination_date_str, reason):
    """Returns a dict of suggested figures (all editable on the form)."""
    termination_date = parse_date(termination_date_str) or datetime.date.today()
    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))
    gratuity_pct = float(get_setting_float(db, "gratuity_pct", 0.25))
    redundancy_months_per_year = float(get_setting_float(db, "redundancy_months_per_year", 2))
    housing_pct = float(get_setting_float(db, "housing_pct", 0.30))
    # Use this driver's own standing food/transport allowance (transport in
    # particular varies by route/driver, not a flat company-wide figure) so
    # the leave-pay-in-lieu valuation matches what they actually earn.
    food = float(driver["food_allowance"]) if driver["food_allowance"] is not None else float(get_setting_float(db, "default_food_allowance", 180))
    transport = float(driver["transport_full"]) if driver["transport_full"] is not None else float(get_setting_float(db, "default_transport_full", 200))

    info = contract_info(driver["date_employed"], driver["contract_end_override"],
                          contract_length, leave_per_month, today=termination_date,
                          contract_cycle_start=driver["contract_cycle_start"])
    contract_start = parse_date(driver["date_employed"])

    basic_pay_info = _basic_pay_earned_during_contract(db, driver, contract_start, termination_date)

    # --- Gratuity / severance ---
    if reason in SEVERANCE_REASONS:
        gratuity_method = "severance_2mo_per_year"
        years_served = info["months_served"] // 12
        gratuity_amount = round(redundancy_months_per_year * driver["basic_salary"] * years_served, 2)
        basis_note = (f"{years_served} completed year(s) served x {redundancy_months_per_year} "
                       f"months x basic salary {driver['basic_salary']:,.2f}")
        basic_pay_basis = years_served
    else:
        gratuity_method = "contract_gratuity_25pct"
        gratuity_amount = round(gratuity_pct * basic_pay_info["total_basic_pay_earned"], 2)
        basis_note = (f"{gratuity_pct*100:.0f}% of basic pay earned during contract "
                       f"(ZMW {basic_pay_info['total_basic_pay_earned']:,.2f})")
        basic_pay_basis = basic_pay_info["total_basic_pay_earned"]

    # --- Leave pay in lieu of untaken accrued leave ---
    leave_accrued = info["leave_days_accrued"]
    leave_taken_row = db.execute(
        "SELECT COALESCE(SUM(pl.leave_days),0) s FROM payroll_lines pl WHERE pl.driver_id = ?",
        (driver["id"],),
    ).fetchone()
    leave_taken = leave_taken_row["s"] or 0
    leave_days_owing = max(round(leave_accrued - leave_taken, 2), 0)

    salary = driver["basic_salary"]  # full month basic, since owing leave is valued at current pay
    housing = housing_pct * salary
    daily_total = (salary + housing + food + transport) / 26
    leave_pay_amount = round(daily_total * leave_days_owing, 2)

    # --- Desertion recovery: 1 month's full pay, recovered from the settlement ---
    monthly_full_pay = round(salary + housing + food + transport, 2)
    if reason == "desertion":
        other_amount = -monthly_full_pay
        other_description = (
            f"Desertion recovery: 1 month's pay (Basic {salary:,.2f} + Housing {housing:,.2f} "
            f"+ Food {food:,.2f} + Transport {transport:,.2f} = {monthly_full_pay:,.2f})"
        )
    else:
        other_amount = 0.0
        other_description = ""

    # --- Outstanding charges (loans/damages) to settle from final pay ---
    open_charges = db.execute(
        "SELECT * FROM charges WHERE driver_id = ? AND status = 'open'", (driver["id"],)
    ).fetchall()
    charge_rows = []
    deductions_total = 0.0
    for c in open_charges:
        paid = db.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM charge_deductions WHERE charge_id = ?", (c["id"],)
        ).fetchone()["s"]
        balance = round(c["total_amount"] - paid, 2)
        if balance > 0:
            charge_rows.append({"id": c["id"], "description": c["description"], "balance": balance})
            deductions_total += balance

    total_payable = round(gratuity_amount + leave_pay_amount + other_amount - deductions_total, 2)

    return {
        "termination_date": termination_date.isoformat(),
        "contract_info": info,
        "basic_pay_info": basic_pay_info,
        "gratuity_method": gratuity_method,
        "gratuity_amount": gratuity_amount,
        "basic_pay_basis": basic_pay_basis,
        "basis_note": basis_note,
        "leave_accrued": leave_accrued,
        "leave_taken": leave_taken,
        "leave_days_owing": leave_days_owing,
        "leave_pay_amount": leave_pay_amount,
        "other_amount": other_amount,
        "other_description": other_description,
        "open_charges": charge_rows,
        "deductions_amount": round(deductions_total, 2),
        "total_payable": total_payable,
    }
