import io
import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

import config
from utils.contract import contract_info
from db import get_setting_float

HEADER_FILL = PatternFill(start_color="1F3B57", end_color="1F3B57", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)
TITLE_FONT = Font(bold=True, size=14)
LABEL_FONT = Font(bold=True)


def build_summary_workbook(db, run):
    wb = Workbook()
    ws = wb.active
    ws.title = "Management Summary"

    ws["A1"] = config.COMPANY_NAME
    ws["A1"].font = TITLE_FONT
    ws["A2"] = f"Payroll Management Summary - {run['period_label']}"
    ws["A2"].font = Font(bold=True, size=11)

    row = 4
    counts = {}
    for status in ("active", "spare", "terminated"):
        counts[status] = db.execute(
            "SELECT COUNT(*) c FROM drivers WHERE status=?", (status,)
        ).fetchone()["c"]

    ws.cell(row=row, column=1, value="Driver Headcount").font = LABEL_FONT
    row += 1
    for label, key in [("Active drivers", "active"), ("Spare drivers", "spare"), ("Terminated", "terminated")]:
        ws.cell(row=row, column=1, value=label)
        ws.cell(row=row, column=2, value=counts[key])
        row += 1
    ws.cell(row=row, column=1, value="Total on record").font = LABEL_FONT
    ws.cell(row=row, column=2, value=sum(counts.values())).font = LABEL_FONT
    row += 2

    totals = db.execute(
        """SELECT COALESCE(SUM(gross_pay),0) gross, COALESCE(SUM(payable),0) net,
                  COALESCE(SUM(nhima),0) nhima, COALESCE(SUM(napsa),0) napsa,
                  COALESCE(SUM(paye),0) paye, COALESCE(SUM(charge_deduction),0) charges,
                  COUNT(*) cnt
           FROM payroll_lines WHERE run_id = ?""",
        (run["id"],),
    ).fetchone()

    ws.cell(row=row, column=1, value=f"Payroll Cost - {run['period_label']}").font = LABEL_FONT
    row += 1
    for label, val in [
        ("Drivers paid this run", totals["cnt"]),
        ("Total Gross Pay (ZMW)", round(totals["gross"], 2)),
        ("Total NAPSA (employee)", round(totals["napsa"], 2)),
        ("Total NHIMA (employee)", round(totals["nhima"], 2)),
        ("Total PAYE", round(totals["paye"], 2)),
        ("Total Charges/Loan Deductions", round(totals["charges"], 2)),
        ("Total Net Pay (Payable)", round(totals["net"], 2)),
    ]:
        ws.cell(row=row, column=1, value=label)
        ws.cell(row=row, column=2, value=val)
        row += 1
    row += 1

    # Contract status
    contract_length = int(float(get_setting_float(db, "contract_length_months", 12)))
    leave_per_month = float(get_setting_float(db, "leave_days_per_month", 2))
    alert_days = int(float(get_setting_float(db, "expiring_contract_alert_days", 30)))

    active_drivers = db.execute("SELECT * FROM drivers WHERE status='active'").fetchall()
    valid_count = 0
    expired_count = 0
    expiring_soon = []
    today = datetime.date.today()
    for d in active_drivers:
        info = contract_info(d["date_employed"], d["contract_end_override"], contract_length, leave_per_month,
                              contract_cycle_start=d["contract_cycle_start"])
        if info["status"] == "Expired":
            expired_count += 1
        else:
            valid_count += 1
        if info["expected_end"]:
            end_date = datetime.date.fromisoformat(info["expected_end"])
            days_left = (end_date - today).days
            if 0 <= days_left <= alert_days:
                expiring_soon.append((d, end_date, days_left))

    ws.cell(row=row, column=1, value="Contract Status (active drivers)").font = LABEL_FONT
    row += 1
    ws.cell(row=row, column=1, value="Valid contracts")
    ws.cell(row=row, column=2, value=valid_count)
    row += 1
    ws.cell(row=row, column=1, value="Expired contracts (needs renewal/review)")
    ws.cell(row=row, column=2, value=expired_count)
    row += 2

    ws.cell(row=row, column=1,
            value=f"Contracts Expiring Within {alert_days} Days").font = LABEL_FONT
    row += 1
    headers = ["Fleet No.", "Surname", "First Name", "Expected Contract End", "Days Left"]
    for i, h in enumerate(headers, start=1):
        c = ws.cell(row=row, column=i, value=h)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
    row += 1
    if expiring_soon:
        for d, end_date, days_left in sorted(expiring_soon, key=lambda x: x[2]):
            ws.cell(row=row, column=1, value=d["fleet_number"])
            ws.cell(row=row, column=2, value=d["surname"])
            ws.cell(row=row, column=3, value=d["first_name"])
            ws.cell(row=row, column=4, value=end_date.isoformat())
            ws.cell(row=row, column=5, value=days_left)
            row += 1
    else:
        ws.cell(row=row, column=1, value="None")
        row += 1

    for col, width in zip("ABCDE", [14, 16, 16, 22, 12]):
        ws.column_dimensions[col].width = width

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
