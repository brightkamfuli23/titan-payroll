"""Contract span / status / leave-accrual helpers (mirrors AE-AI columns
of the legacy sheet: CONTRACT END, End Date, CONTRACT SPAN, CONTRACT
STATUS, Leave Days)."""
import datetime


def add_months(d: datetime.date, months: int) -> datetime.date:
    month = d.month - 1 + months
    year = d.year + month // 12
    month = month % 12 + 1
    day = min(d.day, [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
                       31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1])
    return datetime.date(year, month, day)


def parse_date(s):
    if not s:
        return None
    if isinstance(s, datetime.date):
        return s
    try:
        return datetime.datetime.strptime(s[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def _months_between(start, end):
    n = (end.year - start.year) * 12 + (end.month - start.month)
    if end.day < start.day:
        n -= 1
    return max(n, 0)


def contract_info(date_employed, contract_end_override=None, contract_length_months=12,
                   leave_days_per_month=2, today=None, contract_cycle_start=None):
    """Returns dict with expected_end, months_served, status, leave_days_accrued.

    `expected_end`/`status` describe the CURRENT contract cycle: anchored on
    `contract_cycle_start` if the driver has ever been renewed, otherwise on
    `date_employed`. Renewing resets contract_cycle_start to the renewal
    date, which pushes these forward.

    `months_served`/`leave_days_accrued` are tenure-based -- always anchored
    on `date_employed`, continuous across renewals. Renewing carries these
    forward rather than resetting them, since nothing is settled/paid out at
    renewal time (see roster.renew_contract) -- an eventual termination's
    gratuity/leave-owing is still meant to reflect the driver's full history
    since date_employed.

    `contract_end_override` is accepted for backwards compatibility (every
    call site still passes the driver's stored value) but is otherwise
    unused here -- it used to cap `today` for these calculations, which
    silently froze Months Served/Leave Days Accrued at that fixed date for
    any driver still employed past it (232 of 277 drivers were stuck this
    way, all sharing the same 2026-06-01 bulk-import default). Per the
    client's confirmed policy (2026-08-21), every contract span/tenure
    figure is always computed from the driver's actual start date
    (date_employed, or contract_cycle_start after a renewal) through the
    real current date -- nothing freezes it early."""
    today = today or datetime.date.today()
    employed = parse_date(date_employed)
    cycle_start = parse_date(contract_cycle_start) or employed

    if employed is None:
        return {
            "expected_end": None, "months_served": 0, "status": "Unknown",
            "leave_days_accrued": 0, "cycle_start": None,
        }

    months_served = _months_between(employed, today)
    leave_days_accrued = months_served * leave_days_per_month

    expected_end = add_months(cycle_start, contract_length_months)
    cycle_months_served = _months_between(cycle_start, today)
    status = "Expired" if cycle_months_served >= contract_length_months else "Valid"

    return {
        "expected_end": expected_end.isoformat(),
        "months_served": months_served,
        "status": status,
        "leave_days_accrued": leave_days_accrued,
        "cycle_start": cycle_start.isoformat(),
    }
