"""Contract span / status / leave-accrual helpers (mirrors AE-AI columns
of the legacy sheet: CONTRACT END, End Date, CONTRACT SPAN, CONTRACT
STATUS, Leave Days)."""
import datetime


def add_months(d: datetime.date, months: int) -> datetime.date:
    month = d.month - 1 + months
    year = d.year + month // 12
    month = month % 12 + 1
    day = min(d.day, [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
                       31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1])
    return datetime.date(year, month, day)


def parse_date(s):
    if not s:
        return None
    if isinstance(s, datetime.date):
        return s
    try:
        return datetime.datetime.strptime(s[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def contract_info(date_employed, contract_end_override=None, contract_length_months=12,
                   leave_days_per_month=2, today=None):
    """Returns dict with expected_end, months_served, status, leave_days_accrued."""
    today = today or datetime.date.today()
    employed = parse_date(date_employed)
    override = parse_date(contract_end_override)

    if employed is None:
        return {
            "expected_end": None, "months_served": 0, "status": "Unknown",
            "leave_days_accrued": 0,
        }

    expected_end = add_months(employed, contract_length_months)
    reference_end = min(today, override) if override else today

    months_served = (reference_end.year - employed.year) * 12 + (reference_end.month - employed.month)
    if reference_end.day < employed.day:
        months_served -= 1
    months_served = max(months_served, 0)

    status = "Expired" if months_served >= contract_length_months else "Valid"
    leave_days_accrued = months_served * leave_days_per_month

    return {
        "expected_end": expected_end.isoformat(),
        "months_served": months_served,
        "status": status,
        "leave_days_accrued": leave_days_accrued,
    }
