"""
Bulk upload of driver charges (loans, damages, advances...) from an Excel
(.xlsx) or CSV sheet.

Flow: parse the sheet -> match each row to a driver -> show the user a preview
-> only then insert. Nothing is guessed silently: a row that can't be matched to
exactly one driver is reported and skipped, and a row matched on a partial name
is flagged for the user to check before confirming.
"""
import csv
import datetime
import io
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_ROWS = 2000

# Normalised header text (lower-case, letters/digits only) -> field
_HEADERS = {
    "fleet": {"fleet", "fleetno", "fleetnumber", "truck", "truckno", "trucknumber"},
    "name": {"drivername", "name", "driver", "employee", "employeename", "fullname"},
    "surname": {"surname", "lastname", "secondname"},
    "first_name": {"firstname", "first", "givenname", "forename", "othernames"},
    "nrc": {"nrc", "nrcno", "nrcnumber"},
    "description": {"description", "charge", "chargedescription", "reason", "details", "item", "narration"},
    "total": {"totalamount", "total", "amount", "chargeamount", "totalcharge", "value"},
    "installment": {"monthlyinstallment", "installment", "instalment", "monthlyinstalment",
                    "monthlydeduction", "deduction", "monthly"},
    "date": {"datecharged", "date", "chargedate"},
}


def _norm_header(v):
    s = str(v or "").lower()
    s = re.sub(r"\(.*?\)", "", s)      # "(ZMW)", "(optional)"
    s = s.replace("zmw", "")
    return re.sub(r"[^a-z0-9]", "", s)


def _map_header(row):
    """Return {field: column_index} if this row looks like the header row."""
    found = {}
    for i, cell in enumerate(row):
        h = _norm_header(cell)
        if not h:
            continue
        for field, names in _HEADERS.items():
            if h in names and field not in found:
                found[field] = i
                break
    has_driver = any(k in found for k in ("name", "surname", "nrc", "fleet"))
    if "description" in found and "total" in found and has_driver:
        return found
    return None


def read_sheet(file_bytes, filename):
    """-> (rows, error). rows = [(excel_row_number, {field: raw_value})]"""
    if len(file_bytes) > MAX_FILE_BYTES:
        return None, "That file is too large (limit 2 MB)."
    fname = (filename or "").lower()
    grid = []
    try:
        if fname.endswith(".csv"):
            try:
                text = file_bytes.decode("utf-8-sig")
            except UnicodeDecodeError:
                text = file_bytes.decode("latin-1")
            grid = [list(r) for r in csv.reader(io.StringIO(text))]
        elif fname.endswith((".xlsx", ".xlsm")):
            wb = load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
            sheets = [wb[n] for n in wb.sheetnames if n.lower() == "charges"] + list(wb.worksheets)
            for ws in sheets:
                g = [list(r) for r in ws.iter_rows(values_only=True)]
                if any(_map_header(r) for r in g[:15]):
                    grid = g
                    break
            else:
                grid = [list(r) for r in wb.worksheets[0].iter_rows(values_only=True)]
        else:
            return None, "Please upload an Excel file (.xlsx) or a CSV file."
    except Exception:
        return None, "That file couldn't be read. Please upload a valid .xlsx or .csv file (use the template)."

    header_idx, cols = None, None
    for i, r in enumerate(grid[:15]):
        m = _map_header(r)
        if m:
            header_idx, cols = i, m
            break
    if cols is None:
        return None, ("Couldn't find the column headings. The sheet needs at least a driver name (or NRC / "
                      "fleet number), Description and Total Amount columns -- download the template to see the layout.")

    rows = []
    for i in range(header_idx + 1, len(grid)):
        r = grid[i]
        rec = {f: (r[ix] if ix < len(r) else None) for f, ix in cols.items()}
        if all(v is None or str(v).strip() == "" for v in rec.values()):
            continue
        rows.append((i + 1, rec))
    if not rows:
        return None, "No data rows were found under the column headings."
    if len(rows) > MAX_ROWS:
        return None, f"Too many rows ({len(rows)}). Please upload at most {MAX_ROWS} at a time."
    return rows, None


# ---------------------------------------------------------------- parsing
def parse_money(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None, None
    if isinstance(v, bool):
        return None, "not a number"
    if isinstance(v, (int, float)):
        return round(float(v), 2), None
    s = re.sub(r"(?i)^\s*(zmw|k)\s*", "", str(v))
    s = re.sub(r"[,\s]", "", s)
    try:
        return round(float(s), 2), None
    except ValueError:
        return None, f"'{v}' is not a number"


def parse_date(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None, None
    if isinstance(v, datetime.datetime):
        return v.date().isoformat(), None
    if isinstance(v, datetime.date):
        return v.isoformat(), None
    s = str(v).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d %b %Y", "%d %B %Y"):
        try:
            return datetime.datetime.strptime(s, fmt).date().isoformat(), None
        except ValueError:
            pass
    return None, f"'{s}' is not a recognised date"


def _tokens(s):
    return set(t for t in re.split(r"[^a-z0-9]+", str(s or "").lower()) if t)


def _nrc(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


# ---------------------------------------------------------------- matching
def _driver_index(db):
    rows = db.execute(
        """SELECT d.id, d.first_name, d.surname, d.fleet_number, d.nrc_no, d.status,
                  t.fleet_number AS truck_fleet
           FROM drivers d
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id"""
    ).fetchall()
    out = []
    for r in rows:
        fleets = {str(x).strip().lower() for x in (r["truck_fleet"], r["fleet_number"]) if x}
        out.append({
            "id": r["id"], "status": r["status"],
            "tokens": _tokens(r["first_name"]) | _tokens(r["surname"]),
            "fleets": fleets, "nrc": _nrc(r["nrc_no"]),
            "label": f"{r['truck_fleet'] or r['fleet_number'] or '-'} - {r['first_name']} {r['surname']}",
        })
    return out


def _narrow(cands, fleet):
    if fleet and len(cands) > 1:
        f = fleet.strip().lower()
        n = [c for c in cands if f in c["fleets"]]
        if n:
            return n
    return cands


def _find_driver(index, rec):
    """-> (driver, warning, error)"""
    nrc = _nrc(rec.get("nrc"))
    fleet = str(rec.get("fleet") or "").strip()
    if rec.get("surname") or rec.get("first_name"):
        name = f"{rec.get('first_name') or ''} {rec.get('surname') or ''}"
    else:
        name = str(rec.get("name") or "")
    ntok = _tokens(name)

    if nrc:
        hit = [d for d in index if d["nrc"] and d["nrc"] == nrc]
        if len(hit) == 1:
            return hit[0], None, None
        if len(hit) > 1:
            return None, None, "NRC number matches more than one driver"
        if not ntok:
            return None, None, "NRC number not found on any driver"

    if ntok:
        exact = _narrow([d for d in index if d["tokens"] == ntok], fleet)
        if len(exact) == 1:
            return exact[0], None, None
        if len(exact) > 1:
            return None, None, "More than one driver has this name - add the NRC or fleet number"
        partial = _narrow([d for d in index if len(ntok) >= 2 and (ntok <= d["tokens"] or d["tokens"] <= ntok)
                           and len(ntok & d["tokens"]) >= 2], fleet)
        if len(partial) == 1:
            return partial[0], "Matched on a partial name - please check it is the right driver", None
        if len(partial) > 1:
            return None, None, "Name matches several drivers - add the NRC or fleet number"
        return None, None, "No driver found with this name"

    if fleet:
        hit = [d for d in index if fleet.lower() in d["fleets"] and d["status"] != "terminated"]
        if len(hit) == 1:
            return hit[0], "Matched on fleet number only - please check it is the right driver", None
        return None, None, "No single driver found for this fleet number"
    return None, None, "No driver name, NRC or fleet number on this row"


def match_rows(db, rows):
    """Turn parsed sheet rows into preview results.
    status: ok | warn | skip (duplicate) | error"""
    index = _driver_index(db)
    existing = set()
    for r in db.execute("SELECT driver_id, description, total_amount, date_charged FROM charges").fetchall():
        existing.add((r["driver_id"], str(r["description"]).strip().lower(),
                      round(float(r["total_amount"]), 2), r["date_charged"]))
    seen = set()
    today = datetime.date.today().isoformat()
    results = []
    for rownum, rec in rows:
        res = {
            "row": rownum,
            "excel_name": (f"{rec.get('first_name') or ''} {rec.get('surname') or ''}".strip()
                           if (rec.get("surname") or rec.get("first_name")) else str(rec.get("name") or "").strip()),
            "fleet": str(rec.get("fleet") or "").strip(),
            "description": str(rec.get("description") or "").strip()[:200],
            "driver_id": None, "driver_label": "", "total": None, "installment": None, "date": None,
            "status": "ok", "message": "",
        }
        errors, warns = [], []
        driver, warn, err = _find_driver(index, rec)
        if err:
            errors.append(err)
        elif driver["status"] == "terminated":
            errors.append("Driver is terminated - charges for leavers are settled through Terminal Dues")
        else:
            res["driver_id"], res["driver_label"] = driver["id"], driver["label"]
            if warn:
                warns.append(warn)

        if not res["description"]:
            errors.append("Description is missing")
        total, e = parse_money(rec.get("total"))
        if e:
            errors.append("Total amount: " + e)
        elif total is None or total <= 0:
            errors.append("Total amount must be more than zero")
        res["total"] = total
        inst, e = parse_money(rec.get("installment"))
        if e:
            errors.append("Installment: " + e)
        elif inst is not None and inst <= 0:
            errors.append("Installment must be more than zero")
        if total and total > 0 and not e:
            if inst is None:
                inst = total
                warns.append("No installment given - the full amount will be deducted on the next payroll run")
            elif inst > total:
                inst = total
        res["installment"] = inst
        d, e = parse_date(rec.get("date"))
        if e:
            errors.append("Date: " + e)
        res["date"] = d or today

        if errors:
            res["status"], res["message"] = "error", "; ".join(errors)
        else:
            key = (res["driver_id"], res["description"].lower(), res["total"], res["date"])
            if key in existing:
                res["status"], res["message"] = "skip", "Already in the system - will be skipped"
            elif key in seen:
                res["status"], res["message"] = "skip", "Repeated earlier in this sheet - will be skipped"
            else:
                seen.add(key)
                if warns:
                    res["status"], res["message"] = "warn", "; ".join(warns)
        results.append(res)
    return results


def build_template():
    wb = Workbook()
    ws = wb.active
    ws.title = "Charges"
    headers = ["Fleet No", "Driver Name", "NRC No", "Description", "Total Amount",
               "Monthly Installment", "Date Charged"]
    widths = [12, 30, 16, 34, 14, 20, 14]
    for i, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(row=1, column=i, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3B57")
        c.alignment = Alignment(horizontal="center")
        ws.column_dimensions[c.column_letter].width = w
    ws.freeze_panes = "A2"

    info = wb.create_sheet("Instructions")
    lines = [
        "How to fill in the Charges sheet",
        "",
        "One row per charge. Delete nothing from the heading row; type your rows underneath it.",
        "",
        "Driver Name  - the driver's name, as on their record (first and last name, either order).",
        "NRC No       - optional, but the most reliable way to match a driver.",
        "Fleet No     - optional; helps pick the right driver if two share a name.",
        "Description  - required, e.g. 'Windscreen damage' or 'Salary advance repayment'.",
        "Total Amount - required, the full amount owed (ZMW).",
        "Monthly Installment - optional. Deducted from each payroll run until the total is paid off.",
        "              Leave blank to deduct the whole amount on the next payroll run.",
        "Date Charged - optional (YYYY-MM-DD or DD/MM/YYYY). Blank = today.",
        "",
        "Rows that cannot be matched to exactly one driver are listed on the preview and skipped.",
        "Nothing is saved until you confirm on the preview page.",
    ]
    for i, t in enumerate(lines, start=1):
        c = info.cell(row=i, column=1, value=t)
        if i == 1:
            c.font = Font(bold=True, size=13)
    info.column_dimensions["A"].width = 100
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
