"""
Starting content for the News Center. Loaded once (guarded by the
`news_seeded` setting) so the page isn't empty on first deploy; after that
Admins add/edit/delete items from the News Center page itself.

Figures were checked on 2026-10-23 against ZRA, PwC Tax Summaries, the
Ministry of Labour and Social Security, EY and other sources named on each
item. Third-party summaries are labelled as such -- always confirm with the
authority (ZRA, NAPSA, NHIMA, MLSS) before acting.
"""

ADDED = "2026-10-23"

SEED_ITEMS = [
    # ------------------------------------------------------------------ tax
    dict(
        category="tax", importance="important",
        title="PAYE bands for 2026 (effective 1 January 2026)",
        summary="Monthly PAYE: first K5,100 at 0%; K5,100.01 to K7,100 at 20%; K7,100.01 to K9,200 at 30%; "
                "above K9,200 at 37%.",
        details="These are the bands shown on the ZRA PAYE calculator and in PwC's Zambia tax summary for the 2026 "
                "charge year (annual equivalents: K61,200 / K85,200 / K110,400).\n"
                "Some third-party websites quote a 37.5% top rate or a different second band. The ZRA and PwC "
                "figures are the ones to follow.\n"
                "When this item was written, the system's default PAYE bands matched the figures above.",
        recommended_action="Open Settings and confirm the PAYE bands still match. Review them again after every "
                           "National Budget.",
        source_name="ZRA - PAYE calculator", source_url="https://www.zra.org.zm/paye-calculator/",
        effective_date="2026-01-01",
    ),
    dict(
        category="tax", importance="important",
        title="NAPSA ceiling K37,236 a month; NHIMA 1%",
        summary="NAPSA: 5% employee + 5% employer on monthly earnings up to K37,236, so the most either side "
                "pays is K1,861.80. NHIMA: 1% of basic pay from the employee and 1% from the employer.",
        details="The new NAPSA monthly ceiling applies from 1 January 2026. It is not backdated, so any period "
                "processed before the new ceiling was applied must be corrected manually.\n"
                "The NHIMA rate was reported unchanged. The system's defaults matched these figures when this "
                "item was written.",
        recommended_action="Confirm the NAPSA ceiling and rates in Settings. For drivers on K4,000 basic pay "
                           "the ceiling is not reached, so no one is currently capped.",
        source_name="Sage 300 People - Zambia statutory update (third-party)",
        source_url="https://communityhub.sage.com/za/sage-300-people/f/announcements/261374/statutory-update-zambia-napsa-ceiling-increase-effective-01-january-2026",
        effective_date="2026-01-01",
    ),
    dict(
        category="tax", importance="info",
        title="2026 Budget: other measures employers may notice",
        summary="The deduction for employing persons with disabilities rises from K2,000 to K2,500 per qualifying "
                "employee. A reduced late-payment penalty of 0.5% a month is also reported from 1 January 2026.",
        details="The disability deduction increase is confirmed in EY's 2026 National Budget analysis. The 0.5% "
                "late-payment penalty comes from a third-party tax summary that has some internal "
                "inconsistencies, so treat it as reported rather than confirmed.",
        recommended_action="Confirm the penalty rate with ZRA before relying on it.",
        source_name="EY - Zambia 2026 National Budget analysis",
        source_url="https://www.ey.com/content/dam/ey-unified-site/ey-com/en-zm/documents/ey-zm-budget-economic-overview.pdf",
        effective_date="2026-01-01",
    ),
    dict(
        category="tax", importance="info",
        title="Reminder: monthly remittances",
        summary="PAYE is due to ZRA by the 10th of the following month. NAPSA and NHIMA have their own due dates.",
        details="Published guides give differing dates for NAPSA and NHIMA, so the system does not state them here. "
                "Confirm the current due dates with NAPSA and NHIMA and put them in the finance calendar.",
        recommended_action="After each payroll run is finalized, schedule the PAYE, NAPSA and NHIMA payments.",
        source_name="MJ Consultants - PAYE rates guide (third-party)",
        source_url="https://mjconsultants.co.zm/guides/paye-rates-zambia-2026/",
    ),
    # ------------------------------------------------------------------- SI
    dict(
        category="si", importance="action",
        title="SI No. 3 of 2025: higher minimum wages for bus and truck drivers",
        summary="Basic minimum wage for truck drivers rose from K3,000 to K4,000, and for bus drivers from K2,200 "
                "to K3,000. Cross-border subsistence: US$30 a night for vehicles without a sleeping cabin, US$20 "
                "with one.",
        details="Announced on 16 January 2025. The Ministry of Labour and Social Security notice of 11 April 2025 "
                "urged all employers to review pay structures, tell workers about the changes, and warned of "
                "integrated inspections and sanctions.\n"
                "The Ministry's notice says the new wages apply to non-unionised workers operating public service "
                "vehicles. Check with your lawyer or the Ministry how this applies to goods-haulage drivers and "
                "to any unionised staff.\n"
                "When this item was written, every driver on the system was on a K4,000 basic salary, which is at "
                "the truck-driver minimum.",
        recommended_action="Keep basic salary at or above K4,000 for covered drivers, compare cross-border "
                           "subsistence payments with the US$ rates, and keep records ready for inspections.",
        source_name="Ministry of Labour and Social Security - notice, 11 April 2025",
        source_url="https://www.mlss.gov.zm/?p=5141",
        effective_date="2025-01-16",
    ),
    # ----------------------------------------------------------- labour law
    dict(
        category="labour_law", importance="important",
        title="Employment Code (Amendment) Bill withdrawn: watch for a revised draft",
        summary="After trade-union opposition, the amendment bill was withdrawn. As of early 2026 no revised "
                "draft had been announced.",
        details="Critics said the bill would have weakened protections on gratuity, forced leave and contract "
                "transfers. If a revised bill returns, gratuity, leave and termination calculations in the system "
                "may need to change.",
        recommended_action="No change needed now. Tell us when a new draft is published so we can review the "
                           "gratuity and leave logic.",
        source_name="Paul Hastings - Zambia employment law summary (Feb 2026)",
        source_url="https://www.paulhastings.com/insights/practice-area-articles/zambia",
    ),
    dict(
        category="labour_law", importance="info",
        title="Pending: Workers' Compensation Bill and social-security reform",
        summary="A Workers' Compensation Bill to replace the 1999 Act and a social-security reform bill were "
                "pending in 2026. The compensation bill had not yet been tabled in Parliament.",
        details="The Workers' Compensation (Funeral Expenses Reimbursement) Order, approved in August 2025, "
                "requires funeral-expense reimbursement for the families of workers who die in the course of "
                "their duties. It does not change what employers pay into the Workers' Compensation Fund.",
        recommended_action="Keep a record of any work-related deaths and follow up with the Fund on "
                           "reimbursement.",
        source_name="Paul Hastings - Zambia employment law summary (Feb 2026)",
        source_url="https://www.paulhastings.com/insights/practice-area-articles/zambia",
    ),
    dict(
        category="labour_law", importance="info",
        title="Employment Code Act No. 3 of 2019: points that affect payroll",
        summary="Gratuity is mandatory on fixed-term contracts, overtime is payable beyond 48 hours a week, and "
                "standard redundancy procedures apply to written contracts.",
        details="This is the law behind the contract-renewal gratuity the system calculates. Contracts signed "
                "before the Act came into force had a one-year grace period.",
        source_name="Paul Hastings - Zambia employment law summary (Feb 2026)",
        source_url="https://www.paulhastings.com/insights/practice-area-articles/zambia",
    ),
    dict(
        category="labour_law", importance="info",
        title="NAPSA (Amendment) Act No. 1 of 2023: partial withdrawal and employer duty",
        summary="Members with at least five years of contributions, and either 60 monthly contributions or age 45, "
                "can withdraw a one-off 20% of indexed contributions plus interest. Employers must deduct and "
                "remit employee contributions.",
        details="Drivers may ask HR about the 20% withdrawal. Employers carry the duty to deduct and remit "
                "correctly, so NAPSA numbers on payslips need to be accurate.",
        recommended_action="Keep each driver's NAPSA number complete on their record.",
        source_name="Paul Hastings - Zambia employment law summary (Feb 2026)",
        source_url="https://www.paulhastings.com/insights/practice-area-articles/zambia",
    ),
    # --------------------------------------------------------------- system
    dict(
        category="system", importance="action",
        title="Recommended: check statutory rates after every Budget and each January",
        summary="PAYE bands, the NAPSA ceiling and the NHIMA rate are set in Settings and are not updated "
                "automatically.",
        details="When the National Budget or a Statutory Instrument changes a rate, the new figures only apply "
                "once they are entered in Settings. After changing them, check the figures on any open draft "
                "payroll run before finalizing it.",
        recommended_action="Each October after the Budget speech and again each January: open Settings, compare "
                           "with the News Center, update, then check any open draft run.",
    ),
    dict(
        category="system", importance="info",
        title="System update: payslip logo, payroll Excel and run clean-up",
        summary="Payslips now show the company logo at top left with a faint watermark. Archived runs can be "
                "deleted permanently, and the payroll Excel marks each pay cycle's terminations with a red line.",
        details="Payslips: logo top-left and a light watermark in the middle of every generated payslip.\n"
                "Archived runs: Admins can delete an archived run, draft or finalized, from Payroll Runs, "
                "Archived. Finalized runs are backed up first, and the charges and contract renewals they "
                "triggered are reversed.\n"
                "Payroll Excel: the Terminated Drivers sheet lists everyone on record, newest pay cycle first, "
                "with a thick red line where each earlier pay cycle begins.",
        source_name=None,
    ),
]


def seed_news(db):
    """Insert the starting items once. Safe to call on every boot."""
    from db import get_setting, set_setting
    if get_setting(db, "news_seeded") is not None:
        return
    for it in SEED_ITEMS:
        db.execute(
            """INSERT INTO news_items (category, importance, title, summary, details, recommended_action,
                                       source_name, source_url, effective_date, published_date)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (it["category"], it["importance"], it["title"], it["summary"], it.get("details"),
             it.get("recommended_action"), it.get("source_name"), it.get("source_url"),
             it.get("effective_date"), ADDED),
        )
    db.commit()
    set_setting(db, "news_seeded", "1")
