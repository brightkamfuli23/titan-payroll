import io
import zipfile
from reportlab.lib.pagesizes import A5
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

import config


def _fmt(n):
    try:
        return f"{n:,.2f}"
    except (TypeError, ValueError):
        return "0.00"


def _line_query(db, run_id, driver_id):
    return db.execute(
        """SELECT pl.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number,
                  d.surname, d.first_name, d.bank_name, d.account_no,
                  d.nrc_no, d.tpin_no, d.napsa_no, d.nhima_no
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE pl.run_id = ? AND pl.driver_id = ?""",
        (run_id, driver_id),
    ).fetchone()


def _build_pdf_bytes(run, line):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A5, topMargin=10 * mm, bottomMargin=10 * mm,
                             leftMargin=10 * mm, rightMargin=10 * mm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("title", parent=styles["Heading2"], alignment=1, spaceAfter=2)
    sub_style = ParagraphStyle("sub", parent=styles["Normal"], alignment=1, textColor=colors.grey)

    elems = []
    elems.append(Paragraph(config.COMPANY_NAME, title_style))
    elems.append(Paragraph(f"Payslip &ndash; {run['period_label']}", sub_style))
    elems.append(Spacer(1, 8))

    info_data = [
        ["Employee", f"{line['first_name']} {line['surname']}", "Fleet No.", line["fleet_number"] or ""],
        ["NRC No.", line["nrc_no"] or "", "TPIN No.", line["tpin_no"] or ""],
        ["NAPSA No.", line["napsa_no"] or "", "NHIMA No.", line["nhima_no"] or ""],
        ["Bank", line["bank_name"] or "", "Account No.", line["account_no"] or ""],
    ]
    info_table = Table(info_data, colWidths=[28 * mm, 42 * mm, 24 * mm, 32 * mm])
    info_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
    ]))
    elems.append(info_table)
    elems.append(Spacer(1, 10))

    earn_rows = [["EARNINGS", "AMOUNT (ZMW)"]]
    earn_rows.append(["Basic Salary", _fmt(line["basic_salary"])])
    earn_rows.append([f"Days Attended ({line['days_attended']:g}/{line['work_days']})",
                       _fmt(line["salary"])])
    earn_rows.append(["Housing Allowance", _fmt(line["housing"])])
    earn_rows.append(["Food Allowance", _fmt(line["food"])])
    earn_rows.append(["Transport Allowance", _fmt(line["transport"])])
    if line["leave_pay"]:
        earn_rows.append([f"Leave Pay ({line['leave_days']:g} days)", _fmt(line["leave_pay"])])
    if line["advance"]:
        earn_rows.append(["Less: Salary Advance", f"-{_fmt(line['advance'])}"])
    earn_rows.append(["GROSS PAY", _fmt(line["gross_pay"])])
    if line["salary_backpay"]:
        earn_rows.append(["Salary Backpay", _fmt(line["salary_backpay"])])
    if line["gratuity"]:
        earn_rows.append(["Gratuity", _fmt(line["gratuity"])])
    if line["bonus_other"]:
        earn_rows.append(["Bonus / Other", _fmt(line["bonus_other"])])

    earn_table = Table(earn_rows, colWidths=[86 * mm, 40 * mm])
    earn_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f3b57")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, colors.grey),
        ("FONTNAME", (0, -5 if line["salary_backpay"] or line["gratuity"] or line["bonus_other"] else -1),
         (-1, -5 if line["salary_backpay"] or line["gratuity"] or line["bonus_other"] else -1), "Helvetica-Bold"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    elems.append(earn_table)
    elems.append(Spacer(1, 8))

    ded_rows = [["DEDUCTIONS", "AMOUNT (ZMW)"]]
    ded_rows.append(["NAPSA (5%)", _fmt(line["napsa"])])
    ded_rows.append(["NHIMA (1%)", _fmt(line["nhima"])])
    ded_rows.append(["PAYE", _fmt(line["paye"])])
    if line["charge_deduction"]:
        ded_rows.append(["Loan / Charge Repayment", _fmt(line["charge_deduction"])])
    total_ded = line["napsa"] + line["nhima"] + line["paye"] + line["charge_deduction"]
    ded_rows.append(["TOTAL DEDUCTIONS", _fmt(total_ded)])

    ded_table = Table(ded_rows, colWidths=[86 * mm, 40 * mm])
    ded_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#7a2020")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("LINEABOVE", (0, -1), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    elems.append(ded_table)
    elems.append(Spacer(1, 10))

    net_table = Table([["NET PAY", f"ZMW {_fmt(line['payable'])}"]], colWidths=[86 * mm, 40 * mm])
    net_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#e8eef4")),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#1f3b57")),
    ]))
    elems.append(net_table)
    elems.append(Spacer(1, 14))
    elems.append(Paragraph(
        "This is a system-generated payslip. Please report any discrepancy to Payroll/HR within 5 working days.",
        ParagraphStyle("footnote", parent=styles["Normal"], fontSize=6.5, textColor=colors.grey)))

    doc.build(elems)
    buf.seek(0)
    return buf.read()


def build_single_payslip(db, run, driver_id):
    line = _line_query(db, run["id"], driver_id)
    if line is None:
        return None, None
    pdf_bytes = _build_pdf_bytes(run, line)
    filename = f"Payslip_{line['fleet_number']}_{line['surname']}_{line['first_name']}_{run['period_label'].replace(' ', '_')}.pdf"
    return io.BytesIO(pdf_bytes), filename


def build_all_payslips_zip(db, run):
    lines = db.execute(
        """SELECT pl.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number,
                  d.surname, d.first_name, d.bank_name, d.account_no,
                  d.nrc_no, d.tpin_no, d.napsa_no, d.nhima_no
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE pl.run_id = ? ORDER BY d.surname, d.first_name""",
        (run["id"],),
    ).fetchall()

    zip_buf = io.BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for line in lines:
            pdf_bytes = _build_pdf_bytes(run, line)
            filename = f"{line['fleet_number']}_{line['surname']}_{line['first_name']}.pdf".replace(" ", "_")
            zf.writestr(filename, pdf_bytes)
    zip_buf.seek(0)
    return zip_buf
