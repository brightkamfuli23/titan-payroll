"""
Database backup helper.

The database now lives in Supabase (Postgres) rather than a local SQLite
file, so "backup" here means: connect, read every table, and write a plain
SQL dump (CREATE-free -- just INSERT statements matching schema.sql, which
already runs on every app startup) that can be replayed into any empty
Postgres database with `psql` or pasted into the Supabase SQL editor to
restore. It is NOT a substitute for Supabase's own project-level backups --
see the README's "Backups" section -- but it gives Admin a portable, human-
readable snapshot they can download any time, independent of the Supabase
dashboard.

Snapshots are taken automatically whenever a payroll run is finalized (the
most important checkpoint to never lose), and can also be triggered any
time from Settings ("Download Database Backup Now").
"""
import os
import datetime
import glob

import config
import db as db_module

# Order matters: children after the parents they reference (foreign keys).
_TABLES = [
    ("settings", ["key", "value"]),
    ("users", ["id", "username", "password_hash", "full_name", "role", "active", "created_at"]),
    ("drivers", ["id", "fleet_number", "surname", "first_name", "bank_name", "account_no", "branch",
                 "nrc_no", "tpin_no", "napsa_no", "nhima_no", "phone", "email", "date_employed",
                 "basic_salary", "work_days", "food_allowance", "transport_full", "transport_partial",
                 "status", "date_terminated", "contract_end_override", "comments", "created_at", "updated_at"]),
    ("trucks", ["id", "fleet_number", "notes", "created_at"]),
    ("truck_assignments", ["id", "truck_id", "driver_id", "start_date", "end_date", "end_reason",
                            "note", "created_by", "created_at"]),
    ("payroll_runs", ["id", "period_year", "period_month", "period_label", "status", "created_by",
                       "created_at", "finalized_at", "finalized_by"]),
    ("payroll_lines", ["id", "run_id", "driver_id", "basic_salary", "work_days", "days_attended",
                        "daily_pay", "salary", "housing", "food", "transport", "leave_days", "leave_pay",
                        "salary_backpay", "gratuity", "bonus_other", "advance", "gross_pay", "nhima",
                        "napsa", "paye", "charge_deduction", "payable", "comments"]),
    ("terminations", ["id", "driver_id", "termination_date", "reason", "gratuity_method",
                       "basic_pay_basis", "gratuity_amount", "leave_days_owing", "leave_pay_amount",
                       "other_amount", "other_description", "deductions_amount", "total_payable",
                       "status", "notes", "created_by", "created_at", "finalized_at"]),
    ("charges", ["id", "driver_id", "description", "date_charged", "total_amount",
                 "installment_amount", "status", "created_by", "created_at"]),
    ("charge_deductions", ["id", "charge_id", "run_id", "termination_id", "amount", "created_at"]),
    ("audit_log", ["id", "user_id", "action", "details", "created_at"]),
]


def _esc(v):
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def make_backup(tag=None, keep=60):
    """Write a timestamped SQL snapshot of the live database to backups/ and
    return its full path. Prunes older snapshots beyond `keep` (oldest
    first) so the folder doesn't grow forever -- set keep=None to disable
    pruning."""
    os.makedirs(config.BACKUPS_DIR, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    suffix = f"_{tag}" if tag else ""
    filename = f"payroll_backup_{ts}{suffix}.sql"
    dest = os.path.join(config.BACKUPS_DIR, filename)

    conn = db_module._connect()
    try:
        lines = [
            f"-- {config.COMPANY_NAME} payroll backup ({config.PRODUCT_NAME}) -- {ts}",
            "-- Restore into an empty database that already has schema.sql applied",
            "-- (the app runs schema.sql automatically on every startup).",
            "",
        ]
        for table, cols in _TABLES:
            rows = conn.execute(f"SELECT {', '.join(cols)} FROM {table} ORDER BY {cols[0]}").fetchall()
            if not rows:
                continue
            lines.append(f"-- {table}: {len(rows)} rows")
            tuples = [f"({', '.join(_esc(r[c]) for c in cols)})" for r in rows]
            lines.append(f"INSERT INTO {table} ({', '.join(cols)}) VALUES")
            lines.append(",\n".join(tuples) + ";")
            lines.append("")
        with open(dest, "w") as f:
            f.write("\n".join(lines))
    finally:
        conn.close()

    if keep:
        _prune_old_backups(keep)

    return dest


def _prune_old_backups(keep):
    files = sorted(glob.glob(os.path.join(config.BACKUPS_DIR, "payroll_backup_*.sql")))
    excess = len(files) - keep
    for f in files[:max(excess, 0)]:
        try:
            os.remove(f)
        except OSError:
            pass


def list_backups():
    """Return backup files newest-first, with size and modified time, for
    display on the Settings page."""
    files = glob.glob(os.path.join(config.BACKUPS_DIR, "payroll_backup_*.sql"))
    rows = []
    for f in files:
        stat = os.stat(f)
        rows.append({
            "filename": os.path.basename(f),
            "path": f,
            "size_kb": round(stat.st_size / 1024, 1),
            "modified": datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
        })
    rows.sort(key=lambda r: r["modified"], reverse=True)
    return rows
