"""
Best-effort statutory contribution/tax schedules for NAPSA, NHIMA and PAYE
(ZRA), built from publicly available guidance on each body's reporting
requirements (employee name, ID/registration numbers, contribution base,
employee & employer amounts). These are NOT official e-filing templates --
whoever runs payroll should confirm the exact column layout each portal/
e-filing system expects (NAPSA e-service, NHIMA portal, ZRA TaxOnline)
before first submission, and this workbook can then be adjusted to match
exactly.
"""
import io
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

import config

HEADER_FILL = PatternFill(start_color="1F3B57", end_color="1F3B57", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)
NOTE_FONT = Font(italic=True, color="808080", size=9)


def _sheet(wb, title, headers):
    ws = wb.create_sheet(title=title)
    ws.append(headers)
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        ws.column_dimensions[get_column_letter(c)].width = 20
    return ws


def build_statutory_workbook(db, run):
    lines = db.execute(
        """SELECT pl.*, COALESCE(t.fleet_number, d.fleet_number) as fleet_number,
                  d.surname, d.first_name, d.nrc_no, d.tpin_no, d.napsa_no, d.nhima_no
           FROM payroll_lines pl JOIN drivers d ON d.id = pl.driver_id
           LEFT JOIN truck_assignments ta ON ta.driver_id = d.id AND ta.end_date IS NULL
           LEFT JOIN trucks t ON t.id = ta.truck_id
           WHERE pl.run_id = ? ORDER BY d.surname, d.first_name""",
        (run["id"],),
    ).fetchall()

    napsa_rate = float(db.execute("SELECT value FROM settings WHERE key='napsa_rate'").fetchone()["value"])
    napsa_ceiling = float(db.execute("SELECT value FROM settings WHERE key='napsa_ceiling'").fetchone()["value"])
    nhima_rate = float(db.execute("SELECT value FROM settings WHERE key='nhima_rate'").fetchone()["value"])

    wb = Workbook()
    wb.remove(wb.active)

    # --- NAPSA schedule ---
    ws = _sheet(wb, "NAPSA", ["Fleet No.", "Surname", "First Name", "NRC No.", "NAPSA No.",
                               "Insurable Earnings (ZMW)", "Employee 5% (ZMW)", "Employer 5% (ZMW)",
                               "Total Contribution (ZMW)"])
    for l in lines:
        base = min(l["gross_pay"], napsa_ceiling)
        emp = round(base * napsa_rate, 2)
        ws.append([l["fleet_number"], l["surname"], l["first_name"], l["nrc_no"], l["napsa_no"],
                   round(base, 2), emp, emp, round(emp * 2, 2)])
    trow = len(lines) + 2
    ws.cell(row=trow, column=6, value="TOTAL").font = Font(bold=True)
    ws.cell(row=trow, column=7, value=f"=SUM(G2:G{len(lines)+1})").font = Font(bold=True)
    ws.cell(row=trow, column=8, value=f"=SUM(H2:H{len(lines)+1})").font = Font(bold=True)
    ws.cell(row=trow, column=9, value=f"=SUM(I2:I{len(lines)+1})").font = Font(bold=True)
    ws.cell(row=trow + 2, column=1,
            value=f"Insurable earnings ceiling: ZMW {napsa_ceiling:,.2f}/month. Verify column layout "
                  f"against the NAPSA e-Service bulk contribution template before submission.").font = NOTE_FONT

    # --- NHIMA schedule ---
    ws = _sheet(wb, "NHIMA", ["Fleet No.", "Surname", "First Name", "NRC No.", "NHIMA No.",
                               "Basic Pay (ZMW)", "Employee 1% (ZMW)", "Employer 1% (ZMW)",
                               "Total Contribution (ZMW)"])
    for l in lines:
        emp = round(l["basic_salary"] * nhima_rate, 2)
        ws.append([l["fleet_number"], l["surname"], l["first_name"], l["nrc_no"], l["nhima_no"],
                   round(l["basic_salary"], 2), emp, emp, round(emp * 2, 2)])
    trow = len(lines) + 2
    ws.cell(row=trow, column=6, value="TOTAL").font = Font(bold=True)
    ws.cell(row=trow, column=7, value=f"=SUM(G2:G{len(lines)+1})").font = Font(bold=True)
    ws.cell(row=trow, column=8, value=f"=SUM(H2:H{len(lines)+1})").font = Font(bold=True)
    ws.cell(row=trow, column=9, value=f"=SUM(I2:I{len(lines)+1})").font = Font(bold=True)
    ws.cell(row=trow + 2, column=1,
            value="No contribution ceiling applies to NHIMA. Verify column layout against the NHIMA "
                  "employer portal template before submission.").font = NOTE_FONT

    # --- PAYE / ZRA schedule ---
    ws = _sheet(wb, "PAYE", ["Fleet No.", "Surname", "First Name", "NRC No.", "TPIN No.",
                              "Gross Pay (ZMW)", "Taxable Pay (ZMW)", "PAYE Deducted (ZMW)"])
    for l in lines:
        taxable = round(l["gross_pay"] - l["bonus_other"], 2)
        ws.append([l["fleet_number"], l["surname"], l["first_name"], l["nrc_no"], l["tpin_no"],
                   round(l["gross_pay"], 2), taxable, round(l["paye"], 2)])
    trow = len(lines) + 2
    ws.cell(row=trow, column=6, value="TOTAL").font = Font(bold=True)
    ws.cell(row=trow, column=6).value = "TOTAL"
    ws.cell(row=trow, column=8, value=f"=SUM(H2:H{len(lines)+1})").font = Font(bold=True)
    ws.cell(row=trow + 2, column=1,
            value=f"Taxable pay excludes Bonus/Other per {config.COMPANY_NAME}'s existing payroll practice -- "
                  "confirm this treatment (and the treatment of Gratuity/Backpay, which are currently "
                  "untaxed) with your tax advisor. Verify column layout against ZRA TaxOnline before e-filing.").font = NOTE_FONT

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
