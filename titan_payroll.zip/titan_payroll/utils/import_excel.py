"""
One-time migration: import the driver roster from the legacy manual Excel
workbook ("TITAN PAYROLL ZAMBIA DRIVER JULY 2026.xlsx") into the new
system's SQLite database.

Usage:
    python utils/import_excel.py /path/to/TITAN_PAYROLL_ZAMBIA_DRIVER_JULY_2026.xlsx

Notes on the source layout (sheet "Payroll-zambia driver"):
  - Header rows 1-6, data starts row 7.
  - Rows 7-269   : active drivers
  - Row 270      : "SPARE DRIVERS" section label
  - Rows 272-287 : spare drivers
  - Row 289      : "TERMINATED" section label
  - Rows 291-306 : terminated drivers

"Fleet Number" (column B) identifies the TRUCK, not the employee -- the
same fleet number can legitimately appear on more than one driver record
(a truck gets reassigned between drivers over time, and a spare driver may
be linked to a truck another driver currently occupies). It is therefore
imported as a plain field, not a unique key -- the database primary key is
an auto-increment driver id.
"""
import sys
import os
import datetime
import openpyxl

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import config
import db as db_module
from utils import roster as roster_utils

SHEET_NAME = "Payroll-zambia driver"

SECTIONS = [
    (7, 269, "active"),
    (272, 287, "spare"),
    (291, 306, "terminated"),
]

COL = {
    "fleet_number": 2,   # B
    "surname": 3,        # C
    "first_name": 4,     # D
    "bank_name": 5,      # E
    "account_no": 6,     # F
    "branch": 7,         # G
    "nrc_no": 8,          # H
    "tpin_no": 9,         # I
    "napsa_no": 10,        # J
    "nhima_no": 11,        # K
    "date_employed": 12,   # L
    "basic_salary": 13,    # M
    "work_days": 14,       # N
    "food_allowance": 19,      # S -- "Food" -- captured per driver (see note below)
    "transport_full": 20,      # T -- "Transport" -- captured per driver (see note below)
    "contract_end_override": 32,  # AF
    "comments": 36,         # AJ
}

# NOTE on food/transport allowances: the manual sheet enters one literal
# ZMW figure per driver per month for both columns, not a formula. Food is
# uniform (180 for every driver in the source data), but Transport is NOT
# uniform -- it ranges from the standard 156/200 full-attendance rate up to
# 1,620 or 3,420 for drivers on particular long-haul routes, unrelated to
# attendance. These are therefore imported as each driver's own standing
# allowance (drivers.food_allowance / drivers.transport_full), which is what
# every new payroll run line is seeded from, rather than one company-wide
# default applied to everyone. HR/Admin can update either figure any time
# from the driver's Edit page if a route or allowance changes.


def _s(val):
    if val is None:
        return None
    return str(val).strip() or None


def _iso_date(val):
    if val is None:
        return None
    if isinstance(val, (datetime.datetime, datetime.date)):
        return val.strftime("%Y-%m-%d")
    return _s(val)


def import_drivers(xlsx_path, conn=None):
    wb = openpyxl.load_workbook(xlsx_path, data_only=False)
    ws = wb[SHEET_NAME]

    own_conn = False
    if conn is None:
        conn = db_module._connect()
        own_conn = True

    default_work_days = int(float(conn.execute(
        "SELECT value FROM settings WHERE key='default_work_days'").fetchone()["value"]))
    default_food = float(conn.execute(
        "SELECT value FROM settings WHERE key='default_food_allowance'").fetchone()["value"])
    default_transport = float(conn.execute(
        "SELECT value FROM settings WHERE key='default_transport_full'").fetchone()["value"])

    inserted = 0
    skipped = 0
    trucks_assigned = 0
    conflicts = []  # active drivers whose fleet number was already taken by another active driver
    assigned_fleet_numbers = set()

    for lo, hi, status in SECTIONS:
        for r in range(lo, hi + 1):
            fleet = ws.cell(row=r, column=COL["fleet_number"]).value
            surname = ws.cell(row=r, column=COL["surname"]).value
            if not fleet or not surname:
                continue

            basic_salary = ws.cell(row=r, column=COL["basic_salary"]).value
            try:
                basic_salary = float(basic_salary) if basic_salary is not None else 0.0
            except (TypeError, ValueError):
                basic_salary = 0.0

            work_days = ws.cell(row=r, column=COL["work_days"]).value
            try:
                work_days = int(work_days) if work_days is not None else default_work_days
            except (TypeError, ValueError):
                work_days = default_work_days

            food_allowance = ws.cell(row=r, column=COL["food_allowance"]).value
            try:
                food_allowance = float(food_allowance) if food_allowance not in (None, "") else default_food
            except (TypeError, ValueError):
                food_allowance = default_food

            transport_full = ws.cell(row=r, column=COL["transport_full"]).value
            try:
                transport_full = float(transport_full) if transport_full not in (None, "") else default_transport
            except (TypeError, ValueError):
                transport_full = default_transport

            date_employed = _iso_date(ws.cell(row=r, column=COL["date_employed"]).value)
            contract_end_override = _iso_date(ws.cell(row=r, column=COL["contract_end_override"]).value)
            date_terminated = contract_end_override if status == "terminated" else None

            row = {
                "fleet_number": _s(fleet),
                "surname": _s(surname).upper() if _s(surname) else None,
                "first_name": _s(ws.cell(row=r, column=COL["first_name"]).value),
                "bank_name": _s(ws.cell(row=r, column=COL["bank_name"]).value),
                "account_no": _s(ws.cell(row=r, column=COL["account_no"]).value),
                "branch": _s(ws.cell(row=r, column=COL["branch"]).value),
                "nrc_no": _s(ws.cell(row=r, column=COL["nrc_no"]).value),
                "tpin_no": _s(ws.cell(row=r, column=COL["tpin_no"]).value),
                "napsa_no": _s(ws.cell(row=r, column=COL["napsa_no"]).value),
                "nhima_no": _s(ws.cell(row=r, column=COL["nhima_no"]).value),
                "date_employed": date_employed,
                "basic_salary": basic_salary,
                "work_days": work_days,
                "food_allowance": food_allowance,
                "transport_full": transport_full,
                "status": status,
                "date_terminated": date_terminated,
                "contract_end_override": contract_end_override,
                "comments": _s(ws.cell(row=r, column=COL["comments"]).value),
            }

            cur = conn.execute(
                """INSERT INTO drivers
                   (fleet_number, surname, first_name, bank_name, account_no, branch,
                    nrc_no, tpin_no, napsa_no, nhima_no, date_employed, basic_salary,
                    work_days, food_allowance, transport_full, status, date_terminated,
                    contract_end_override, comments)
                   VALUES (:fleet_number, :surname, :first_name, :bank_name, :account_no, :branch,
                    :nrc_no, :tpin_no, :napsa_no, :nhima_no, :date_employed, :basic_salary,
                    :work_days, :food_allowance, :transport_full, :status, :date_terminated,
                    :contract_end_override, :comments)""",
                row,
            )
            new_id = cur.lastrowid
            inserted += 1

            # Seed a live truck assignment for active drivers only -- spare/
            # terminated drivers' fleet_number is kept as reference text only
            # (see module docstring: a truck can have only one current driver,
            # and the original sheet has 14 cases of the same fleet number
            # appearing on two different ACTIVE rows -- a pre-existing data
            # conflict we surface rather than silently resolve).
            if status == "active" and row["fleet_number"]:
                fn = row["fleet_number"]
                if fn in assigned_fleet_numbers:
                    conflicts.append((fn, row["first_name"], row["surname"]))
                else:
                    assigned_fleet_numbers.add(fn)
                    truck = roster_utils.get_truck_by_fleet_number(conn, fn, create_if_missing=True)
                    conn.execute(
                        "INSERT INTO truck_assignments (truck_id, driver_id, start_date, note) "
                        "VALUES (?, ?, ?, ?)",
                        (truck["id"], new_id, row["date_employed"] or datetime.date.today().isoformat(),
                         "Seeded from July 2026 Excel import"),
                    )
                    trucks_assigned += 1

    conn.commit()
    if own_conn:
        conn.close()
    if conflicts:
        print(f"NOTE: {len(conflicts)} active driver(s) share a fleet number with another active driver "
              f"in the original sheet -- imported without a live truck assignment; resolve via the Truck "
              f"Roster (assign them their real current truck):")
        for fn, first, last in conflicts:
            print(f"   - {fn}: {first} {last}")
    return inserted, skipped, trucks_assigned, conflicts


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python utils/import_excel.py <path-to-xlsx>")
        sys.exit(1)
    from db import init_db
    init_db()
    n, skipped, trucks_assigned, conflicts = import_drivers(sys.argv[1])
    print(f"Imported {n} driver records, seeded {trucks_assigned} truck assignments.")
