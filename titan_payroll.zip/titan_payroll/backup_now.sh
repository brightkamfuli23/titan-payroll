#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "============================================================"
echo " BK HRM 300 - Payroll Backup"
echo "============================================================"

if [ ! -d "venv" ]; then
    echo "The app hasn't been run yet on this computer (no venv found)."
    echo "Run run_mac.sh once first, then try this again."
    exit 1
fi

source venv/bin/activate

# Optional: pass a folder path as an argument to also copy the backup
# there (e.g. an iCloud/OneDrive/Google Drive folder or a USB drive).
#   ./backup_now.sh "/Users/you/OneDrive/Titan Payroll Backups"
python utils/backup_cli.py "$@"

echo ""
echo "Done. See the backups/ folder next to this app."
