#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "============================================================"
echo " TITAN GATEWAY LOGISTICS - Payroll System"
echo "============================================================"

if ! command -v python3 &> /dev/null; then
    echo "Python 3 was not found. Please install it from https://www.python.org/downloads/"
    exit 1
fi

if [ ! -d "venv" ]; then
    echo "Creating a private Python environment for this app the first time..."
    python3 -m venv venv
fi

source venv/bin/activate
python -m pip install --upgrade pip > /dev/null
python -m pip install -r requirements.txt

echo ""
echo "Starting the payroll system..."
echo "Open http://127.0.0.1:5000 in your browser."
echo ""

( sleep 2 && open "http://127.0.0.1:5000" ) &
python app.py
