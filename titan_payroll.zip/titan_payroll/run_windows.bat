@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  TITAN GATEWAY LOGISTICS - Payroll System
echo ============================================================

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found on this computer.
    echo Please install Python 3.11 or later from https://www.python.org/downloads/
    echo During installation, make sure to tick "Add Python to PATH".
    pause
    exit /b 1
)

if not exist "venv\" (
    echo Creating a private Python environment for this app the first time...
    python -m venv venv
)

call venv\Scripts\activate.bat

echo Installing/updating required packages...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt

echo.
echo Starting the payroll system...
echo A browser window will open automatically. If it doesn't, go to http://127.0.0.1:5000
echo.

start "" http://127.0.0.1:5000
python app.py

pause
